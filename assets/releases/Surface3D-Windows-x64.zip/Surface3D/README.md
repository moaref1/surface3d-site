# Surface3D 0.41 — Windows x64 development preview

Extract the entire ZIP and run Surface3D.exe. Keep the adjacent DLLs, shaders, assets and library folders.

Website: https://surface3d.site
Community and bug reports: https://discord.gg/K3YzGP72cg
Contact: pouyasaad@gmail.com

Surface3D is independently developed from experience in environment and prop texturing, with AI-assisted coding. This is a development preview; see the bundled release notes for current limitations. Application source is private. Third-party notices are included in licenses/.
