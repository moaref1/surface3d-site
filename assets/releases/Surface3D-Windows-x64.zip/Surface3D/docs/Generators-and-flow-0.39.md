# Surface3D 0.39 — generators and flow maps

The 100 patterns added in 0.38 now appear under **Assets → Generators**, alongside the existing 100 recipes. They no longer appear as complete materials in the material library. Existing 0.38 releases and projects are preserved. New previews are flat grayscale pattern images, rather than the demo prop.

Double-click a generator, or drag it onto the layer or mask. The layer generator picker also includes the new groups and search. A mask receives the scalar pattern. A material effect initially drives Roughness, preserving its other incoming channels.

Select the generator effect to edit its **Generator controls** in Paint Properties. Controls include the recipe's structure, tiling and breakup where applicable, output black/white points, and optional grunge texture selection, grunge black/white points and amount. Grunge amount defaults to zero, so adding a generator preserves its original pattern. Texture controls accept a library texture drop or import. Overrides belong to that instance; reset restores its shared source default. Ordinary custom graphs use the same graph-binding and override system.

## Expose custom graph controls

In Node Properties, the small graph icon beside a supported numeric/color control or texture input exposes it in Paint Properties. Clicking an already exposed control removes its exposure and the associated overrides. A local material/mask graph is published as a shared graph when its first control is exposed. The existing Expose control menu remains available for other supported controls and naming. Saving/exporting a reusable `.s3graph` retains its parameter definitions. A material texture export remains a snapshot.

Folder mask exposure is not added in this iteration. Single-layer `.s3mat` assets still flatten their graph bindings; use `.s3graph` when reusable exposed controls must travel across projects.

## Paint Flow Map

Search **Paint Flow Map** in the graph node picker. It has an optional encoded flow input and a vector output. Choose **Edit paint** to use the existing brush, erase, clone and stencil workflow. Follow stroke derives direction from the UV path of each brush stroke. Turn it off for a fixed Direction. Speed controls the magnitude of new painted marks; Flip V changes their green-channel convention. These brush settings affect new marks, rather than redirecting existing strokes.

The result is encoded linear RG data: `0.5, 0.5` means stationary, `(RG - 0.5) * 2` decodes its UV velocity. Export as linear data, with no sRGB conversion or normal-map encoding. Erase restores the incoming flow or neutral flow. The node reuses the existing GPU paint shader and cache; it is a flow-map authoring tool, not a fluid simulation.

## Verification

The dedicated check validates all 200 exposed generator definitions, renders all 100 new generator previews, checks their output adjustments and texture-driven grunge, and verifies GPU flow painting, neutral background, zero opacity, erase, direction convention and project persistence. Native captures check Paint controls and mouse interaction with the expose icon. Existing graph/library and brush checks are run separately.
