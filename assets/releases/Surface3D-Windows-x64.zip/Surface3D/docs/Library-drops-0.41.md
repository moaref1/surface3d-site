# Surface3D 0.41 — library drops and selected-layer grouping

- Shift-click layer names to select a range; Ctrl-click toggles individual layers. The folder toolbar button groups the selected layers. The operation is undoable.
- Drag a generator onto a layer name, its material/mask thumbnail, or a visible mesh. A missing mask starts black; an existing mask retains its base and effects, with the generator appended.
- Textures and baked maps dropped on a mesh use the selected layer channel (Material defaults to Base Color), or fill the selected mask. Shared generator materials receive a channel-only Fill override; their shared source and remaining channels remain intact.
- Materials apply to the mesh texture set; decals retain surface placement. Brush drops select the brush/tool. Whole material/mask graphs apply as instances; functions use their first compatible output. Path-only functions must be connected in Graph and show an invalid viewport target.
- Library textures, generators and cached materials show a thumbnail while dragging. Targets have green outlines and a release-action label; invalid viewport positions show red feedback. Reusable graphs and brushes also have draggable library entries.

## Verification

Five focused native interaction checks passed on the final binary: reusable graph library, texture/coordinate/brush interactions, ready generators, material-pack library, and UV/layer/graph workflow. The layer workflow includes a real folder-button click that groups selected layer IDs. Actual generator drag events verified black-mask creation, subsequent mask reuse, and valid-drop feedback. Actual texture drag events verified ImageColor connection through a shared material's channel-only override. Dragging and resulting 3D captures were inspected.

An intermediate texture/coordinate/brush test crashed once; its isolated rerun and the final suite passed. This is not evidence that every intermittent crash is fixed. A separate contextual-opacity regression reports `Opacity touched another channel` on both preserved 0.40 and this development branch; it predates these changes and remains unresolved.

No project schema change. Prior releases and user projects are preserved. No ZIP created. Multi-set drops, all graph output combinations and detached-window dragging still need broader manual testing across hardware. Poly Haven HDRIs continue to use the existing explicit environment action; they are not treated as ordinary channel textures.
