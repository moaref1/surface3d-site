# Surface3D 0.40 — portable controls and Paint Properties

Saved layer and folder assets retain their graph bindings, exposed parameter names/types/ranges, instance overrides and nested function dependencies. Only used graph definitions and textures are included. Image choices, including grunge overrides and painted-stencil resources, are portable snapshots; project-local output links are detached.

Import remaps graph, texture, layer and effect identities without changing graph-local node/port/parameter IDs. Replacing a material keeps the destination mask and its exposed controls. Imported controls can still be edited and reset in Paint Properties.

Paint Properties groups exposed controls by their naming prefix (`Structure / Tiles`, `Grunge / Texture`, etc.). The prefix becomes a collapsible section, avoiding repeated text. Breakup, Placement and Fine detail start collapsed; advanced placement is also tucked away. Unprefixed custom controls appear under General. Reset icons remain beside overridden controls.

Nine focused graph, mask, material, texture-pack, nested-function, generator and portable-asset checks passed. The final replacement/edit/reset checks and native library interaction checks passed again after the UI refinement. GPU comparisons verify that imported material and mask pixels match their originals within 0.003 at 256px, then verify that editing/resetting imported controls changes/restores pixels. The native Paint layout was captured and inspected.

No project schema change. Older assets load normally. An asset already flattened by an earlier version cannot recover its lost exposure metadata: re-save it from the original project using this version. External anchors outside a saved asset remain unsupported rather than silently copied incorrectly. Live project outputs travel as texture snapshots, not links to another project.
