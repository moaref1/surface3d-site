#define SAMPLER 116
#define MAPPER 128
#define SPLATTER 192
#define SPLATTER_BLEND 193
#define SPLATTER_EXTRACT 194
#define SPLATTER_MASK 195
#define DIRT 211
#define CELLS 212
#define SPOTS 213
#define FUR 214
#define FRACTAL 215
#define DIRECTIONAL 216
#define GRUNGE 217
#define FIBERS 218
#define MORPH 220
#define UPSCALE 221
Texture2D<float4> t0:register(t0),t1:register(t1),t2:register(t2),t3:register(t3),t4:register(t4),t5:register(t5),t6:register(t6),t7:register(t7),t8:register(t8),t9:register(t9),t10:register(t10),t11:register(t11),t12:register(t12),t13:register(t13),t14:register(t14),t15:register(t15);
RWTexture2D<float4> result:register(u0);
cbuffer Settings:register(b0){uint4 info,config;float4 parameters,extra0,extra1,controls0,controls1;};
float4 fetch(int slot,int2 p){switch(slot){case 0:return t0.Load(int3(p,0));case 1:return t1.Load(int3(p,0));case 2:return t2.Load(int3(p,0));case 3:return t3.Load(int3(p,0));case 4:return t4.Load(int3(p,0));case 5:return t5.Load(int3(p,0));case 6:return t6.Load(int3(p,0));case 7:return t7.Load(int3(p,0));case 8:return t8.Load(int3(p,0));case 9:return t9.Load(int3(p,0));case 10:return t10.Load(int3(p,0));case 11:return t11.Load(int3(p,0));case 12:return t12.Load(int3(p,0));case 13:return t13.Load(int3(p,0));case 14:return t14.Load(int3(p,0));case 15:return t15.Load(int3(p,0));}return 0;}
int boundary(int x){int size=config.x;if(config.y==1)return clamp(x,0,size-1);if(config.y==2){x=(x%(size*2)+size*2)%(size*2);return x<size?x:size*2-1-x;}return (x%size+size)%size;}
float3 unit(float3 n){return dot(n,n)>1e-12?normalize(n):float3(0,0,1);}
float4 sampleField(int slot,float2 uv,int type){float2 q=uv*config.x-.5;int2 base=(int2)floor(q);float2 f=frac(q);float4 value=0;[unroll]for(int y=0;y<2;y++)[unroll]for(int x=0;x<2;x++){float4 p=fetch(slot,int2(boundary(base.x+x),boundary(base.y+y)));if(type==1)p.rgb*=p.a;value+=p*(x?f.x:1-f.x)*(y?f.y:1-f.y);}if(type==1)value.rgb=value.a>1e-8?value.rgb/value.a:0;if(type==5)value=float4(unit(value.xyz),0);return value;}
bool connected(int s){return (config.z&(1u<<s))!=0;}
float mapValue(int slot,float2 uv,float fallback){return connected(slot)?sampleField(slot,uv,0).x:fallback;}
float rand(uint x){x^=x>>16;x*=0x7feb352du;x^=x>>15;x*=0x846ca68bu;x^=x>>16;return (x>>8)/16777216.0;}
float2 rotate2(float2 p,float a){float c=cos(a),s=sin(a);return float2(c*p.x-s*p.y,s*p.x+c*p.y);}
float fade(float a,float b,float x){float t=saturate((x-a)/max(b-a,1e-8));return t*t*(3-2*t);}
float noise(float2 p,uint seed,int period){int2 cell=(int2)floor(p);float2 f=frac(p);f=f*f*(3-2*f);float4 v;[unroll]for(int j=0;j<2;j++)[unroll]for(int i=0;i<2;i++){int2 c=(cell+int2(i,j))%period;c=(c+period)%period;v[j*2+i]=rand((uint)c.x*73856093u^(uint)c.y*19349663u^seed);}return lerp(lerp(v.x,v.y,f.x),lerp(v.z,v.w,f.x),f.y);}
#if OPERATOR>=DIRT && OPERATOR<=FIBERS
#if OPERATOR==DIRECTIONAL || OPERATOR==GRUNGE
float periodicDirectional(float2 uv,uint seed,int scale,float angle,float stretch){float2 t=frac(uv),w=t*t*(3-2*t);float2 a=rotate2(t*scale,-angle),b=rotate2((t-float2(1,0))*scale,-angle),c=rotate2((t-float2(0,1))*scale,-angle),d=rotate2((t-1)*scale,-angle);a.y/=stretch;b.y/=stretch;c.y/=stretch;d.y/=stretch;return lerp(lerp(noise(a,seed,scale),noise(b,seed,scale),w.x),lerp(noise(c,seed,scale),noise(d,seed,scale),w.x),w.y);}
#endif
float recipe(float2 uv){int scale=max((int)parameters.x,1),octaves=clamp((int)parameters.z,1,8);uint seed=(uint)parameters.y;float2 q=connected(0)?sampleField(0,uv,2).xy*scale:uv*scale;float f=0,total=0,amplitude=1;[loop]for(int o=0;o<octaves;o++){f+=noise(q*(1<<o),seed+o*337,scale*(1<<o))*amplitude;total+=amplitude;amplitude*=parameters.w;}f/=max(total,1e-6);float nearest=10,next=10;int2 cell=(int2)floor(q);[unroll]for(int y=-1;y<=1;y++)[unroll]for(int x=-1;x<=1;x++){int2 c=(cell+int2(x,y))%scale;c=(c+scale)%scale;uint hash=c.x*71u+c.y*971u+seed;float d=length(cell+int2(x,y)+float2(rand(hash),rand(hash+1))-q);if(d<nearest){next=nearest;nearest=d;}else next=min(next,d);}float angle=extra0.z*6.2831853;float2 direction=round(float2(cos(angle),sin(angle))*scale);if(all(direction==0))direction.x=1;float2 p=float2(dot(direction,q),dot(float2(-direction.y,direction.x),q))/scale;float directional=0;
#if OPERATOR==DIRECTIONAL || OPERATOR==GRUNGE
 directional=periodicDirectional(q/scale,seed,scale,angle,max(extra0.w,1));
#endif
float fiber=1-fade(extra0.y*.2,extra0.y*.2+.035,abs(sin(6.2831853*(p.x+(f-.5)*2))));int mode=info.y;float value=f;
#if OPERATOR==DIRT
 if(mode==0)value=f*(1-saturate(nearest));else if(mode==1)value=fade(.35,.75,f)*rand((uint)((cell.x%scale+scale)%scale)*53u+(uint)((cell.y%scale+scale)%scale)+seed);else if(mode==2)value=1-fade(.03,.15,next-nearest);else if(mode==3)value=fade(.2,.65,f);else if(mode==4)value=pow(1-saturate(nearest),4);else value=f*(.5-.5*cos(6.2831853*q.y/scale));
#elif OPERATOR==CELLS
 value=mode==0?saturate(nearest):mode==1?1-saturate((next-nearest)*4):mode==2?pow(1-saturate(nearest),2):1-fade(.015,.06,next-nearest);
#elif OPERATOR==SPOTS
 value=mode==0?exp(-nearest*nearest/max(.005,extra0.y*extra0.y)):mode==1?(1-fade(.1,.4,nearest))*fade(.2,.7,f):1-fade(extra0.y,extra0.y+.03,nearest);
#elif OPERATOR==FUR
 value=mode==0?fiber:mode==1?fiber*fade(.2,.7,f):max(fiber,1-fade(.03,.08,abs(sin(6.2831853*p.y))));
#elif OPERATOR==FRACTAL
 value=mode<=1?f:mode==2?1-abs(2*f-1):mode==3?abs(2*f-1):fade(.2,.8,abs(2*f-1));
#elif OPERATOR==DIRECTIONAL
 value=mode==0?directional:mode==1?directional*f:mode==2?.5*(directional+sin(6.2831853*p.y)*.5+.5):mode==3?fade(.4,.6,directional):fiber*fade(.4,.8,f);
#elif OPERATOR==GRUNGE
 if(mode==0)value=.6*f+.4*(1-saturate(nearest));else if(mode==1)value=fade(.25,.65,f)*(1-fade(.03,.15,next-nearest));else if(mode==2)value=directional*pow(.5-.5*cos(6.2831853*q.y/scale),.4);else if(mode==3)value=fiber*fade(.25,.6,f);else if(mode==4)value=1-fade(.15,.5,nearest);else if(mode==5)value=pow(1-saturate(nearest),.4)*f;else if(mode==6)value=fiber*f*(1-saturate(nearest));else if(mode==7)value=fade(.5,.8,f)*(1-fade(.1,.3,nearest));else if(mode==8)value=fade(.3,.7,f);else if(mode==9)value=.5+.5*sin(6.2831853*(p.x+f*4));else if(mode==10)value=fade(.2,.65,f)*directional;else value=.5*f+.5*pow(1-saturate(nearest),3);
#elif OPERATOR==FIBERS
 value=mode==0?fiber:mode==1?max(fiber,1-fade(.03,.1,abs(sin(6.2831853*(p.y+f*3))))):.5*(fiber+1-fade(.03,.08,abs(sin(6.2831853*(p.y+f)))));
#endif
 return saturate((value-.5)*extra0.x+.5);}
#endif
#if (OPERATOR>=82 && OPERATOR<=88) || (OPERATOR>=100 && OPERATOR<=103)
SamplerState filterSampler:register(s0);
float4 filterSource(float2 uv){return t0.SampleLevel(filterSampler,uv,0);}
float4 filterGuide(float2 uv){return t1.SampleLevel(filterSampler,uv,0);}
float4 filterConverted(float4 v,uint code){if(code==1)return dot(v.rgb,float3(.2126,.7152,.0722)).xxxx;if(code==2)return v.xxxx;if(code==3)return (v.x>.5?1:0).xxxx;if(code==4)return round(v.x).xxxx;if(code==5)return float4(unit(v.rgb*2-1),0);if(code==6)return float4(unit(v.xyz),0);return v;}
float4 filterTap0(float2 uv){float4 v=filterSource(uv);if(info.z==1)v.rgb*=v.a;return v;}
float3 filterCombineNormal(float3 base,float3 detail){base=unit(base);detail=unit(detail);float3 t=base+float3(0,0,1),u=detail*float3(-1,-1,1);return t.z>1e-5?unit(t*dot(t,u)/t.z-u):unit(base+detail-float3(0,0,1)+1e-8);}
float4 basicFilter(float2 uv){float step=1.0/config.x;
#if OPERATOR==82 || OPERATOR==83 || OPERATOR==103
 float4 guide=filterConverted(filterGuide(uv),config.w);if(!connected(1))guide=1;
 float2 direction=guide.xy;
#if OPERATOR==83
 direction=float2(cos(parameters.y*.0174532925),sin(parameters.y*.0174532925))*guide.x;
#endif
 return filterSource(uv+direction*parameters.x);
#elif OPERATOR==84 || OPERATOR==85 || OPERATOR==88
 float4 l=filterConverted(filterSource(uv-float2(step,0)),info.w),r=filterConverted(filterSource(uv+float2(step,0)),info.w),up=filterConverted(filterSource(uv-float2(0,step)),info.w),down=filterConverted(filterSource(uv+float2(0,step)),info.w);
 float2 gradient=float2(r.x-l.x,down.x-up.x)*.5*config.x;
#if OPERATOR==84
 float3 detail=unit(float3(-gradient.x*parameters.x,(info.y==1?1:-1)*gradient.y*parameters.x,1));
 float3 base=connected(1)?filterConverted(filterGuide(uv),config.w).xyz:float3(0,0,1);
 return float4(filterCombineNormal(base,detail),0);
#elif OPERATOR==85
 return saturate(length(gradient)*parameters.x).xxxx;
#else
 return saturate(.5+(r.x-l.x+down.y-up.y)*config.x*parameters.x*.25).xxxx;
#endif
#elif OPERATOR==86
 int radius=clamp((int)parameters.x,1,8);float value=info.y==1?1e10:-1e10;
 [loop]for(int y=-radius;y<=radius;y++)[loop]for(int x=-radius;x<=radius;x++){float tap=filterConverted(filterSource(uv+float2(x,y)*step),info.w).x;value=info.y==1?min(value,tap):max(value,tap);}return value.xxxx;
#elif OPERATOR==87
 int count=clamp((int)parameters.y,1,8);float4 sum=0,value=filterSource(uv);
 [loop]for(int j=0;j<count;j++){float l=filterConverted(filterGuide(uv-float2(step,0)),config.w).x,r=filterConverted(filterGuide(uv+float2(step,0)),config.w).x,up=filterConverted(filterGuide(uv-float2(0,step)),config.w).x,down=filterConverted(filterGuide(uv+float2(0,step)),config.w).x;
 uv+=float2(r-l,down-up)*parameters.x*step;float4 tap=filterSource(uv);sum+=tap;value=info.y==1?min(value,tap):max(value,tap);}return info.y==0?sum/count:value;
#else
 float radius=clamp(parameters.x,0,64);if(OPERATOR==101 && connected(1))radius*=saturate(filterGuide(uv).x);float4 sum=0;float total=0;
#if OPERATOR==100
 int extent=(int)ceil(radius);float angle=parameters.y*.0174532925;
 [loop]for(int j=-extent;j<=extent;j++){float edge=saturate(radius+.5-abs(j)),weight=extra0.x>.5?edge:exp(-2*j*j/max(radius*radius,.0001))*edge;sum+=filterTap0(uv+float2(cos(angle),sin(angle))*j*step)*weight;total+=weight;}
#else
 [loop]for(int j=0;j<128;j++){float angle=j*2.39996323,fraction=sqrt((j+.5)/128.0),weight=exp(-2*fraction*fraction);sum+=filterTap0(uv+float2(cos(angle),sin(angle))*fraction*radius*step)*weight;total+=weight;}
#endif
 float4 value=sum/max(total,.001);if(info.z==1)value.rgb=value.a>1e-8?value.rgb/value.a:0;if(info.z==5)value.xyz=unit(value.xyz);
#if OPERATOR==102
 float4 original=filterSource(uv);value=float4(saturate(.5+(original.rgb-value.rgb)*parameters.z),original.a);
#endif
 return value;
#endif
}
#endif
[numthreads(8,8,1)]void process(uint3 p:SV_DispatchThreadID){if(any(p.xy>=config.x))return;float2 uv=(p.xy+.5)/config.x;float4 value=0;
#if (OPERATOR>=82 && OPERATOR<=88) || (OPERATOR>=100 && OPERATOR<=103)
 value=basicFilter(uv);
#elif OPERATOR==SAMPLER || OPERATOR==SPLATTER
 bool splatter=OPERATOR==SPLATTER;int cols=max((int)parameters.x,1),rows=max((int)parameters.y,1);int2 cell=(int2)floor(uv*float2(cols,rows));int scaleSlot=splatter?2:1,rotationSlot=splatter?3:2,positionSlot=splatter?6:8,selectorSlot=splatter?7:9,axisSlot=splatter?15:12;float best=-1e30;
 int available[8];int amount=0;if(connected(0))available[amount++]=0;if(splatter){if(connected(1))available[amount++]=1;[unroll]for(int a=8;a<=13;a++)if(connected(a))available[amount++]=a;}else{[unroll]for(int a=5;a<=7;a++)if(connected(a))available[amount++]=a;if(connected(10))available[amount++]=10;if(connected(11))available[amount++]=11;}
 float4 combined=0;int overlap=splatter?3:(int)controls0.y;bool reverse=!splatter&&controls0.z>.5;
 [loop]for(int dy=-2;dy<=2;dy++)[loop]for(int dx=-2;dx<=2;dx++){
  int2 tile=cell+(reverse?-int2(dx,dy):int2(dx,dy)),wrapped=(tile%int2(cols,rows)+int2(cols,rows))%int2(cols,rows);uint id=wrapped.y*cols+wrapped.x+1,hash=id*71u+(uint)parameters.z*97u;
  float2 center=(tile+.5+(float2(rand(hash),rand(hash+1))-.5)*(splatter?extra0.x:extra0.y))/float2(cols,rows);
  if(connected(positionSlot))center+=sampleField(positionSlot,center,2).xy*(1-saturate(splatter?extra1.z:extra1.w));if(rand(hash+2)>saturate(mapValue(4,center,1)))continue;
  float scaleMap=lerp(1,mapValue(scaleSlot,center,1),1-saturate(splatter?extra1.x:extra1.y));
  float rotationMap=mapValue(rotationSlot,center,0)*(1-saturate(splatter?extra1.y:extra1.z));
  float scale=max(.001,parameters.w*scaleMap*(splatter?1:1+(rand(hash+5)-.5)*2*extra0.z)),angle=splatter?(extra0.z+(rand(hash+3)-.5)*extra0.y+rotationMap)*6.2831853:(extra0.x+(rand(hash+3)-.5)*2*extra0.w)*.01745329252+rotationMap*6.2831853;
  float2 axis=connected(axisSlot)?max(.001,1+sampleField(axisSlot,center,2).xy):1;
  float2 local=rotate2((uv-center)*float2(cols,rows),-angle)/(scale*axis)+.5;if(any(local<0)||any(local>1))continue;
  int choice=amount?clamp((int)(lerp(rand(hash+4),mapValue(selectorSlot,center,rand(hash+4)),controls0.x)*amount),0,amount-1):0;int selected=amount?available[choice]:-1;
  float4 pattern=selected>=0?sampleField(selected,local,info.z):(1-fade(.45,.5,length(local-.5))).xxxx;float mask=selected>=0?(splatter?saturate(pattern.a):info.z==1?pattern.a:saturate(pattern.x)):pattern.x;if(mask<=0)continue;
  float height=(float)id;if(splatter){float bg=mapValue(14,center,0);height=bg+controls0.y+controls0.z*mask+controls0.w*mapValue(5,center,0);if(connected(14)&&height<=mapValue(14,uv,0))continue;}
  if(!splatter){if(info.z==5)pattern=float4(unit(float3(rotate2(pattern.xy/axis,angle),pattern.z)),0);
   if(overlap==0){if(info.z==1){float alpha=pattern.a+combined.a*(1-pattern.a);combined=float4(alpha>1e-8?(pattern.rgb*pattern.a+combined.rgb*combined.a*(1-pattern.a))/alpha:0,alpha);}else combined=lerp(combined,pattern,mask);}
   if(overlap==1)combined=max(combined,pattern);if(overlap==2)combined+=pattern;
  }
  if(height<=best)continue;best=height;
  if(splatter)value=float4(local,id+frac(angle/6.2831853),mask+2*(selected==0?0:selected==1?1:selected>=8?selected-6:0));else value=pattern;
 }
 if(!splatter){if(overlap<3)value=combined;float3 tint=connected(3)?sampleField(3,uv,1).rgb:1;uint id=(uint)max(best,0);value.rgb*=tint*(1-extra1.x*rand(id+(uint)parameters.z));if(info.z==5)value=float4(unit(value.xyz),0);
  if(connected(13)){float4 bg=sampleField(13,uv,info.z);float mask=info.z==1?saturate(value.a):info.z==5?(best>-1e20?1:0):saturate(value.x);if(info.z==1){float alpha=mask+bg.a*(1-mask);value=float4(alpha>1e-8?(value.rgb*mask+bg.rgb*bg.a*(1-mask))/alpha:0,alpha);}else {value.rgb=lerp(bg.rgb,value.rgb,mask);if(info.z==5)value.xyz=unit(value.xyz);}}
 }
#elif OPERATOR==MAPPER
 float id=fetch(0,p.xy).x;if(id>0){float2 center=connected(2)?fetch(2,p.xy).xy:.5,bounds=connected(3)?max(fetch(3,p.xy).xy,1.0/config.x):1;
 float scale=max(.001,parameters.x*lerp(1,mapValue(7,uv,1),1-saturate(extra0.z))),angle=(parameters.y+(rand((uint)id+(uint)parameters.z)-.5)*2*parameters.w)*.01745329252+mapValue(8,uv,0)*(1-saturate(extra0.w))*6.2831853;
 if(connected(15))bounds*=max(.001,1+sampleField(15,uv,2).xy);float2 delta=uv-center;if(config.y==0)delta-=round(delta);if(info.y==1)bounds=min(bounds.x,bounds.y);if(info.y==2)bounds=max(bounds.x,bounds.y);
 float2 local=rotate2(delta,-angle)/(bounds*scale)+.5+(float2(rand((uint)id+31),rand((uint)id+71))-.5)*extra0.x;
 int available[8],amount=0;if(connected(1))available[amount++]=1;[unroll]for(int a=4;a<=6;a++)if(connected(a))available[amount++]=a;[unroll]for(int a=11;a<=14;a++)if(connected(a))available[amount++]=a;
 if(amount&&all(local>=0)&&all(local<=1)){float select=lerp(rand((uint)id+(uint)parameters.z),mapValue(10,uv,rand((uint)id+(uint)parameters.z)),controls1.x);int selected=available[clamp((int)(select*amount),0,amount-1)];value=sampleField(selected,local,info.z);
 if(info.z==5)value=float4(unit(float3(rotate2(value.xy/max(bounds,.0001),angle),value.z)),0);
 else{value.rgb*=lerp(1,connected(9)?fetch(9,p.xy).rgb:1,1-saturate(extra1.x))*(1-extra0.y*rand((uint)id+17));if(info.z==1){float a=controls0.x*6.2831853,co=cos(a),si=sin(a),neutral=(value.r+value.g+value.b)/3;float3 old=value.rgb;value.rgb=co*old+si*.577350269*float3(old.b-old.g,old.r-old.b,old.g-old.r)+(1-co)*neutral;float luma=dot(value.rgb,float3(.2126,.7152,.0722));value.rgb=max(0,luma+(value.rgb-luma)*(1+controls0.y)+controls0.z);value.a=saturate(value.a+controls0.w);}}
 }}
#elif OPERATOR==SPLATTER_BLEND
 float4 data=fetch(0,p.xy);int choice=(int)floor(max(data.a,0)*.5);float coverage=saturate(data.a-choice*2);float mask=coverage*parameters.x;value=connected(2)?fetch(2,p.xy):0;
 if(mask>0){int available[8],amount=0;if(connected(1))available[amount++]=1;[unroll]for(int s=3;s<=9;s++)if(connected(s))available[amount++]=s;if(amount){float4 pattern=sampleField(connected(choice==0?1:choice+2)?(choice==0?1:choice+2):available[choice%amount],data.xy,info.y==1?5:info.y==2?0:1);if(info.y==1){float angle=(frac(data.z)+parameters.y)*6.2831853;pattern.xy=rotate2(pattern.xy,angle);if(!connected(2))value=float4(0,0,1,0);value=float4(unit(lerp(value.xyz,pattern.xyz,mask)),0);}else{value.rgb=lerp(value.rgb,pattern.rgb,mask);value.a=mask+value.a*(1-mask);}}}
#elif OPERATOR==SPLATTER_EXTRACT
 float4 data=fetch(0,p.xy);float id=floor(data.z),coverage=saturate(data.a-2*floor(max(data.a,0)*.5));value=(info.y==0?id:info.y==1?rand((uint)id):info.y==2?data.x:info.y==3?data.y:coverage).xxxx;
#elif OPERATOR==SPLATTER_MASK
 float4 data=fetch(0,p.xy);float coverage=saturate(data.a-2*floor(max(data.a,0)*.5));float selected=info.y==0?1:info.y==1?(floor(data.z)==parameters.x?1:0):(rand((uint)floor(data.z))<parameters.y?1:0);value=(coverage*selected).xxxx;
#elif OPERATOR>=DIRT && OPERATOR<=FIBERS
 value=recipe(uv).xxxx;
#elif OPERATOR==MORPH
 value=sampleField(0,uv+fetch(1,p.xy).xy*parameters.x,info.z);
#elif OPERATOR==UPSCALE
 float grid=max(parameters.x,2),floatX=uv.x*grid-.5,floatY=uv.y*grid-.5;float2 base=floor(float2(floatX,floatY)),f=frac(float2(floatX,floatY));float source=0;[unroll]for(int y=0;y<2;y++)[unroll]for(int x=0;x<2;x++)source+=sampleField(0,(base+float2(x,y)+.5)/grid,0).x*(x?f.x:1-f.x)*(y?f.y:1-f.y);value=(source+(noise(uv*grid*4,(uint)parameters.z,(int)(grid*4))-.5)*parameters.y).xxxx;
#endif
 result[p.xy]=value;}
