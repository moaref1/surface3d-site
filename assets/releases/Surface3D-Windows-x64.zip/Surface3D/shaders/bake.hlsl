// Surface3D's original bounded secondary-map BVH compute kernel.
struct Triangle { float3 a; uint group; float3 b; uint ignoreBackface; float3 c; uint reserved;
                  float3 na; uint reserved1; float3 nb; uint reserved2; float3 nc; uint reserved3; };
struct Node { float3 lo; uint begin; float3 hi; uint count; uint left, right, reserved0, reserved1; };
struct Sample { float3 position; uint group; float3 normal; uint texel; float3 tangent; int wanted;
                float3 bitangent; uint reserved; };
struct Value { float ao; float3 bent; float thickness, curvature; float2 reserved; };
StructuredBuffer<Triangle> triangles : register(t0);
#ifdef SL_DXR
RaytracingAccelerationStructure scene : register(t4);
#else
StructuredBuffer<Node> nodes : register(t1);
StructuredBuffer<uint> order : register(t2);
#endif
#ifndef SL_PRIMARY
StructuredBuffer<Sample> samples : register(t3);
RWStructuredBuffer<Value> values : register(u0);
#endif
cbuffer Parameters : register(b0) {
    uint4 counts;       // samples, maps, AO rays, thickness rays
    float4 distances;   // epsilon, AO max, thickness max, curvature radius
    float4 controls;    // spread, thickness spread, curvature intensity, ground Y
    uint4 flags;        // cosine, AO ignore backface, self occlusion, attenuation
    uint4 options;      // ground, name matching
};
float3 safeNormal(float3 v) {
    float len = length(v);
    return len > 1e-12 ? v / len : float3(0, 0, 1);
}
bool boxHit(Node box, float3 p, float3 dir, float nearT, float farT) {
    [unroll] for (uint k = 0; k < 3; k++) {
        if (abs(dir[k]) < 1e-12) {
            if (p[k] < box.lo[k] || p[k] > box.hi[k]) return false;
        } else {
            float a = (box.lo[k] - p[k]) / dir[k], b = (box.hi[k] - p[k]) / dir[k];
            nearT = max(nearT, min(a, b));
            farT = min(farT, max(a, b));
            if (nearT > farT) return false;
        }
    }
    return true;
}
bool triangleHit(Triangle t, float3 p, float3 dir, float nearT, float farT, bool backface,
                 out float distance, out float2 bary) {
    distance=farT; bary=0;
    uint z=abs(dir.y)>abs(dir.x)?1:0;if(abs(dir.z)>abs(dir[z]))z=2;
    if(dir[z]==0)return false;
    uint x=(z+1)%3,y=(x+1)%3;if(dir[z]<0){uint swap=x;x=y;y=swap;}
    float sx=dir[x]/dir[z],sy=dir[y]/dir[z];
    float3 ap=t.a-p,bp=t.b-p,cp=t.c-p;
    precise float2 a=float2(ap[x]-sx*ap[z],ap[y]-sy*ap[z]);
    precise float2 b=float2(bp[x]-sx*bp[z],bp[y]-sy*bp[z]);
    precise float2 c=float2(cp[x]-sx*cp[z],cp[y]-sy*cp[z]);
    precise float wa=b.x*c.y-b.y*c.x;
    precise float wb=c.x*a.y-c.y*a.x;
    precise float wc=a.x*b.y-a.y*b.x;
    if((wa<0||wb<0||wc<0)&&(wa>0||wb>0||wc>0))return false;
    float det=wa+wb+wc;
    if(det==0||(backface&&t.ignoreBackface&&det>=0))return false;
    distance=(wa*ap[z]+wb*bp[z]+wc*cp[z])/(det*dir[z]);
    bary=float2(wb,wc)/det;
    return distance>=nearT&&distance<=farT;
}
#ifdef SL_DXR
bool traceDetailed(float3 p,float3 dir,float nearT,float farT,int wanted,int excluded,
                   bool backface,out float bestT,out uint bestTriangle,out float2 bestBary) {
    bestT=farT;bestTriangle=0;bestBary=0;
    RayDesc ray; ray.Origin=p;ray.Direction=dir;ray.TMin=nearT;ray.TMax=farT;
    RayQuery<RAY_FLAG_NONE> query;
    query.TraceRayInline(scene,RAY_FLAG_NONE,255,ray);
    while(query.Proceed()) {
        if(query.CandidateType()!=CANDIDATE_NON_OPAQUE_TRIANGLE) continue;
        uint index=query.CandidatePrimitiveIndex(); Triangle t=triangles[index];
        if((wanted>=0&&t.group!=(uint)wanted)||(excluded>=0&&t.group==(uint)excluded))continue;
        float candidateT;float2 candidateBary;
        if(!triangleHit(t,p,dir,nearT,farT,backface,candidateT,candidateBary))continue;
        query.CommitNonOpaqueTriangleHit();
    }
    if(query.CommittedStatus()!=COMMITTED_TRIANGLE_HIT)return false;
    bestT=query.CommittedRayT();bestTriangle=query.CommittedPrimitiveIndex();
    bestBary=query.CommittedTriangleBarycentrics();
    // Reconstruct with the same edge arithmetic as the compute engine for stable map encoding.
    float reconstructed;float2 bary;
    if(triangleHit(triangles[bestTriangle],p,dir,nearT,farT,backface,reconstructed,bary)) {bestT=reconstructed;bestBary=bary;}
    return true;
}
#else
bool traceDetailed(float3 p,float3 dir,float nearT,float farT,int wanted,int excluded,
                   bool backface,out float bestT,out uint bestTriangle,out float2 bestBary) {
    bestT=farT;bestTriangle=0;bestBary=0;
    bool found=false;uint stack[64];uint top=1;stack[0]=0;
    [loop]while(top){
        Node node=nodes[stack[--top]];
        if(!boxHit(node,p,dir,nearT,bestT))continue;
        if(!node.count){
            if(top+2>64)return false;
            stack[top++]=node.left;stack[top++]=node.right;
        }else{
            [loop]for(uint i=node.begin;i<node.begin+node.count;i++){
                uint index=order[i];Triangle t=triangles[index];
                if((wanted>=0&&t.group!=(uint)wanted)||(excluded>=0&&t.group==(uint)excluded))continue;
                float distance;float2 bary;
                if(triangleHit(t,p,dir,nearT,bestT,backface,distance,bary)){
                    bestT=distance;bestTriangle=index;bestBary=bary;found=true;
                }
            }
        }
    }
    return found;
}
#endif

bool trace(float3 p,float3 dir,float nearT,float farT,int wanted,int excluded,
           bool backface,out float bestT){
    uint hitIndex;float2 bary;
    return traceDetailed(p,dir,nearT,farT,wanted,excluded,backface,bestT,hitIndex,bary);
}
float3 hemisphere(float3 n, uint i, uint count, float spread) {
    float u = (i + .5) / count;
    float angle = 6.2831853 * (reversebits(i) * 2.3283064365386963e-10);
    float limit = cos(spread * .5 * 3.14159265 / 180);
    float z = flags.x ? sqrt(1 - u * (1 - limit * limit)) : 1 - u * (1 - limit);
    float radius = sqrt(max(0, 1 - z * z));
    float3 t = safeNormal(cross(abs(n.z) < .9 ? float3(0, 0, 1) : float3(0, 1, 0), n));
    float3 b = cross(n, t);
    return t * (radius * cos(angle)) + b * (radius * sin(angle)) + n * z;
}
#ifndef SL_PRIMARY
[numthreads(64, 1, 1)]
void secondary(uint3 id : SV_DispatchThreadID) {
    if (id.x >= counts.x) return;
    Sample packet = samples[id.x];
    Value result = (Value)0;
    float3 p = packet.position, n = packet.normal;
    float epsilon = distances.x;
    if (counts.y & ((1 << 2) | (1 << 7))) {
        float visible = 0;
        float3 bent = 0;
        [loop] for (uint ray = 0; ray < counts.z; ray++) {
            float3 d = hemisphere(n, ray, counts.z, controls.x);
            float3 origin = p + n * epsilon;
            float distance;
            trace(origin, d, epsilon, distances.y, -1, flags.z ? -1 : (int)packet.group, flags.y != 0,
                  distance);
            if (options.x && d.y < -1e-6) {
                float planeT = (controls.w - origin.y) / d.y;
                if (planeT > epsilon) distance = min(distance, planeT);
            }
            float visibility = distance >= distances.y ? 1 : flags.w ? saturate(distance / distances.y) : 0;
            visible += visibility;
            bent += d * visibility;
        }
        result.ao = visible / counts.z;
        result.bent = length(bent) > epsilon ? safeNormal(bent) : n;
    }
    if (counts.y & (1 << 5)) {
        float total = 0;
        [loop] for (uint ray = 0; ray < counts.w; ray++) {
            float3 d = hemisphere(-n, ray, counts.w, controls.y);
            float distance;
            if (trace(p - n * epsilon, d, epsilon, distances.z, -1, -1, false, distance)) total += distance;
        }
        result.thickness = total / counts.w / distances.z;
    }
    if (counts.y & (1 << 3)) {
        float signedBend = 0;
        uint accepted = 0;
        float3 tangent=safeNormal(cross(abs(n.z)<.9?float3(0,0,1):float3(0,1,0),n));
        float3 bitangent=cross(n,tangent);
        uint ringSamples=min(options.z,8);
        [loop]for(uint tap=0;tap<options.z;tap++){
            uint ring=tap/ringSamples;
            float radius=distances.w/(1+.5*ring);
            float angle=6.2831853*(tap%ringSamples+.125*ring)/ringSamples;
            float3 d=tangent*cos(angle)+bitangent*sin(angle);
            float3 origin=p+d*radius+n*(radius*2);
            float distance;uint index;float2 bary;
            if(traceDetailed(origin,-n,0,radius*4,packet.wanted,-1,false,distance,index,bary)){
                Triangle t=triangles[index];
                float3 neighbor=origin-n*distance;
                float3 neighborNormal=safeNormal(t.na*(1-bary.x-bary.y)+t.nb*bary.x+t.nc*bary.y);
                if(dot(neighborNormal,n)<-.1)continue;
                float geometric=-dot(neighbor-p,n)/radius;
                float normalBend=dot(neighborNormal-n,d)*.5;
                signedBend+=packet.reserved?normalBend:(geometric+normalBend)*.5;accepted++;
            }
        }
        float bend=(accepted?signedBend/accepted:0)*controls.z;
        result.curvature=.5+(options.w?-bend:bend);
    }
    values[id.x] = result;
}

#else
struct ProjectionRay { float3 origin; float farT; float3 direction; float nearT; int wanted, excluded; uint backface, reserved; };
struct ProjectionHit { float distance, u, v; uint hitIndex; uint valid; uint3 reserved; };
StructuredBuffer<ProjectionRay> projectionRays : register(t3);
RWStructuredBuffer<ProjectionHit> projectionHits : register(u0);
[numthreads(64,1,1)]
void primary(uint3 id:SV_DispatchThreadID) {
    if(id.x>=counts.x)return;
    ProjectionRay ray=projectionRays[id.x];ProjectionHit hit=(ProjectionHit)0;float2 bary;
    hit.valid=traceDetailed(ray.origin,ray.direction,ray.nearT,ray.farT,ray.wanted,ray.excluded,ray.backface!=0,hit.distance,hit.hitIndex,bary);
    hit.u=bary.x;hit.v=bary.y;projectionHits[id.x]=hit;
}
#endif
