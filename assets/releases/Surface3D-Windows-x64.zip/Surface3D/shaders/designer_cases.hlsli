#if !defined(SPECIALIZED_NODES) || defined(NODE_143)
case 143:{float minimum=min(a.r,min(a.g,a.b)),maximum=max(a.r,max(a.g,a.b));float gray=op==0?(minimum+maximum)*.5:op==1?dLuma(a.rgb):op==2?(a.r+a.g+a.b)/3:op==3?maximum:minimum;value=gray.xxxx;break;}
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_144)
case 144:value=float4(a.rgb-dLuma(a.rgb),a.a);break;
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_145)
case 145:{float position=node.meta.z>=0?b.x:node.parameters.x,contrast=node.meta.w>=0?c.x:node.parameters.y;float feather=max(1e-5,(1-saturate(contrast))*.5);value=smoothstep(position-feather,position+feather,a.x).xxxx;break;}
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_146)
case 146:value=float4(a.rgb*exp2(node.parameters.x),a.a);if(node.links1.y!=1)value=a*exp2(node.parameters.x);break;
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_147)
case 147:{bool low=any(a.rgb<node.parameters.x),high=any(a.rgb>node.parameters.y);value=op==1?(low||high?1:0).xxxx:float4(high?float3(1,0,0):low?float3(0,.25,1):float3(0,.35,0),a.a);break;}
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_148)
case 148:{float warm=node.parameters.x,tint=node.parameters.y;float3 gains=exp2(float3(warm-tint*.25,tint*.5,-warm-tint*.25));value=float4(a.rgb*gains,a.a);break;}
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_149)
case 149:value=saturate(safeNormalize(a.xyz).z).xxxx;break;
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_150)
case 150:{float angle=node.parameters.x*(node.meta.z>=0?b.x:1)*6.283185307;value=float4(safeNormalize(float3(dRotate2(a.xy,angle),a.z)),0);break;}
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_156)
case 156:{float metallic=op==0&&node.meta.z>=0?saturate(b.x):0;float low=lerp(node.parameters.x,node.parameters.z,metallic),high=lerp(node.parameters.y,1,metallic);
    float tolerance=node.parameters.w;value=float4(clamp(a.rgb,max(0,low-tolerance),high+tolerance),a.a);break;}
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_157)
case 157:{float metallic=node.meta.z>=0?saturate(b.x):0,brightness=max(a.r,max(a.g,a.b)),tolerance=node.parameters.w;
    bool albedo=any(a.rgb<node.parameters.x-tolerance)||any(a.rgb>node.parameters.y+tolerance),metal=brightness<node.parameters.z-tolerance||brightness>1+tolerance;
    bool bad=op==0?albedo:op==1?metal:(metallic>=.5?metal:albedo);
    value=op==3?(bad?1:0).xxxx:float4(bad?float3(1,.08,0):float3(0,.65,.15),a.a);break;}
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_158)
case 158:value=dDielectricF0(op,node.parameters.x,node.parameters.y).xxxx;break;
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_159)
case 159:value=float4(workingFrom709(dMetalColor(op))*node.parameters.x,1);break;
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_167)
case 167:{float ao=node.meta.z>=0?max(b.x,node.parameters.y):1;value=float4(lerp(a.rgb,a.rgb/ao,node.parameters.x),a.a);break;}
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_168)
case 168:value=float4(dPanoramaDirection(node.meta.y>=0?a.xy:(float2(p)+.5)/outputSettings.y),0);break;
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_171)
case 171:{float2 q=dRotate2((node.meta.y>=0?a.xy:uv)-node.parameters.zw,-node.parameters.y*.01745329252);float v=q.x/node.parameters.x+.5;
    if(op==1)v=1-abs(2*v-1);if(op==2)v=abs(q.x)/node.parameters.x;if(op==3)v=1-abs(q.x)/node.parameters.x;
    if(op==4)v=length(q)/node.parameters.x;if(op==5)v=frac(atan2(q.y,q.x)/6.283185307+.5);
    value=pow(saturate(v),1/max(node.extra0.x,.05)).xxxx;break;}
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_172)
case 172:{float2 delta=node.parameters.zw-node.parameters.xy,q=(node.meta.y>=0?a.xy:uv)-node.parameters.xy;float t=dot(q,delta)/max(dot(delta,delta),1e-8);
    t=node.extra0.w>.5?frac(t):saturate(t);value=lerp(node.extra0.x,node.extra0.y,pow(t,1/max(node.extra0.z,.05))).xxxx;break;}
#endif

#if !defined(SPECIALIZED_NODES) || defined(NODE_186)
case 186:value=fieldAt((int)node.reserved.x+3,(float2(p)+.5)/outputSettings.y);break;
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_187) || defined(NODE_190)
case 187:case 190:value=fieldAt((int)node.reserved.x+2,(float2(p)+.5)/outputSettings.y);break;
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_188) || defined(NODE_189)
case 188:case 189:value=fieldAt((int)node.reserved.x+1,(float2(p)+.5)/outputSettings.y);break;
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_191)
case 191:value=fieldAt((int)node.reserved.x,(float2(p)+.5)/outputSettings.y);break;
#endif
