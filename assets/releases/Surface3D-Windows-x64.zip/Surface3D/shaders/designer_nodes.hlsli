// Point operators only. Dense spatial sampling belongs to designer_spatial.hlsl,
// avoiding repeated 16-resource sampling branches inside the graph interpreter.
float dLuma(float3 c){return dot(c,float3(.2126,.7152,.0722));}
float2 dRotate2(float2 v,float angle){float c=cos(angle),s=sin(angle);return float2(c*v.x-s*v.y,s*v.x+c*v.y);}
float3 dPanoramaDirection(float2 uv){float a=(uv.x-.5)*6.283185307,t=uv.y*3.141592654;return float3(cos(a)*sin(t),cos(t),sin(a)*sin(t));}
float3 dMetalColor(int metal){
    if(metal==0)return float3(1,.766,.336);if(metal==1)return float3(.972,.960,.915);
    if(metal==2)return float3(.913,.922,.924);if(metal==3)return float3(.560,.570,.580);
    if(metal==4)return float3(.955,.638,.538);if(metal==5)return float3(.542,.497,.449);
    if(metal==6)return float3(.660,.609,.526);if(metal==7)return float3(.662,.655,.634);
    return float3(.673,.637,.585);
}
float dDielectricF0(int preset,float range,float ior){
    if(preset==11){float f=(ior-1)/(ior+1);return f*f;}
    float2 limits=float2(.03,.05);
    if(preset==1)limits=float2(.02,.04);if(preset==2)limits=float2(.02,.05);
    if(preset==3)limits=float2(.02,.04);if(preset==4)limits=float2(.03,.05);
    if(preset==5)limits=float2(.02,.05);if(preset==6)limits=float2(.02,.04);
    if(preset==7)limits=float2(.04,.08);if(preset==8)limits=.02037;
    if(preset==9)limits=.018;if(preset==10)limits=.04;
    return lerp(limits.x,limits.y,saturate(range));
}
