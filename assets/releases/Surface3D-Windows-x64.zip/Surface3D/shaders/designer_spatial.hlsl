Texture2D<float4> source:register(t0),rotationMap:register(t1),pivotMap:register(t2);
Texture2D<float4> previous:register(t3);
RWTexture2D<float4> result:register(u0);
cbuffer Settings:register(b0){uint4 info,config;float4 parameters,extra0,extra1;};
// info: operator, mode, output type, first-input conversion. config: size, fill wrap, input flags.
float3 unit(float3 v){return dot(v,v)>1e-12?normalize(v):float3(0,0,1);}
float4 convertInput(float4 v){
    if(info.w==1)return dot(v.rgb,float3(.2126,.7152,.0722)).xxxx;
    if(info.w==2)return v.xxxx;
    if(info.w==5)return float4(unit(v.rgb*2-1),0);
    if(info.w==6)return float4(unit(v.xyz),0);
    return v;
}
int boundary(int x,int mode){int size=(int)config.x;if(mode==1)return clamp(x,0,size-1);int period=mode==2?2*size:size;x=(x%period+period)%period;return mode==2&&x>=size?2*size-1-x:x;}
float4 at(int2 p,int wrap){if(wrap==3&&(any(p<0)||any(p>=(int)config.x)))return 0;return source[int2(boundary(p.x,wrap),boundary(p.y,wrap))];}
float4 tap(int2 p,int wrap){float4 v=at(p,wrap);if(info.z==1)v.rgb*=v.a;return v;}
float4 premul(float2 q,int wrap){float2 pixel=q*config.x-.5,f=frac(pixel);int2 p=(int2)floor(pixel);return lerp(lerp(tap(p,wrap),tap(p+int2(1,0),wrap),f.x),lerp(tap(p+int2(0,1),wrap),tap(p+1,wrap),f.x),f.y);}
float4 sample(float2 q,int wrap,int filtering){float4 v=filtering==0?tap((int2)floor(q*config.x),wrap):premul(q,wrap);if(info.z==1)v.rgb=v.a>1e-8?v.rgb/v.a:0;return v;}
float2 rotate2(float2 p,float a){float c=cos(a),s=sin(a);return float2(c*p.x-s*p.y,s*p.x+c*p.y);}
float randomSeed(float2 p,float seed){return frac(sin(dot(p,float2(127.1,311.7))+seed*37.719)*43758.5453);}
float cross2(float2 a,float2 b){return a.x*b.y-a.y*b.x;}
float3 direction(float2 q){float a=(q.x-.5)*6.283185307,t=q.y*3.141592654;return float3(cos(a)*sin(t),cos(t),sin(a)*sin(t));}
float2 panoramaUV(float3 v){v=unit(v);return float2(atan2(v.z,v.x)/6.283185307+.5,acos(clamp(v.y,-1,1))/3.141592654);}
float3 rotate3(float3 p,float3 r){float3 c=cos(r),s=sin(r);p=float3(p.x,c.x*p.y-s.x*p.z,s.x*p.y+c.x*p.z);p=float3(c.y*p.x+s.y*p.z,p.y,-s.y*p.x+c.y*p.z);return float3(c.z*p.x-s.z*p.y,s.z*p.x+c.z*p.y,p.z);}
bool quadCandidate(float2 p,float2 b,float2 c,float2 d,float u,out float2 uv,out float facing){float2 axis=c+d*u;float length2=dot(axis,axis);float v=dot(p-b*u,axis)/max(length2,1e-12);uv=float2(u,v);facing=cross2(b+d*v,c+d*u);bool visible=info.y==0?facing>1e-8:info.y==1?facing<-1e-8:abs(facing)>1e-8;return length2>1e-12&&visible&&length(p-b*u-c*v-d*u*v)<1e-3;}
float4 quad(float2 p){
    p-=parameters.xy;float2 b=parameters.zw-parameters.xy,c=extra0.xy-parameters.xy,d=extra0.zw-parameters.zw-extra0.xy+parameters.xy;
    float a=-cross2(b,d),bb=cross2(p,d)-cross2(b,c),cc=cross2(p,c);float2 uv=0,candidate=0;float facing=0,chosen=0;bool found=false;
    if(abs(a)<1e-8){if(abs(bb)>1e-8)found=quadCandidate(p,b,c,d,-cc/bb,uv,chosen);}
    else{float discriminant=bb*bb-4*a*cc;if(discriminant>=0){[unroll]for(int root=0;root<2;root++){
        float u=(-bb+(root==0?1:-1)*sqrt(discriminant))/(2*a);
        if(quadCandidate(p,b,c,d,u,candidate,facing)){bool inside=all(candidate>=0)&&all(candidate<=1),oldInside=all(uv>=0)&&all(uv<=1);bool priority=info.y==2?facing>chosen:info.y==3?facing<chosen:false;
            if(!found||(inside&&!oldInside)||(inside==oldInside&&priority)){uv=candidate;chosen=facing;found=true;}}
    }}}
    if(!found)return info.z==1?float4(extra1.z.xxx,0):extra1.z.xxxx;
    return sample(uv,(int)extra1.x,(int)extra1.y);
}
float4 normalOrHeight(int2 p){return convertInput(at(p,(int)config.y));}
float luma(float4 v){float3 c=info.z==1?lerp(12.92*max(v.rgb,0),1.055*pow(max(v.rgb,0),1/2.4)-.055,step(.0031308,v.rgb)):v.xxx;return dot(c,float3(.2126,.7152,.0722));}
float4 fxaa(float2 q){
    float2 pixel=1.0/config.xx;int wrap=(int)config.y;
    float4 m=premul(q,wrap),n=premul(q-float2(0,pixel.y),wrap),s=premul(q+float2(0,pixel.y),wrap),w=premul(q-float2(pixel.x,0),wrap),e=premul(q+float2(pixel.x,0),wrap);
    float lm=luma(m),ln=luma(n),ls=luma(s),lw=luma(w),le=luma(e);
    float lo=min(lm,min(min(ln,ls),min(lw,le))),hi=max(lm,max(max(ln,ls),max(lw,le))),range=hi-lo;
    if(range<max(parameters.y,hi*parameters.x))return sample(q,wrap,1);
    float4 nw=premul(q-pixel,wrap),ne=premul(q+float2(pixel.x,-pixel.y),wrap),sw=premul(q+float2(-pixel.x,pixel.y),wrap),se=premul(q+pixel,wrap);
    float lnw=luma(nw),lne=luma(ne),lsw=luma(sw),lse=luma(se);
    float horizontal=abs(lnw-2*lw+lsw)+2*abs(ln-2*lm+ls)+abs(lne-2*le+lse),vertical=abs(lnw-2*ln+lne)+2*abs(lw-2*lm+le)+abs(lsw-2*ls+lse);
    bool alongX=horizontal>=vertical;float first=alongX?ln:lw,second=alongX?ls:le,signOffset=abs(first-lm)>=abs(second-lm)?-1:1;
    float average=(lm+(signOffset<0?first:second))*.5,gradient=abs((signOffset<0?first:second)-lm)*.25;
    float2 normal=alongX?float2(0,pixel.y*signOffset):float2(pixel.x*signOffset,0),along=alongX?float2(pixel.x,0):float2(0,pixel.y),origin=q+normal*.5;
    float left=1,right=1,endpointLeft=average,endpointRight=average;bool doneLeft=false,doneRight=false;
    [loop]for(int i=1;i<=12;i++){if(!doneLeft){left=i;endpointLeft=luma(premul(origin-along*i,wrap));doneLeft=abs(endpointLeft-average)>=gradient;}if(!doneRight){right=i;endpointRight=luma(premul(origin+along*i,wrap));doneRight=abs(endpointRight-average)>=gradient;}if(doneLeft&&doneRight)break;}
    float endpoint=left<right?endpointLeft:endpointRight,shift=(endpoint-average)*(lm-average)<0?.5-min(left,right)/max(left+right,1):0;
    float subpixel=saturate((abs((ln+ls+lw+le)*.25-lm)/max(range,1e-8)-.25)/.75)*parameters.z;
    float4 v=lerp(premul(q+normal*shift,wrap),(m+n+s+w+e+nw+ne+sw+se)/9,subpixel);if(info.z==1)v.rgb=v.a>1e-8?v.rgb/v.a:0;if(info.z==5)v=float4(unit(v.xyz),0);return v;
}
[numthreads(8,8,1)]void process(uint3 p:SV_DispatchThreadID){if(any(p.xy>=config.x))return;float2 q=(float2(p.xy)+.5)/config.x;float4 value=0;
#if OPERATOR==151
    float2 uv;if(info.y==0){float2 d=q-parameters.xy;uv=float2(frac(atan2(d.y,d.x)/6.283185307+.5-parameters.w),length(d)/parameters.z);}else{float a=(q.x-.5+parameters.w)*6.283185307;uv=parameters.xy+float2(cos(a),sin(a))*q.y*parameters.z;}value=sample(uv,(int)extra0.x,(int)extra0.y);
#elif OPERATOR==152
    float2 pivot=(config.z&4)!=0?pivotMap[p.xy].xy:parameters.zw;float rotation=(config.z&2)!=0?rotationMap[p.xy].x:0;float a=(rotation*parameters.x+parameters.y)*6.283185307;value=sample(pivot+rotate2(q-pivot,-a),(int)extra0.x,(int)extra0.y);
#elif OPERATOR==153
    value=quad(q);
#elif OPERATOR==160 || OPERATOR==161
    bool sobel=OPERATOR==161||info.y==1;float2 gradient=0;
    if(sobel){[unroll]for(int i=-1;i<=1;i++){float w=i==0?2:1;gradient.x+=w*(normalOrHeight(int2(p.xy)+int2(1,i)).x-normalOrHeight(int2(p.xy)+int2(-1,i)).x);gradient.y+=w*(normalOrHeight(int2(p.xy)+int2(i,1)).x-normalOrHeight(int2(p.xy)+int2(i,-1)).x);}gradient*=config.x/8.0;}
    else gradient=float2(normalOrHeight(int2(p.xy)+int2(1,0)).x-normalOrHeight(int2(p.xy)-int2(1,0)).x,normalOrHeight(int2(p.xy)+int2(0,1)).x-normalOrHeight(int2(p.xy)-int2(0,1)).x)*config.x/2.0;
    gradient*=OPERATOR==160?parameters.z*parameters.w/max(parameters.xy,1e-4):parameters.xx;value=float4(unit(float3(-gradient,1)),0);
#elif OPERATOR==162
    float2 step=parameters.y/config.xx;float divergence=0;
    [unroll]for(int i=-1;i<=1;i++){if(info.y==0&&i!=0)continue;float w=info.y==1?(i==0?2:1):1;
        divergence+=w*(convertInput(sample(q+float2(step.x,i*step.y),(int)config.y,1)).x-convertInput(sample(q+float2(-step.x,i*step.y),(int)config.y,1)).x+
                       convertInput(sample(q+float2(i*step.x,step.y),(int)config.y,1)).y-convertInput(sample(q+float2(i*step.x,-step.y),(int)config.y,1)).y);}
    float curvature=divergence*config.x/((info.y==1?8:2)*parameters.y)*parameters.x*.25;value=float4(saturate(.5+curvature),saturate(curvature*2),saturate(-curvature*2),0);
#elif OPERATOR==163
    float a=parameters.z*.01745329252;float2 uv=rotate2(q-.5,-a)/parameters.xy+.5+extra0.xy;float3 n=convertInput(sample(uv,(int)extra0.w,(int)extra0.z)).xyz;n.xy=rotate2(n.xy/parameters.xy,a);value=float4(unit(n),0);
#elif OPERATOR==165
    value=fxaa(q);
#elif OPERATOR==169 || OPERATOR==170
    float3 dir=direction(q);if(OPERATOR==169)dir=rotate3(dir,parameters.yxz*.01745329252);else{float2 uv=rotate2(q-.5,parameters.y*6.283185307)/parameters.x;dir=float3(uv.x,-1,uv.y);}float2 uv=panoramaUV(dir);uv.x=frac(uv.x);uv.y=clamp(uv.y,.5/config.x,1-.5/config.x);value=sample(uv,0,1);
#elif OPERATOR==173
    q=((config.z&1)!=0?source[p.xy].xy:q)-extra0.xy;
    float angle=frac(atan2(q.y,q.x)/6.283185307+.5+extra0.z)*parameters.x,ray=floor(angle),nearest=1e5;
    [unroll]for(int i=-1;i<=1;i++){float id=ray+i,period=max(1,round(parameters.x));float index=fmod(fmod(id,period)+period,period);float center=id+.5+(randomSeed(float2(index,0),parameters.w)-.5)*parameters.z;nearest=min(nearest,abs(angle-center));}
    float aa=1.0/max(config.x*max(length(q),.01),1),mask=1-smoothstep(parameters.y*.5,parameters.y*.5+aa,nearest);
    value=(mask*exp(-length(q)*extra0.w)).xxxx;
#elif OPERATOR==186
    bool seed=(config.z&2)==0 || rotationMap[p.xy].x>=.5;
    if(config.w==0 || seed){value=seed || parameters.x<.5?convertInput(source[p.xy]):0;}
    else {
        int stride=max(1,(int)round(parameters.y*config.x/max(parameters.x,1)));
        int2 pixel=int2(p.xy);
        int2 offsets[4]={int2(stride,0),int2(-stride,0),int2(0,stride),int2(0,-stride)};
        float4 sum=0;
        [unroll]for(int i=0;i<4;i++) {
            int2 at=pixel+offsets[i];at=int2(boundary(at.x,(int)config.y),boundary(at.y,(int)config.y));
            float4 sample=previous[at];if(info.z==1)sample.rgb*=sample.a;sum+=sample;
        }
        sum*=.25;if(info.z==1)sum.rgb=sum.a>1e-8?sum.rgb/sum.a:0;
        float intensity=parameters.z*((config.z&4)!=0?saturate(pivotMap[p.xy].x):1);
        value=lerp(previous[p.xy],sum,intensity);
    }
#elif OPERATOR==187
    float2 warped=q;int count=clamp((int)round(parameters.x),0,16);
    int wrap=(int)config.y;
    [loop]for(int step=0;step<count;step++) {
        int2 at=int2(floor(warped*config.x));
        int2 l=int2(boundary(at.x-1,wrap),boundary(at.y,wrap)),r=int2(boundary(at.x+1,wrap),boundary(at.y,wrap));
        int2 u=int2(boundary(at.x,wrap),boundary(at.y-1,wrap)),d=int2(boundary(at.x,wrap),boundary(at.y+1,wrap));
        float2 gradient=float2(rotationMap[r].x-rotationMap[l].x,rotationMap[d].x-rotationMap[u].x);
        warped+=gradient*parameters.y/max(count,1);
    }
    value=sample(warped,wrap,1);
#elif OPERATOR==188
    float4 src=source[p.xy],blurred=rotationMap[p.xy];
    float luminance=dot(blurred.rgb,float3(.2126,.7152,.0722));
    float strength=parameters.y*(parameters.z<=0?1:saturate((luminance-parameters.z)/max(.0001,luminance)));
    value=float4(src.rgb+blurred.rgb*strength,src.a);
#elif OPERATOR==189
    float v=(dot(source[p.xy].rgb,float3(.2126,.7152,.0722))-dot(rotationMap[p.xy].rgb,float3(.2126,.7152,.0722)))*parameters.y;
    value=(v+(info.y==0?.5:0)).xxxx;
#elif OPERATOR==190
    float4 src=source[p.xy];int level=clamp((int)round(parameters.x),2,16),cube=level*level,side=level*level*level;
    float3 coord=saturate(src.rgb)*(cube-1),fraction=frac(coord);int3 lower=int3(floor(coord));float3 mapped=0;
    [unroll]for(int z=0;z<2;z++)[unroll]for(int y=0;y<2;y++)[unroll]for(int x=0;x<2;x++) {
        int3 cell=min(lower+int3(x,y,z),cube-1);int index=cell.x+cell.y*cube+cell.z*cube*cube;
        float2 uv=(float2(index%side,index/side)+.5)/side;
        int2 pixel=min(int2(uv*config.x),(int)config.x-1);
        float weight=(x?fraction.x:1-fraction.x)*(y?fraction.y:1-fraction.y)*(z?fraction.z:1-fraction.z);
        mapped+=rotationMap[pixel].rgb*weight;
    }
    value=float4(lerp(src.rgb,mapped,parameters.y),src.a);
#elif OPERATOR==174
    float period=max(1,round(parameters.x));q=((config.z&1)!=0?source[p.xy].xy:q)*period;float2 cell=floor(q);float maskResult=0;
    [loop]for(int y=-2;y<=2;y++)[loop]for(int x=-2;x<=2;x++){
        float2 c=cell+float2(x,y),id=fmod(fmod(c,period)+period,period);float seed=parameters.y;
        if(randomSeed(id+41,seed)>extra1.x)continue;
        float2 center=c+.5+(float2(randomSeed(id,seed),randomSeed(id+29,seed))-.5)*extra0.z;
        float segmentLength=parameters.z*lerp(1-extra0.w,1,randomSeed(id+83,seed));
        float angle=extra0.x*.01745329252+(randomSeed(id+57,seed)-.5)*extra0.y*6.283185307;
        float2 local=rotate2(q-center,-angle);float distance=length(float2(max(abs(local.x)-segmentLength*.5,0),local.y));
        float mask=1-smoothstep(parameters.w*.5,parameters.w*.5+period/config.x,distance);maskResult=max(maskResult,mask);
    }value=maskResult.xxxx;
#endif
    result[p.xy]=value;
}
