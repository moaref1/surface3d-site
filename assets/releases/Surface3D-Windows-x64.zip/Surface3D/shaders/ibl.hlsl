// Original split-sum GGX integration. Input and filtered lighting remain scene-linear Rec.709.
Texture2D<float4> sourceEnvironment:register(t0);
RWTexture2D<float4> filteredEnvironment:register(u0);
SamplerState environmentSampler:register(s0);
cbuffer IblData:register(b0){float4 filterSettings;}; // roughness, mode, source width, source height
static const float PI=3.14159265359;
float radical(uint bits){bits=(bits<<16)|(bits>>16);bits=((bits&0x55555555)<<1)|((bits&0xAAAAAAAA)>>1);bits=((bits&0x33333333)<<2)|((bits&0xCCCCCCCC)>>2);bits=((bits&0x0F0F0F0F)<<4)|((bits&0xF0F0F0F0)>>4);bits=((bits&0x00FF00FF)<<8)|((bits&0xFF00FF00)>>8);return float(bits)*2.3283064365386963e-10;}
float3 basis(float3 h,float3 n){float3 t=normalize(cross(abs(n.z)<.999?float3(0,0,1):float3(1,0,0),n));return normalize(t*h.x+cross(n,t)*h.y+n*h.z);}
float3 ggx(float2 xi,float rough,float3 n){float a=rough*rough;float phi=2*PI*xi.x,ct=sqrt((1-xi.y)/(1+(a*a-1)*xi.y)),st=sqrt(max(0,1-ct*ct));return basis(float3(cos(phi)*st,sin(phi)*st,ct),n);}
float3 radiance(float3 n,float lod){float2 uv=float2(atan2(n.z,n.x)/(2*PI)+.5,acos(clamp(n.y,-1,1))/PI);return sourceEnvironment.SampleLevel(environmentSampler,uv,lod).rgb;}
[numthreads(8,8,1)]void integrate(uint3 id:SV_DispatchThreadID){
 uint width,height;filteredEnvironment.GetDimensions(width,height);if(id.x>=width || id.y>=height)return;float2 uv=(float2(id.xy)+.5)/float2(width,height);
 if(filterSettings.y>1.5){float nv=max(.001,uv.x),rough=max(.001,uv.y);float3 v=float3(sqrt(1-nv*nv),0,nv);float2 total=0;
  for(uint i=0;i<128;i++){float3 h=ggx(float2(float(i)/128,radical(i)),rough,float3(0,0,1)),l=normalize(2*dot(v,h)*h-v);float nl=saturate(l.z),nh=saturate(h.z),vh=saturate(dot(v,h));if(nl>0){float k=rough*rough*.5;float g=(nv/(nv*(1-k)+k))*(nl/(nl*(1-k)+k));float visibility=g*vh/max(nh*nv,.0001),fc=pow(1-vh,5);total+=float2(1-fc,fc)*visibility;}}
  filteredEnvironment[id.xy]=float4(total/128,0,1);return;
 }
 float phi=(uv.x-.5)*2*PI,theta=uv.y*PI;float3 n=float3(cos(phi)*sin(theta),cos(theta),sin(phi)*sin(theta));float3 result=0;float weight=0;
 for(uint j=0;j<64;j++){float2 xi=float2(float(j)/64,radical(j));float3 l;
  if(filterSettings.y>.5){float r=sqrt(xi.x),p=xi.y*2*PI;l=basis(float3(r*cos(p),r*sin(p),sqrt(1-xi.x)),n);result+=radiance(l,2);weight+=1;}
  else {float3 h=ggx(xi,max(.001,filterSettings.x),n);l=normalize(2*dot(n,h)*h-n);float nl=saturate(dot(n,l));if(nl>0){float nh=saturate(dot(n,h)),a=filterSettings.x*filterSettings.x;float d=a*a/(PI*pow(nh*nh*(a*a-1)+1,2));float pdf=max(.0001,d*.25);float sampleArea=1/(64*pdf),texelArea=4*PI/(filterSettings.z*filterSettings.w);float lod=filterSettings.x<.01?0:max(0,.5*log2(sampleArea/texelArea));result+=radiance(l,lod)*nl;weight+=nl;}}
 }filteredEnvironment[id.xy]=float4(result/max(weight,.0001),1);
}
