cbuffer DisplacementData:register(b7){float4 displacementSettings;};
Texture2D<float4> albedo:register(t0);Texture2D<float4> properties:register(t1);SamplerState textureSampler:register(s0);
Texture2D<float> selectedMask:register(t2);
Texture2D<float4> surfaceDetail:register(t3);Texture2D<float4> surfaceEmission:register(t4);Texture2D<float4> surfaceUtility:register(t5);
float3 finalSurfaceNormal(float2 uv,float3 base){
 uint w,h;surfaceDetail.GetDimensions(w,h);float2 stepUV=1.0/float2(w,h),lo=stepUV*.5,hi=1-lo;
 float hx=surfaceDetail.SampleLevel(textureSampler,clamp(uv+float2(stepUV.x,0),lo,hi),0).w-surfaceDetail.SampleLevel(textureSampler,clamp(uv-float2(stepUV.x,0),lo,hi),0).w;
 float hy=surfaceDetail.SampleLevel(textureSampler,clamp(uv+float2(0,stepUV.y),lo,hi),0).w-surfaceDetail.SampleLevel(textureSampler,clamp(uv-float2(0,stepUV.y),lo,hi),0).w;
 float strength=displacementSettings.x>.5?displacementSettings.y:.025;return combineNormalHeight(base,float3(-hx*w*strength,-hy*h*strength,1));
}

cbuffer CameraData:register(b1) {float4 camera;float4 cameraExtra;float4 cameraScreen;float4 lighting;float4 environmentSettings;float4 projectionSettings;};
Texture2D<float4> environmentImage:register(t6);
float3 environmentRadiance(float3 n,float mip){float c=cos(lighting.w),s=sin(lighting.w);n=float3(c*n.x-s*n.z,n.y,s*n.x+c*n.z);float2 uv=float2(atan2(n.z,n.x)/6.283185+.5,acos(clamp(n.y,-1,1))/3.141593);return environmentImage.SampleLevel(textureSampler,uv,mip).rgb*environmentSettings.y;}
float3 keyDirection(){float3 v=normalize(float3(-.55,.65,.7));float c=cos(lighting.x),s=sin(lighting.x);v=float3(c*v.x-s*v.z,v.y,s*v.x+c*v.z);float cp=cos(lighting.y),sp=sin(lighting.y);return float3(v.x,cp*v.y-sp*v.z,sp*v.y+cp*v.z);}
struct MeshInput {float3 position:POSITION;float3 normal:NORMAL;float2 uv:TEXCOORD;float3 tangent:TANGENT;float3 bitangent:BINORMAL;};
struct MeshOutput {float4 position:SV_POSITION;float3 normal:NORMAL;float2 uv:TEXCOORD;float3 worldPosition:TEXCOORD1;float3 tangent:TEXCOORD2;float3 bitangent:TEXCOORD3;};
float3 rotate(float3 p) {float c=cos(camera.x),s=sin(camera.x),cp=cos(camera.y),sp=sin(camera.y);float3 q=float3(c*p.x-s*p.z,p.y,s*p.x+c*p.z);return float3(q.x,cp*q.y-sp*q.z,sp*q.y+cp*q.z);}
float3 displacedPosition(MeshInput i){if(displacementSettings.x<.5)return i.position;float h=surfaceDetail.SampleLevel(textureSampler,i.uv,0).w;return i.position+normalize(i.normal)*(h-displacementSettings.z)*displacementSettings.y;}
MeshOutput meshVertex(MeshInput i) {MeshOutput o;float3 p=rotate(objectRotate(displacedPosition(i)*objectScale.xyz)+objectTranslation.xyz);if(projectionSettings.x>.5){float w=3-p.z;o.position=float4((p.xy*camera.z*3*projectionSettings.y+cameraExtra.xy*w)*cameraScreen.xy+cameraScreen.zw*w,(w-.05)/10*w,w);}else o.position=float4((p.xy*camera.z+cameraExtra.xy)*cameraScreen.xy+cameraScreen.zw,.5-p.z*.4,1);o.normal=rotate(normalize(objectRotate(i.normal/max(objectScale.xyz,.001))));o.tangent=rotate(objectRotate(i.tangent));o.bitangent=rotate(objectRotate(i.bitangent));o.uv=i.uv;o.worldPosition=p;return o;}
float4 meshShadowVertex(MeshInput i):SV_POSITION {float3 p=rotate(objectRotate(displacedPosition(i)*objectScale.xyz)+objectTranslation.xyz);float3 c=shadowCoordinates(p,(int)renderReserved.x);return float4(c.xy,c.z*.5+.5,1);}
float3 display(float3 c){return managedDisplay(c);}
StructuredBuffer<uint> regionMembership:register(t12);
float4 meshPixelBase(MeshOutput i) {
    float3 color=albedo.Sample(textureSampler,i.uv).rgb;float2 p=properties.Sample(textureSampler,i.uv).rg;
    if(camera.w==4) {float m=cameraExtra.z>.5?saturate(selectedMask.Sample(textureSampler,i.uv)):1;
        if(cameraExtra.z>.5 && cameraExtra.w>.5)m=1-m;return float4(m,m,m,1);}
    if(camera.w==8)return float4(color,1);if(camera.w==9)return float4(color*.5+.5,1);
    float4 detail=surfaceDetail.Sample(textureSampler,i.uv),emission=surfaceEmission.Sample(textureSampler,i.uv),utility=surfaceUtility.Sample(textureSampler,i.uv);
    if(camera.w==5)return float4(finalSurfaceNormal(i.uv,detail.xyz)*.5+.5,1);if(camera.w==6)return float4((.5+detail.w*.5).xxx,1);if(camera.w==7)return float4(utility.rrr,1);
    if(camera.w==10)return float4(display(emission.rgb),1);
    if(camera.w==11)return float4(utility.ggg,1);
    clip(utility.g-.5);
    if(camera.w==1) return float4(p.rrr,1);if(camera.w==2) return float4(p.ggg,1);if(camera.w==3) return float4(display(color),1);
    float3 tangentNormal=finalSurfaceNormal(i.uv,detail.xyz);
    float3 n=normalize(i.tangent*tangentNormal.x+i.bitangent*tangentNormal.y+i.normal*tangentNormal.z);
    float3 v=normalize(float3(0,0,3)-i.worldPosition);float rough=clamp(p.x,.02,1),metal=saturate(p.y);float3 f0=lerp(.04.xxx,color,metal);
    float3 shaded=directPBR(color,rough,metal,n,v,i.worldPosition);
    shaded+=environmentPBR(color,rough,metal,n,v,lighting.w,environmentSettings.y,environmentSettings.x>.5)*utility.r;
    shaded=(shaded+emission.rgb)*exp2(lighting.z);
    if(renderView.z>.5)shaded=lerp(shaded,float3(.08,.8,.64),.25);
    return float4(display(shaded),1);
}
float4 meshPixel(MeshOutput i,uint faceID:SV_PrimitiveID):SV_TARGET {
    float4 result=meshPixelBase(i);
    uint authored=(faceID+(uint)interactionSettings.y)/(uint)max(displacementSettings.w,1);
    if(interactionSettings.x>.5 && authored<(uint)interactionSettings.z && regionMembership[authored]!=0)
        result.rgb=lerp(result.rgb,float3(.14,.88,.72),.38);
    return result;
}