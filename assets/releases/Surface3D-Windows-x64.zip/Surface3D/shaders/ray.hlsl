float3 combineNormalHeight(float3 base,float3 detail){
 base=normalize(base+float3(0,0,1e-8));detail=normalize(detail+float3(0,0,1e-8));
 float3 t=base+float3(0,0,1),u=detail*float3(-1,-1,1);
 return t.z>1e-5?normalize(t*dot(t,u)/t.z-u):normalize(base+detail-float3(0,0,1)+1e-8);
}
// Original Surface3D compute path tracer: bounded BVH traversal, GGX/Lambert BSDF,
// HDRI importance sampling with MIS, directional shadow rays and stochastic coverage.
// No proprietary renderer source; no claim of DXR or RT-core usage.
struct Vertex{float4 position,normal,uv,tangent,bitangent;};
struct Triangle{Vertex a,b,c;};
struct Branch{float3 lo;uint left;float3 hi;uint right;};
struct Alias{float chance;uint alias;float pdf,pad;};
StructuredBuffer<Branch> branches:register(t0);
StructuredBuffer<Triangle> triangles:register(t1);
Texture2D<float4> colorMaps[16]:register(t2);
Texture2D<float4> materialMaps[16]:register(t18);
Texture2D<float4> detailMaps[16]:register(t34);
Texture2D<float4> emissionMaps[16]:register(t50);
Texture2D<float4> utilityMaps[16]:register(t66);
Texture2D<float4> sky:register(t82);
StructuredBuffer<Alias> skyAlias:register(t83);
SamplerState materialSampler:register(s0),skySampler:register(s1);
RWTexture2D<float4> result:register(u0);
cbuffer Controls:register(b0){float4 imageSettings,camera,cameraExtra,skySettings,background,groundColor,quality,scene;
float4 lightDirections[8],lightColors[8],tileData,textureSizes[4],lens,unused[2];};
static const float PI=3.14159265359;
struct Surface{float3 color;float roughness;float metal;float3 normal;float height;float3 emission;float ao,alpha;};
Surface sampleSurface(uint id,float2 uv){Surface s=(Surface)0;s.normal=float3(0,0,1);s.ao=s.alpha=1;
 switch(id){
case 0:{float4 c=colorMaps[0].SampleLevel(materialSampler,uv,0),m=materialMaps[0].SampleLevel(materialSampler,uv,0),d=detailMaps[0].SampleLevel(materialSampler,uv,0),e=emissionMaps[0].SampleLevel(materialSampler,uv,0),u=utilityMaps[0].SampleLevel(materialSampler,uv,0);s.color=c.rgb;s.roughness=m.r;s.metal=m.g;s.normal=d.xyz;s.height=d.w;s.emission=e.rgb;s.ao=u.r;s.alpha=u.g;break;}
case 1:{float4 c=colorMaps[1].SampleLevel(materialSampler,uv,0),m=materialMaps[1].SampleLevel(materialSampler,uv,0),d=detailMaps[1].SampleLevel(materialSampler,uv,0),e=emissionMaps[1].SampleLevel(materialSampler,uv,0),u=utilityMaps[1].SampleLevel(materialSampler,uv,0);s.color=c.rgb;s.roughness=m.r;s.metal=m.g;s.normal=d.xyz;s.height=d.w;s.emission=e.rgb;s.ao=u.r;s.alpha=u.g;break;}
case 2:{float4 c=colorMaps[2].SampleLevel(materialSampler,uv,0),m=materialMaps[2].SampleLevel(materialSampler,uv,0),d=detailMaps[2].SampleLevel(materialSampler,uv,0),e=emissionMaps[2].SampleLevel(materialSampler,uv,0),u=utilityMaps[2].SampleLevel(materialSampler,uv,0);s.color=c.rgb;s.roughness=m.r;s.metal=m.g;s.normal=d.xyz;s.height=d.w;s.emission=e.rgb;s.ao=u.r;s.alpha=u.g;break;}
case 3:{float4 c=colorMaps[3].SampleLevel(materialSampler,uv,0),m=materialMaps[3].SampleLevel(materialSampler,uv,0),d=detailMaps[3].SampleLevel(materialSampler,uv,0),e=emissionMaps[3].SampleLevel(materialSampler,uv,0),u=utilityMaps[3].SampleLevel(materialSampler,uv,0);s.color=c.rgb;s.roughness=m.r;s.metal=m.g;s.normal=d.xyz;s.height=d.w;s.emission=e.rgb;s.ao=u.r;s.alpha=u.g;break;}
case 4:{float4 c=colorMaps[4].SampleLevel(materialSampler,uv,0),m=materialMaps[4].SampleLevel(materialSampler,uv,0),d=detailMaps[4].SampleLevel(materialSampler,uv,0),e=emissionMaps[4].SampleLevel(materialSampler,uv,0),u=utilityMaps[4].SampleLevel(materialSampler,uv,0);s.color=c.rgb;s.roughness=m.r;s.metal=m.g;s.normal=d.xyz;s.height=d.w;s.emission=e.rgb;s.ao=u.r;s.alpha=u.g;break;}
case 5:{float4 c=colorMaps[5].SampleLevel(materialSampler,uv,0),m=materialMaps[5].SampleLevel(materialSampler,uv,0),d=detailMaps[5].SampleLevel(materialSampler,uv,0),e=emissionMaps[5].SampleLevel(materialSampler,uv,0),u=utilityMaps[5].SampleLevel(materialSampler,uv,0);s.color=c.rgb;s.roughness=m.r;s.metal=m.g;s.normal=d.xyz;s.height=d.w;s.emission=e.rgb;s.ao=u.r;s.alpha=u.g;break;}
case 6:{float4 c=colorMaps[6].SampleLevel(materialSampler,uv,0),m=materialMaps[6].SampleLevel(materialSampler,uv,0),d=detailMaps[6].SampleLevel(materialSampler,uv,0),e=emissionMaps[6].SampleLevel(materialSampler,uv,0),u=utilityMaps[6].SampleLevel(materialSampler,uv,0);s.color=c.rgb;s.roughness=m.r;s.metal=m.g;s.normal=d.xyz;s.height=d.w;s.emission=e.rgb;s.ao=u.r;s.alpha=u.g;break;}
case 7:{float4 c=colorMaps[7].SampleLevel(materialSampler,uv,0),m=materialMaps[7].SampleLevel(materialSampler,uv,0),d=detailMaps[7].SampleLevel(materialSampler,uv,0),e=emissionMaps[7].SampleLevel(materialSampler,uv,0),u=utilityMaps[7].SampleLevel(materialSampler,uv,0);s.color=c.rgb;s.roughness=m.r;s.metal=m.g;s.normal=d.xyz;s.height=d.w;s.emission=e.rgb;s.ao=u.r;s.alpha=u.g;break;}
case 8:{float4 c=colorMaps[8].SampleLevel(materialSampler,uv,0),m=materialMaps[8].SampleLevel(materialSampler,uv,0),d=detailMaps[8].SampleLevel(materialSampler,uv,0),e=emissionMaps[8].SampleLevel(materialSampler,uv,0),u=utilityMaps[8].SampleLevel(materialSampler,uv,0);s.color=c.rgb;s.roughness=m.r;s.metal=m.g;s.normal=d.xyz;s.height=d.w;s.emission=e.rgb;s.ao=u.r;s.alpha=u.g;break;}
case 9:{float4 c=colorMaps[9].SampleLevel(materialSampler,uv,0),m=materialMaps[9].SampleLevel(materialSampler,uv,0),d=detailMaps[9].SampleLevel(materialSampler,uv,0),e=emissionMaps[9].SampleLevel(materialSampler,uv,0),u=utilityMaps[9].SampleLevel(materialSampler,uv,0);s.color=c.rgb;s.roughness=m.r;s.metal=m.g;s.normal=d.xyz;s.height=d.w;s.emission=e.rgb;s.ao=u.r;s.alpha=u.g;break;}
case 10:{float4 c=colorMaps[10].SampleLevel(materialSampler,uv,0),m=materialMaps[10].SampleLevel(materialSampler,uv,0),d=detailMaps[10].SampleLevel(materialSampler,uv,0),e=emissionMaps[10].SampleLevel(materialSampler,uv,0),u=utilityMaps[10].SampleLevel(materialSampler,uv,0);s.color=c.rgb;s.roughness=m.r;s.metal=m.g;s.normal=d.xyz;s.height=d.w;s.emission=e.rgb;s.ao=u.r;s.alpha=u.g;break;}
case 11:{float4 c=colorMaps[11].SampleLevel(materialSampler,uv,0),m=materialMaps[11].SampleLevel(materialSampler,uv,0),d=detailMaps[11].SampleLevel(materialSampler,uv,0),e=emissionMaps[11].SampleLevel(materialSampler,uv,0),u=utilityMaps[11].SampleLevel(materialSampler,uv,0);s.color=c.rgb;s.roughness=m.r;s.metal=m.g;s.normal=d.xyz;s.height=d.w;s.emission=e.rgb;s.ao=u.r;s.alpha=u.g;break;}
case 12:{float4 c=colorMaps[12].SampleLevel(materialSampler,uv,0),m=materialMaps[12].SampleLevel(materialSampler,uv,0),d=detailMaps[12].SampleLevel(materialSampler,uv,0),e=emissionMaps[12].SampleLevel(materialSampler,uv,0),u=utilityMaps[12].SampleLevel(materialSampler,uv,0);s.color=c.rgb;s.roughness=m.r;s.metal=m.g;s.normal=d.xyz;s.height=d.w;s.emission=e.rgb;s.ao=u.r;s.alpha=u.g;break;}
case 13:{float4 c=colorMaps[13].SampleLevel(materialSampler,uv,0),m=materialMaps[13].SampleLevel(materialSampler,uv,0),d=detailMaps[13].SampleLevel(materialSampler,uv,0),e=emissionMaps[13].SampleLevel(materialSampler,uv,0),u=utilityMaps[13].SampleLevel(materialSampler,uv,0);s.color=c.rgb;s.roughness=m.r;s.metal=m.g;s.normal=d.xyz;s.height=d.w;s.emission=e.rgb;s.ao=u.r;s.alpha=u.g;break;}
case 14:{float4 c=colorMaps[14].SampleLevel(materialSampler,uv,0),m=materialMaps[14].SampleLevel(materialSampler,uv,0),d=detailMaps[14].SampleLevel(materialSampler,uv,0),e=emissionMaps[14].SampleLevel(materialSampler,uv,0),u=utilityMaps[14].SampleLevel(materialSampler,uv,0);s.color=c.rgb;s.roughness=m.r;s.metal=m.g;s.normal=d.xyz;s.height=d.w;s.emission=e.rgb;s.ao=u.r;s.alpha=u.g;break;}
case 15:{float4 c=colorMaps[15].SampleLevel(materialSampler,uv,0),m=materialMaps[15].SampleLevel(materialSampler,uv,0),d=detailMaps[15].SampleLevel(materialSampler,uv,0),e=emissionMaps[15].SampleLevel(materialSampler,uv,0),u=utilityMaps[15].SampleLevel(materialSampler,uv,0);s.color=c.rgb;s.roughness=m.r;s.metal=m.g;s.normal=d.xyz;s.height=d.w;s.emission=e.rgb;s.ao=u.r;s.alpha=u.g;break;}
 default:s.color=groundColor.rgb;s.roughness=groundColor.w;s.normal=float3(0,1,0);break;
 }return s;}
float alphaAt(uint id,float2 uv){switch(id){
case 0:return utilityMaps[0].SampleLevel(materialSampler,uv,0).g;
case 1:return utilityMaps[1].SampleLevel(materialSampler,uv,0).g;
case 2:return utilityMaps[2].SampleLevel(materialSampler,uv,0).g;
case 3:return utilityMaps[3].SampleLevel(materialSampler,uv,0).g;
case 4:return utilityMaps[4].SampleLevel(materialSampler,uv,0).g;
case 5:return utilityMaps[5].SampleLevel(materialSampler,uv,0).g;
case 6:return utilityMaps[6].SampleLevel(materialSampler,uv,0).g;
case 7:return utilityMaps[7].SampleLevel(materialSampler,uv,0).g;
case 8:return utilityMaps[8].SampleLevel(materialSampler,uv,0).g;
case 9:return utilityMaps[9].SampleLevel(materialSampler,uv,0).g;
case 10:return utilityMaps[10].SampleLevel(materialSampler,uv,0).g;
case 11:return utilityMaps[11].SampleLevel(materialSampler,uv,0).g;
case 12:return utilityMaps[12].SampleLevel(materialSampler,uv,0).g;
case 13:return utilityMaps[13].SampleLevel(materialSampler,uv,0).g;
case 14:return utilityMaps[14].SampleLevel(materialSampler,uv,0).g;
case 15:return utilityMaps[15].SampleLevel(materialSampler,uv,0).g;
default:return 1;}}
float heightAt(uint id,float2 uv){float size=textureSizes[id/4][id%4];uv=clamp(uv,.5/size,1-.5/size);switch(id){
case 0:return detailMaps[0].SampleLevel(materialSampler,uv,0).w;
case 1:return detailMaps[1].SampleLevel(materialSampler,uv,0).w;
case 2:return detailMaps[2].SampleLevel(materialSampler,uv,0).w;
case 3:return detailMaps[3].SampleLevel(materialSampler,uv,0).w;
case 4:return detailMaps[4].SampleLevel(materialSampler,uv,0).w;
case 5:return detailMaps[5].SampleLevel(materialSampler,uv,0).w;
case 6:return detailMaps[6].SampleLevel(materialSampler,uv,0).w;
case 7:return detailMaps[7].SampleLevel(materialSampler,uv,0).w;
case 8:return detailMaps[8].SampleLevel(materialSampler,uv,0).w;
case 9:return detailMaps[9].SampleLevel(materialSampler,uv,0).w;
case 10:return detailMaps[10].SampleLevel(materialSampler,uv,0).w;
case 11:return detailMaps[11].SampleLevel(materialSampler,uv,0).w;
case 12:return detailMaps[12].SampleLevel(materialSampler,uv,0).w;
case 13:return detailMaps[13].SampleLevel(materialSampler,uv,0).w;
case 14:return detailMaps[14].SampleLevel(materialSampler,uv,0).w;
case 15:return detailMaps[15].SampleLevel(materialSampler,uv,0).w;
 default:return 0;}}
uint hash(uint x){x^=x>>16;x*=0x7feb352du;x^=x>>15;x*=0x846ca68bu;return x^(x>>16);}
float random(inout uint state){state=hash(state+0x9e3779b9u);return (state>>8)*(1.0/16777216.0);}
float3 inverseCamera(float3 p){float c=cos(camera.x),s=sin(camera.x),cp=cos(camera.y),sp=sin(camera.y);
 p=float3(p.x,cp*p.y+sp*p.z,-sp*p.y+cp*p.z);return float3(c*p.x+s*p.z,p.y,-s*p.x+c*p.z);}
float2 skyUV(float3 d){float c=cos(skySettings.x),s=sin(skySettings.x);d=float3(c*d.x-s*d.z,d.y,s*d.x+c*d.z);
 return float2(frac(atan2(d.z,d.x)/(2*PI)+.5),acos(clamp(d.y,-1,1))/PI);}
float3 skyRadiance(float3 d){return max(0,sky.SampleLevel(skySampler,skyUV(d),0).rgb)*skySettings.y;}
float skyPDF(float3 d){uint2 p=min(uint2(skyUV(d)*quality.xy),uint2(quality.xy)-1);return skyAlias[p.y*(uint)quality.x+p.x].pdf;}
float3 sampleSky(inout uint rng,out float pdf){uint count=(uint)(quality.x*quality.y),cell=min((uint)(random(rng)*count),count-1);
 Alias a=skyAlias[cell];if(random(rng)>a.chance)cell=a.alias;pdf=skyAlias[cell].pdf;
 uint x=cell%(uint)quality.x,y=cell/(uint)quality.x;
 float phi=((x+random(rng))/quality.x-.5)*2*PI,cy=lerp(cos(PI*y/quality.y),cos(PI*(y+1)/quality.y),random(rng)),sy=sqrt(max(0,1-cy*cy));
 float3 d=float3(sy*cos(phi),cy,sy*sin(phi));float c=cos(skySettings.x),s=sin(skySettings.x);return float3(c*d.x+s*d.z,d.y,-s*d.x+c*d.z);}
bool box(float3 origin,float3 direction,Branch b,float limit){float nearT=0,farT=limit;
 [unroll]for(int k=0;k<3;++k){if(abs(direction[k])<1e-20){if(origin[k]<b.lo[k]||origin[k]>b.hi[k])return false;}
 else{float a=(b.lo[k]-origin[k])/direction[k],c=(b.hi[k]-origin[k])/direction[k];nearT=max(nearT,min(a,c));farT=min(farT,max(a,c));}}
 return farT>=nearT;}
struct Hit{uint id;float distance;float2 bary;};
bool intersect(float3 origin,float3 direction,Triangle tri,float low,float high,out float distance,out float2 bary){
 distance=high;bary=0;int kz=abs(direction.x)>abs(direction.y)?0:1;if(abs(direction.z)>abs(direction[kz]))kz=2;int kx=(kz+1)%3,ky=(kx+1)%3;if(direction[kz]<0){int swap=kx;kx=ky;ky=swap;}
 float sx=direction[kx]/direction[kz],sy=direction[ky]/direction[kz],sz=1/direction[kz];
 float3 a=tri.a.position.xyz-origin,b=tri.b.position.xyz-origin,c=tri.c.position.xyz-origin;
 precise float ax=a[kx]-sx*a[kz],ay=a[ky]-sy*a[kz],bx=b[kx]-sx*b[kz],by=b[ky]-sy*b[kz],cx=c[kx]-sx*c[kz],cy=c[ky]-sy*c[kz];
 precise float e0=bx*cy-by*cx,e1=cx*ay-cy*ax,e2=ax*by-ay*bx;
 if((e0<0||e1<0||e2<0)&&(e0>0||e1>0||e2>0))return false;
 float det=e0+e1+e2;if(abs(det)<1e-25)return false;
 float t=(e0*a[kz]+e1*b[kz]+e2*c[kz])*sz/det;if(t<low||t>high)return false;distance=t;bary=float2(e1,e2)/det;return true;}
bool trace(float3 origin,float3 direction,float low,float high,out Hit hit){hit.id=0xffffffffu;hit.distance=high;hit.bary=0;
 uint stack[64],top=1;stack[0]=0;
 [loop]while(top){uint id=stack[--top];Branch b=branches[id];if(!box(origin,direction,b,hit.distance))continue;
 if(b.right&0x80000000u){uint count=b.right&0x7fffffffu;[loop]for(uint j=0;j<count;++j){float t;float2 bary;
  if(intersect(origin,direction,triangles[b.left+j],low,hit.distance,t,bary)){hit.id=b.left+j;hit.distance=t;hit.bary=bary;}}}
 else{if(top>61)return false;stack[top++]=b.right;stack[top++]=b.left;}}
 return hit.id!=0xffffffffu;}
float2 hitUV(Hit h){Triangle t=triangles[h.id];return t.a.uv.xy*(1-h.bary.x-h.bary.y)+t.b.uv.xy*h.bary.x+t.c.uv.xy*h.bary.y;}
float shadow(float3 p,float3 d){float visibility=1,low=cameraExtra.w;
 [loop]for(int j=0;j<16;++j){Hit h;if(!trace(p,d,low,1e30,h))return visibility;
 Triangle t=triangles[h.id];float opacity=alphaAt((uint)t.a.uv.z,hitUV(h));visibility*=1-saturate(opacity);if(visibility<.001)return 0;low=h.distance+cameraExtra.w;}
 return 0;}
float3 faceNormal(Triangle t){return normalize(cross(t.b.position.xyz-t.a.position.xyz,t.c.position.xyz-t.a.position.xyz));}
Surface surfaceAt(Hit h,float3 direction,out float3 geometric){Triangle t=triangles[h.id];float3 w=float3(1-h.bary.x-h.bary.y,h.bary.x,h.bary.y);
 uint id=(uint)t.a.uv.z;float2 uv=hitUV(h);Surface s=sampleSurface(id,uv);geometric=faceNormal(t);if(dot(geometric,direction)>0)geometric=-geometric;
 if(id<16){float3 normal=t.a.normal.xyz*w.x+t.b.normal.xyz*w.y+t.c.normal.xyz*w.z;
  float3 tangent=t.a.tangent.xyz*w.x+t.b.tangent.xyz*w.y+t.c.tangent.xyz*w.z,bitangent=t.a.bitangent.xyz*w.x+t.b.bitangent.xyz*w.y+t.c.bitangent.xyz*w.z;
  float size=textureSizes[id/4][id%4],step=1/max(size,1);
  float hx=heightAt(id,uv+float2(step,0))-heightAt(id,uv-float2(step,0)),hy=heightAt(id,uv+float2(0,step))-heightAt(id,uv-float2(0,step));
  float3 nt=combineNormalHeight(s.normal,float3(-hx*size*.025,-hy*size*.025,1));
  s.normal=normalize(tangent*nt.x+bitangent*nt.y+normal*nt.z);
 }else s.normal=geometric;
 if(dot(s.normal,geometric)<0)s.normal=-s.normal;
 if(dot(s.normal,-direction)<=.001)s.normal=geometric;
 s.color=max(s.color,0);s.roughness=clamp(s.roughness,.02,1);s.metal=saturate(s.metal);return s;}
float3 basisDirection(float3 n,float3 q){float3 t=normalize(cross(abs(n.z)<.999?float3(0,0,1):float3(0,1,0),n));return t*q.x+cross(n,t)*q.y+n*q.z;}
float3 fresnel(float vh,float3 f0){return f0+(1-f0)*pow(1-saturate(vh),5);}
float specProbability(Surface s){return clamp(.25+.7*s.metal,.1,.95);}
float distribution(float nh,float a2){float q=nh*nh*(a2-1)+1;return a2/(PI*q*q);}
float maskTerm(float nv,float a2){return 2*nv/max(nv+sqrt(a2+(1-a2)*nv*nv),1e-8);}
float3 bsdf(Surface s,float3 v,float3 l,out float pdf){pdf=0;float nv=dot(s.normal,v),nl=dot(s.normal,l);if(nv<=0||nl<=0)return 0;
 float3 sum=v+l;if(dot(sum,sum)<1e-12)return 0;float3 h=normalize(sum);float nh=max(dot(s.normal,h),0),vh=max(dot(v,h),1e-8),alpha=s.roughness*s.roughness,a2=alpha*alpha;
 float d=distribution(nh,a2),g=maskTerm(nv,a2)*maskTerm(nl,a2);float3 f=fresnel(vh,lerp(.04.xxx,s.color,s.metal));
 float p=specProbability(s);pdf=(1-p)*nl/PI+p*d*nh/(4*vh);
 return (1-f)*(1-s.metal)*s.color/PI+f*d*g/max(4*nv*nl,1e-8);}
float3 sampleBSDF(Surface s,float3 v,inout uint rng,out float3 weight,out float pdf){float3 l;
 if(random(rng)<specProbability(s)){float a=s.roughness*s.roughness,u=random(rng),phi=random(rng)*2*PI;
  float z=sqrt((1-u)/max(1+(a*a-1)*u,1e-8)),r=sqrt(max(0,1-z*z));float3 h=basisDirection(s.normal,float3(r*cos(phi),r*sin(phi),z));l=reflect(-v,h);
 }else{float r=sqrt(random(rng)),phi=random(rng)*2*PI;l=basisDirection(s.normal,float3(r*cos(phi),r*sin(phi),sqrt(max(0,1-r*r))));}
 float3 f=bsdf(s,v,l,pdf);weight=pdf>1e-12?f*max(dot(s.normal,l),0)/pdf:0;return normalize(l);}
float powerWeight(float a,float b){return a*a/max(a*a+b*b,1e-20);}
float3 clampRadiance(float3 c,uint bounce){float limit=bounce==0?quality.z:quality.w;return limit>0?c*min(1,limit/max(max(c.x,c.y),max(c.z,1e-8))):c;}
float4 path(float3 origin,float3 direction,inout uint rng){float3 throughput=1,radiance=0;float primaryAlpha=0,previousPDF=0;
 [loop]for(uint bounce=0;bounce<(uint)imageSettings.z;++bounce){Hit h;bool found=false;float low=cameraExtra.w;
  [loop]for(uint skip=0;skip<16;++skip){if(!trace(origin,direction,low,1e30,h))break;
   Triangle tri=triangles[h.id];float alpha=alphaAt((uint)tri.a.uv.z,hitUV(h));
   if(random(rng)<saturate(alpha)){found=true;break;}low=h.distance+cameraExtra.w;}
  if(!found){if(bounce==0){radiance=background.w>.5?0:(skySettings.w>.5?skyRadiance(direction):background.rgb);}
   else radiance+=clampRadiance(throughput*skyRadiance(direction)*powerWeight(previousPDF,skyPDF(direction)),bounce);break;}
  if(bounce==0)primaryAlpha=1;
  float3 geometric;Surface s=surfaceAt(h,direction,geometric);float3 p=origin+direction*h.distance,v=-direction;
  if(imageSettings.w>0){float3 value=0;switch((uint)imageSettings.w){case 1:value=s.color;break;case 2:value=s.roughness.xxx;break;case 3:value=s.metal.xxx;break;case 4:value=sampleSurface((uint)triangles[h.id].a.uv.z,hitUV(h)).normal*.5+.5;break;case 5:value=(.5+s.height*.5).xxx;break;case 6:value=s.ao.xxx;break;case 7:value=s.emission;break;}
   return float4(value,primaryAlpha);}
  radiance+=clampRadiance(throughput*s.emission,bounce);
  float offset=max(cameraExtra.w,1e-6*max(1,max(abs(p.x),max(abs(p.y),abs(p.z)))));float3 start=p+geometric*offset;
  [loop]for(uint light=0;light<(uint)scene.x;++light){float3 l=lightDirections[light].xyz;float intensity=lightDirections[light].w;if(intensity<=0)continue;
   float pdf;float3 f=bsdf(s,v,l,pdf);float visibility=lightColors[light].w>.5?shadow(start,l):1;
   radiance+=clampRadiance(throughput*f*max(dot(s.normal,l),0)*lightColors[light].rgb*intensity*PI*visibility,bounce);}
  if(skySettings.y>0){float envPDF;float3 l=sampleSky(rng,envPDF);float bsdfPDF;float3 f=bsdf(s,v,l,bsdfPDF);
   if(envPDF>1e-12&&dot(s.normal,l)>0)radiance+=clampRadiance(throughput*f*max(dot(s.normal,l),0)*skyRadiance(l)*shadow(start,l)*(bounce+1<(uint)imageSettings.z?powerWeight(envPDF,bsdfPDF):1)/envPDF,bounce);}
  if(bounce+1>=(uint)imageSettings.z)break;
  float3 weight;direction=sampleBSDF(s,v,rng,weight,previousPDF);if(any(isnan(weight))||max(weight.x,max(weight.y,weight.z))<=0)break;
  throughput*=weight;origin=p+geometric*(dot(geometric,direction)>0?offset:-offset);
  if(bounce>=2){float survive=min(.95,max(throughput.x,max(throughput.y,throughput.z)));if(random(rng)>survive)break;throughput/=max(survive,1e-8);}
 }
 return float4(radiance*skySettings.z,primaryAlpha);}
[numthreads(8,8,1)]void traceImage(uint3 tid:SV_DispatchThreadID){if(any(tid.xy>=(uint2)tileData.zz))return;uint2 p=tid.xy+(uint2)tileData.xy;if(any(p>=(uint2)imageSettings.xy))return;
 uint rng=hash(p.x+p.y*(uint)imageSettings.x+hash((uint)tileData.w+hash((uint)scene.y)));
 float2 jitter=float2(random(rng),random(rng));float scale=min(imageSettings.x*.4,imageSettings.y*.38);
 float nx=(p.x+jitter.x-imageSettings.x*.5)/scale-cameraExtra.x,ny=-(p.y+jitter.y-imageSettings.y*.49)/scale-cameraExtra.y;
 float3 origin=float3(0,0,3),direction=float3(0,0,-1);
 if(camera.w>.5){float focal=3*.414213562/tan(cameraExtra.z*.00872664626);direction=normalize(float3(nx/(camera.z*focal),ny/(camera.z*focal),-1));}
 else origin.xy=float2(nx,ny)/camera.z;
 if(lens.x>.5 && camera.w>.5){
    float3 target=origin+direction*(lens.y/max(-direction.z,1e-6));
    float radius=(.036/(2*tan(cameraExtra.z*.00872664626)))/(2*lens.z);
    float r=sqrt(random(rng))*radius,theta=2*PI*random(rng);origin.xy+=float2(cos(theta),sin(theta))*r;
    direction=normalize(target-origin);
 }
 float4 value=path(inverseCamera(origin),inverseCamera(direction),rng);result[p]=tileData.w>0?lerp(result[p],value,1/(tileData.w+1)):value;
}
