#if defined(REACTION31)
Texture2D<float4> reactionInput : register(t0);
RWTexture2D<float4> reactionOutput : register(u0);
cbuffer Reaction31Data : register(b0) {
    uint4 reactionInfo; // resolution, boundary mode, dispatch mode, color-input flag
    float4 reactionParameters; // feed, kill, diffusion A, diffusion B
};

int reaction31Boundary(int value, uint size) {
    if (reactionInfo.y == 0) {
        int extent = int(size);
        return (value % extent + extent) % extent;
    }
    if (reactionInfo.y == 1)
        return clamp(value, 0, int(size) - 1);
    int extent = int(size * 2);
    int folded = (value % extent + extent) % extent;
    return folded < int(size) ? folded : extent - 1 - folded;
}

int2 reaction31Coordinate(int2 pixel) {
    return int2(reaction31Boundary(pixel.x, reactionInfo.x),
                reaction31Boundary(pixel.y, reactionInfo.x));
}

float reaction31Gray(float4 value) {
    return reactionInfo.w != 0 ? dot(value.rgb, float3(.2126, .7152, .0722)) : value.r;
}

[numthreads(8, 8, 1)]
void reaction31(uint3 id : SV_DispatchThreadID) {
    if (id.x >= reactionInfo.x || id.y >= reactionInfo.x)
        return;

    int2 pixel = int2(id.xy);
    if (reactionInfo.z == 2) {
        float b = reactionInput.Load(int3(pixel, 0)).g;
        reactionOutput[pixel] = b.xxxx;
        return;
    }

    float centerA, centerB;
    if (reactionInfo.z == 0) {
        centerA = 1;
        centerB = saturate(reaction31Gray(reactionInput.Load(int3(pixel, 0))));
    } else {
        float4 state = reactionInput.Load(int3(pixel, 0));
        centerA = state.r;
        centerB = state.g;
    }

    float laplacianA = -centerA;
    float laplacianB = -centerB;
    [unroll]
    for (int y = -1; y <= 1; ++y) {
        [unroll]
        for (int x = -1; x <= 1; ++x) {
            if (x == 0 && y == 0)
                continue;
            float weight = x != 0 && y != 0 ? .05 : .2;
            float neighborA, neighborB;
            if (reactionInfo.z == 0) {
                neighborA = 1;
                neighborB = saturate(reaction31Gray(
                    reactionInput.Load(int3(reaction31Coordinate(pixel + int2(x, y)), 0))));
            } else {
                float4 neighbor = reactionInput.Load(int3(reaction31Coordinate(pixel + int2(x, y)), 0));
                neighborA = neighbor.r;
                neighborB = neighbor.g;
            }
            laplacianA += neighborA * weight;
            laplacianB += neighborB * weight;
        }
    }

    float reaction = centerA * centerB * centerB;
    float a = clamp(centerA + laplacianA * reactionParameters.z - reaction +
                        reactionParameters.x * (1 - centerA),
                    0, 1);
    float b = clamp(centerB + laplacianB * reactionParameters.w + reaction -
                        (reactionParameters.y + reactionParameters.x) * centerB,
                    0, 1);
    reactionOutput[pixel] = float4(a, b, 0, 1);
}
#endif
