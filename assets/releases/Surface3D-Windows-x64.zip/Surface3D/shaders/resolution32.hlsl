Texture2D<float4> source : register(t0);
RWTexture2D<float4> destination : register(u0);
cbuffer Settings : register(b0) { uint4 sizes; uint4 flags; }
float4 tap(int2 p) {
    float4 v = source.Load(int3(clamp(p, int2(0,0), int2(sizes.xy)-1),0));
    if(flags.x==1) v.rgb *= v.a;
    return v;
}
[numthreads(8,8,1)] void resample(uint3 id:SV_DispatchThreadID) {
    if(any(id.xy>=sizes.z))return;
    float2 p=(id.xy+.5)*sizes.xy/sizes.z-.5;
    float4 v;
    if(flags.y) v=source.Load(int3(clamp(int2(floor(p+.5)),int2(0,0),int2(sizes.xy)-1),0));
    else {
        int2 a=int2(floor(p)); float2 f=frac(p);
        v=lerp(lerp(tap(a),tap(a+int2(1,0)),f.x),lerp(tap(a+int2(0,1)),tap(a+1),f.x),f.y);
        if(flags.x==1)v.rgb=v.a>1e-8?v.rgb/v.a:0;
        if(flags.x==5)v=float4(length(v.xyz)>1e-8?normalize(v.xyz):float3(0,0,1),0);
    }
    if(flags.z) v=v[flags.z-1].xxxx;
    destination[id.xy]=v;
}
