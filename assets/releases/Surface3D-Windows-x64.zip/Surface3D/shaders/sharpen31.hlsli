#if defined(SHARPEN31)
Texture2D<float4> sharpenInput : register(t0);
Texture2D<float4> sharpenBlurInput : register(t1);
RWTexture2D<float4> sharpenOutput : register(u0);
cbuffer Sharpen31Data : register(b0) {
    uint4 sharpenInfo; // resolution, radius, boundary mode, pass
    float4 sharpenParameters; // amount, threshold, color-input flag, normal-input flag
    float4 sharpenWeights[25]; // Up to 97 taps, packed as 25 float4 values
};

int sharpen31Boundary(int value) {
    int size = int(sharpenInfo.x);
    if (sharpenInfo.z == 0)
        return (value % size + size) % size;
    if (sharpenInfo.z == 1)
        return clamp(value, 0, size - 1);
    int extent = size * 2;
    int folded = (value % extent + extent) % extent;
    return folded < size ? folded : extent - 1 - folded;
}

float sharpen31Weight(int index) {
    return sharpenWeights[index >> 2][index & 3];
}

float4 sharpen31Blur(int2 pixel, bool horizontal) {
    float4 sum = 0;
    int radius = int(sharpenInfo.y);
    for (int offset = -radius; offset <= radius; ++offset) {
        int2 samplePixel = pixel + (horizontal ? int2(offset, 0) : int2(0, offset));
        samplePixel = int2(sharpen31Boundary(samplePixel.x), sharpen31Boundary(samplePixel.y));
        float4 sampleValue = sharpenInput.Load(int3(samplePixel, 0));
        if (horizontal && sharpenParameters.z > .5)
            sampleValue.rgb *= sampleValue.a;
        sum += sampleValue * sharpen31Weight(offset + radius);
    }
    return sum;
}

[numthreads(8, 8, 1)]
void sharpen31(uint3 id : SV_DispatchThreadID) {
    if (id.x >= sharpenInfo.x || id.y >= sharpenInfo.x)
        return;
    int2 pixel = int2(id.xy);
    if (sharpenInfo.w < 2) {
        sharpenOutput[pixel] = sharpen31Blur(pixel, sharpenInfo.w == 0);
        return;
    }

    float4 original = sharpenInput.Load(int3(pixel, 0));
    float4 blurred = sharpenBlurInput.Load(int3(pixel, 0));
    if (sharpenParameters.z > .5)
        blurred.rgb = blurred.a > 1e-8 ? blurred.rgb / blurred.a : 0;
    float3 result = original.rgb;
    [unroll]
    for (int channel = 0; channel < 3; ++channel) {
        float detail = original[channel] - blurred[channel];
        if (abs(detail) >= sharpenParameters.y)
            result[channel] += detail * sharpenParameters.x;
    }
    if (sharpenParameters.w > .5) {
        float lengthSquared = dot(result, result);
        if (lengthSquared > 1e-12)
            result *= rsqrt(lengthSquared);
    }
    sharpenOutput[pixel] = float4(result, original.a);
}
#endif
