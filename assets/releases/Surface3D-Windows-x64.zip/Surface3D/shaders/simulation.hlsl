// Original conservative surface-film transport. Amounts are per-cell mass, not volumetric water.
struct Cell {float3 position;uint first;float3 normal;uint count;float area;float valid;float cavity;uint padding;};
struct Edge {uint target;uint reverse;float length;uint padding;};
StructuredBuffer<Cell> cells:register(t0);
StructuredBuffer<Edge> edges:register(t1);
StructuredBuffer<float4> states:register(t2);
StructuredBuffer<float> sources:register(t3);
StructuredBuffer<float2> fluxes:register(t4);
RWStructuredBuffer<float2> outFlux:register(u0);
RWStructuredBuffer<float4> outState:register(u1);
RWTexture2D<float4> maskResult:register(u2);
cbuffer Params:register(b0){float4 settings;float4 controls;float4 gravity;uint4 size;};
// settings: conductance, evaporation, deposition, timestep. controls: dirtMode, sourceRate, maskGain, dirtLoad.
[numthreads(64,1,1)]void flux(uint3 id:SV_DispatchThreadID){
 uint i=id.x;if(i>=size.x)return;Cell c=cells[i];float4 s=states[i];
 float source=sources[i]*controls.y*settings.w*c.area;
 float amount=controls.x>.5?s.y+source:s.x+source;
 float concentration=controls.x>.5?1:(s.y+source*controls.w)/max(s.x+source,1e-10);
 float rates[12];float sum=0;float3 g=length(gravity.xyz)>1e-6?normalize(gravity.xyz):float3(0,-1,0);
 [loop]for(uint k=0;k<c.count;k++){
  Edge e=edges[c.first+k];Cell other=cells[e.target];float4 n=states[e.target];
  float localDensity=amount/max(c.area,1e-8),neighbourDensity=(controls.x>.5?n.y:n.x)/max(other.area,1e-8);
  float downhill=dot(g,other.position-c.position)/max(e.length,1e-5);
  float pressure=(localDensity-neighbourDensity)*gravity.w;
  float rate=max(0,downhill+pressure)*settings.x*settings.w*c.area;
  if(controls.x>.5)rate=max(0,(localDensity-neighbourDensity)*gravity.w+max(0,downhill)*localDensity)*settings.x*settings.w*c.area;
  rate*=1-saturate(c.cavity*size.w*.001)*.85;
  rates[k]=rate;sum+=rate;
 }
 float scale=min(1,amount/max(sum,1e-10));
 [loop]for(uint k=0;k<c.count;k++)outFlux[c.first+k]=float2(rates[k]*scale,rates[k]*scale*concentration);
}
[numthreads(64,1,1)]void integrate(uint3 id:SV_DispatchThreadID){
 uint i=id.x;if(i>=size.x)return;Cell c=cells[i];float4 s=states[i];if(c.valid<.5){outState[i]=0;return;}
 float source=sources[i]*controls.y*settings.w*c.area;
 if(controls.x>.5)s.y+=source;else{s.x+=source;s.y+=source*controls.w;}
 [loop]for(uint k=0;k<c.count;k++){
  Edge e=edges[c.first+k];float2 outgoing=fluxes[c.first+k],incoming=fluxes[e.reverse];
  if(controls.x>.5)s.y+=incoming.x-outgoing.x;
  else{s.x+=incoming.x-outgoing.x;s.y+=incoming.y-outgoing.y;}
 }
 s.xy=max(s.xy,0);
 float dry=controls.x>.5?1:1/(1+s.x/max(c.area,1e-8)*4);
 float deposit=min(s.y,s.y*settings.z*settings.w*(.25+.75*dry)*(1+4*c.cavity*size.w*.001));s.y-=deposit;s.z+=deposit;
 s.x*=max(0,1-settings.y*settings.w);s.w=max(s.w,s.x);
 outState[i]=all(isfinite(s))?max(s,0):0;
}
[numthreads(8,8,1)]void outputMask(uint3 id:SV_DispatchThreadID){
 if(any(id.xy>=size.yy))return;uint i=id.y*size.y+id.x;float4 s=states[i];Cell c=cells[i];
 float value=size.z==1?s.x:size.z==2?s.y:size.z==3?s.w:s.z;
 value=c.valid>.5?(size.z==4?saturate(sources[i]):saturate(value/max(c.area,1e-8)*controls.z)):0;
 maskResult[id.xy]=float4(value,value,value,1);
}
