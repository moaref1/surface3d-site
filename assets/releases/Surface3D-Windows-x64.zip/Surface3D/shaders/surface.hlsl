// Read-only neutral channels use one texel; authored channels retain their full resolution.
float4 channelRead(Texture2D<float4> image, int2 pixel) {
 uint w,h; image.GetDimensions(w,h); return image.Load(int3(clamp(pixel,int2(0,0),int2(w,h)-1),0));
}
float3 combineNormalHeight(float3 base,float3 detail){
 base=normalize(base+float3(0,0,1e-8));detail=normalize(detail+float3(0,0,1e-8));
 float3 t=base+float3(0,0,1),u=detail*float3(-1,-1,1);
 return t.z>1e-5?normalize(t*dot(t,u)/t.z-u):normalize(base+detail-float3(0,0,1)+1e-8);
}
// Shared scene-linear color and presentation state; data-map paths bypass the display transform.
cbuffer RenderData:register(b2){float4 renderFlags,renderBackground,groundSettings,groundColor,renderView,objectTranslation,objectRotation,objectScale;float4 working709[3],workingAP1[3];float4 lightCount;float4 lightDirections[8];float4 lightColors[8];float4 renderReserved;float4 interactionSettings;};
Texture3D<float4> displayTransform:register(t127);SamplerState displaySampler:register(s15);
float3 workingFrom709(float3 c){return float3(dot(working709[0].xyz,c),dot(working709[1].xyz,c),dot(working709[2].xyz,c));}
float3 workingFromAP1(float3 c){return float3(dot(workingAP1[0].xyz,c),dot(workingAP1[1].xyz,c),dot(workingAP1[2].xyz,c));}
float3 imageWorking(float3 c,int encoding){if(encoding==1)c=lerp(c/12.92,pow(max((c+.055)/1.055,0),2.4),step(.04045,c));if(encoding==1 || encoding==2)return workingFrom709(c);if(encoding==3)return workingFromAP1(c);return c;}
float3 managedDisplay(float3 c){if(renderBackground.w>.5)return c;if(renderFlags.x>.5){float3 q=saturate(log2(1+max(c,0))/8);q=q*(47.0/48)+.5/48;return displayTransform.SampleLevel(displaySampler,q,0).rgb;}return lerp(12.92*c,1.055*pow(max(c,0),1.0/2.4)-.055,step(.0031308,c));}
float3 objectRotate(float3 p){float3 a=objectRotation.xyz*.01745329252;p=float3(p.x,cos(a.x)*p.y-sin(a.x)*p.z,sin(a.x)*p.y+cos(a.x)*p.z);p=float3(cos(a.y)*p.x+sin(a.y)*p.z,p.y,-sin(a.y)*p.x+cos(a.y)*p.z);return float3(cos(a.z)*p.x-sin(a.z)*p.y,sin(a.z)*p.x+cos(a.z)*p.y,p.z);}
float3 fresnel(float cosTheta,float3 f0){return f0+(1-f0)*pow(1-saturate(cosTheta),5);}

Texture2D<float4> specularEnvironment:register(t8),irradianceEnvironment:register(t9),environmentBRDF:register(t10);
Texture2DArray<float> lightShadows:register(t11);SamplerState lightingSampler:register(s14);
float3 inverseView(float3 p){float c=cos(renderView.x),s=sin(renderView.x),cp=cos(renderView.y),sp=sin(renderView.y);p=float3(p.x,cp*p.y+sp*p.z,-sp*p.y+cp*p.z);return float3(c*p.x+s*p.z,p.y,-s*p.x+c*p.z);}
float3 forwardView(float3 p){float c=cos(renderView.x),s=sin(renderView.x),cp=cos(renderView.y),sp=sin(renderView.y);p=float3(c*p.x-s*p.z,p.y,s*p.x+c*p.z);return float3(p.x,cp*p.y-sp*p.z,sp*p.y+cp*p.z);}
float2 lightingUV(float3 p,float rotation){if(renderFlags.y>.5)p=inverseView(p);float c=cos(rotation),s=sin(rotation);p=float3(c*p.x-s*p.z,p.y,s*p.x+c*p.z);return float2(atan2(p.z,p.x)/6.283185307+.5,acos(clamp(p.y,-1,1))/3.141592654);}
float3 shadowCoordinates(float3 p,int index){float3 l=lightDirections[index].xyz;float3 right=normalize(cross(abs(l.y)<.95?float3(0,1,0):float3(1,0,0),l)),up=cross(l,right);return float3(dot(p,right),dot(p,up),-dot(p,l))/max(renderReserved.w,.001);}
float shadowVisibility(float3 p,int index){if(renderFlags.y<.5 || renderReserved.z<.5 || lightColors[index].a<.5)return 1;float3 c=shadowCoordinates(p,index);float2 uv=c.xy*float2(.5,-.5)+.5;float z=c.z*.5+.5-groundSettings.w;if(any(uv<0) || any(uv>1) || z<0 || z>1)return 1;float result=0;
 for(int y=-1;y<=1;y++)for(int x=-1;x<=1;x++){int2 pixel=clamp(int2(uv*1024)+int2(x,y),0,1023);result+=z<=lightShadows.Load(int4(pixel,index,0))?1:0;}return result/9;
}
float3 directPBR(float3 color,float rough,float metal,float3 n,float3 v,float3 position){
 float3 f0=lerp(.04.xxx,max(color,0),metal),result=0;float a=max(.002,rough*rough),a2=a*a;float nv=max(dot(n,v),.0001);
 for(int j=0;j<(int)lightCount.x;j++){float3 l=lightDirections[j].xyz,h=normalize(l+v);float nl=saturate(dot(n,l)),nh=saturate(dot(n,h)),vh=saturate(dot(v,h));float d=a2/(3.14159265*pow(nh*nh*(a2-1)+1,2));float k=(rough+1)*(rough+1)/8;float g=(nv/(nv*(1-k)+k))*(nl/(nl*(1-k)+k));float3 f=fresnel(vh,f0);result+=((1-f)*(1-metal)*color/3.14159265+d*g*f/max(4*nv*nl,.0001))*lightColors[j].rgb*lightDirections[j].w*nl*3.14159265*shadowVisibility(position,j);
 }return result;
}
float3 environmentPBR(float3 color,float rough,float metal,float3 n,float3 v,float rotation,float gain,bool enabled){
 float nv=saturate(dot(n,v));float3 f0=lerp(.04.xxx,max(color,0),metal),f=fresnel(nv,f0);float3 diffuse=.18.xxx,specular=.18.xxx;float2 brdf=float2(1,0);
 if(enabled){diffuse=workingFrom709(irradianceEnvironment.SampleLevel(lightingSampler,lightingUV(n,rotation),0).rgb)*gain;specular=workingFrom709(specularEnvironment.SampleLevel(lightingSampler,lightingUV(reflect(-v,n),rotation),rough*8).rgb)*gain;brdf=environmentBRDF.SampleLevel(displaySampler,float2(nv,rough),0).rg;}
 return (1-f)*(1-metal)*color*diffuse+specular*(f0*brdf.x+brdf.y);
}
// SurfaceLab authored shader source. Material RGB values are linear.
float blendValue(float a,float b,int mode){
 if(mode==1)return a*b;if(mode==2)return saturate(a+b);if(mode==3)return 1-(1-a)*(1-b);if(mode==4)return saturate(a-b);
 if(mode==5)return min(a,b);if(mode==6)return max(a,b);if(mode==7)return abs(a-b);if(mode==8)return a<.5?2*a*b:1-2*(1-a)*(1-b);if(mode==9)return abs(b)>.00001?saturate(a/b):0;if(mode==14)return a+b;if(mode==15)return a-b;
 if(mode==16)return b>1e-6?1-saturate((1-a)/b):0;
 if(mode==17)return b<1-1e-6?saturate(a/(1-b)):1;
 if(mode==18){float d=a<=.25?((16*a-12)*a+4)*a:sqrt(max(a,0));return b<=.5?a-(1-2*b)*a*(1-a):a+(2*b-1)*(d-a);}
 if(mode==19)return a;
#endif
 return b;
}
float3 blendColor(float3 a,float3 b,int mode){return float3(blendValue(a.r,b.r,mode),blendValue(a.g,b.g,mode),blendValue(a.b,b.b,mode));}

#if defined(BRUSH) || defined(NODE_PAINT)
Texture2D<float4> stencilImage:register(t6);
SamplerState stencilSampler:register(s1);
cbuffer StencilData:register(b3){float4 stencilPlacement,stencilTransform,stencilLevels;float4 stencilProjection[3];float4 stencilFlags;};
float stencilWeight(float2 uv,float4 position){
 if(stencilTransform.w<.5)return 1;
 if(stencilFlags.x>.5){
 if(position.a<.5)return 0;
 float4 world=float4(position.xyz*2-1,1);
 float w=dot(stencilProjection[2],world);if(w<=.00001)return 0;
 uv=float2(dot(stencilProjection[0],world),dot(stencilProjection[1],world))/w;
 }
 float2 d=uv-stencilPlacement.xy;
 float2 q=float2(d.x*stencilTransform.x+d.y*stencilTransform.y,-d.x*stencilTransform.y+d.y*stencilTransform.x)/stencilPlacement.zw+.5;
 if(any(q<0)||any(q>1))return 0;
 float4 sample=stencilImage.SampleLevel(stencilSampler,q,0);
 float value=pow(saturate((dot(sample.rgb,float3(.2126,.7152,.0722))-stencilLevels.x)/max(.00001,stencilLevels.y-stencilLevels.x)),1/max(.01,stencilLevels.z));
 if(stencilLevels.w>.5)value=1-value;
 return saturate(value*sample.a*stencilTransform.z);
}
#endif
#if defined(THUMBNAIL)
Texture2D<float> thumbnailSource:register(t0);
RWTexture2D<float4> thumbnailTarget:register(u0);
cbuffer ThumbnailData:register(b0) {float4 thumbnailSize;float4 thumbnailFlags;};
[numthreads(8,8,1)]
void thumbnail(uint3 p:SV_DispatchThreadID) {
    if(any(p.xy>=uint2(thumbnailSize.zw)))return;
    uint2 source=min(uint2(float2(p.xy)*thumbnailSize.xy/thumbnailSize.zw),uint2(thumbnailSize.xy)-1);
    float v=saturate(thumbnailSource.Load(int3(source,0)));
    if(thumbnailFlags.x<.5)v=1;else if(thumbnailFlags.y>.5)v=1-v;
    thumbnailTarget[p.xy]=float4(v,v,v,1);
}
#elif defined(PADDING)
Texture2D<float4> padColor:register(t0),padMaterial:register(t1),padDetail:register(t2),padEmission:register(t3),padUtility:register(t4);
Texture2D<uint> padLookup:register(t5);
RWTexture2D<float4> padColorOut:register(u0),padMaterialOut:register(u1),padDetailOut:register(u2),padEmissionOut:register(u3),padUtilityOut:register(u4);
[numthreads(8,8,1)] void padding(uint3 p:SV_DispatchThreadID) {
 uint width,height;padLookup.GetDimensions(width,height);if(p.x>=width||p.y>=height)return;
 uint source=padLookup[p.xy];uint2 q=source==0xffffffff?p.xy:uint2(source%width,source/width);
 padColorOut[p.xy]=padColor[q];padMaterialOut[p.xy]=padMaterial[q];padDetailOut[p.xy]=channelRead(padDetail,q);padEmissionOut[p.xy]=channelRead(padEmission,q);padUtilityOut[p.xy]=channelRead(padUtility,q);
}
#elif defined(SMOOTH_FIELD)
Texture2D<float4> smoothSource:register(t0);RWTexture2D<float4> smoothTarget:register(u0);
cbuffer SmoothData:register(b0){float4 smoothSettings;float4 smoothFlags;};
int smoothIndex(int x,int size){
 if(smoothFlags.x<.5)return (x%size+size)%size;
 if(smoothFlags.x<1.5)return clamp(x,0,size-1);
 int t=(x%(size*2)+size*2)%(size*2);return t<size?t:size*2-1-t;
}
[numthreads(8,8,1)] void smoothField(uint3 id:SV_DispatchThreadID){
 int size=(int)smoothSettings.x;if(id.x>=size||id.y>=size)return;
 float radius=smoothSettings.y*2;int extent=(int)ceil(radius);float4 sum=0;float weight=0;
 [loop]for(int j=-extent;j<=extent;j++){
  float edge=saturate(radius+.5-abs(j));float w=smoothSettings.w>.5?exp(-.5*j*j/max(smoothSettings.y*smoothSettings.y,.0001))*edge:edge;
  int2 q=int2(id.xy)+(smoothSettings.z<.5?int2(j,0):int2(0,j));q=int2(smoothIndex(q.x,size),smoothIndex(q.y,size));
  float4 v=smoothSource.Load(int3(q,0));
  if(smoothFlags.y>.5 && smoothSettings.z<.5)v.rgb*=v.a;
  sum+=v*w;weight+=w;
 }
 float4 value=sum/max(weight,1e-8);
 if(smoothFlags.y>.5 && smoothSettings.z>.5)value.rgb=value.a>1e-8?value.rgb/value.a:0;
 if(smoothFlags.z>.5 && smoothSettings.z>.5)value.xyz=length(value.xyz)>1e-8?normalize(value.xyz):float3(0,0,1);
 smoothTarget[id.xy]=value;
}
#elif defined(FIELD_PADDING)
Texture2D<float4> fieldSource:register(t0);Texture2D<uint> fieldLookup:register(t1);RWTexture2D<float4> fieldTarget:register(u0);
[numthreads(8,8,1)] void fieldPadding(uint3 p:SV_DispatchThreadID) {
 uint width,height;fieldLookup.GetDimensions(width,height);if(p.x>=width||p.y>=height)return;
 uint source=fieldLookup[p.xy];uint2 q=source==0xffffffff?p.xy:uint2(source%width,source/width);fieldTarget[p.xy]=fieldSource[q];
}
#elif defined(MASK_PADDING)
Texture2D<float> maskSource:register(t0);Texture2D<uint> maskLookup:register(t1);RWTexture2D<float> maskTarget:register(u0);
[numthreads(8,8,1)] void maskPadding(uint3 p:SV_DispatchThreadID) {
 uint width,height;maskLookup.GetDimensions(width,height);if(p.x>=width||p.y>=height)return;
 uint source=maskLookup[p.xy];uint2 q=source==0xffffffff?p.xy:uint2(source%width,source/width);maskTarget[p.xy]=maskSource[q];
}
#elif defined(BRUSH)
RWTexture2D<float4> colorMap : register(u0);
RWTexture2D<float4> materialMap : register(u1);
RWTexture2D<float> maskMap : register(u2);
RWTexture2D<float4> brushDetail:register(u3),brushEmission:register(u4),brushUtility:register(u5),brushCoverage:register(u6);
RWTexture2D<float> brushStrokeCoverage:register(u7);
cbuffer BrushData : register(b0) {
    float4 color;
    float4 material; // roughness, metallic, mask value, strength
    float4 geometry; // center px, radius px, resolution
    uint4 region; // dispatch origin, channels, mask mode
    float4 weather0,weather1,weather2,weatherOrigin,weatherGravity,surfaceBrush;
    float4 brushTip,brushDetailValue,brushUtilityValue,brushEmissionValue,brushUnused[2];
};
Texture2D<float4> weatherPosition:register(t0);
Texture2D<float4> weatherNormal:register(t1);
Texture2D<float4> weatherAO:register(t2);
Texture2D<float4> weatherLowNormal:register(t3);
Texture2D<uint> surfaceTriangle:register(t4);StructuredBuffer<uint> surfaceAllowed:register(t5);
SamplerState weatherSampler:register(s0);
float weatherHash(float2 p,float seed){return frac(sin(dot(p,float2(127.1,311.7))+seed*19.19)*43758.5453);}
float weatherNoise(float2 p,float seed){float2 i=floor(p),f=frac(p);f=f*f*(3-2*f);return lerp(lerp(weatherHash(i,seed),weatherHash(i+float2(1,0),seed),f.x),lerp(weatherHash(i+float2(0,1),seed),weatherHash(i+1,seed),f.x),f.y);}
float weatherWeight(uint2 p){
 float2 uv=(float2(p)+.5)/geometry.w;
 float4 position=weatherPosition.SampleLevel(weatherSampler,uv,0);
 if(position.a<.5)return 0;
 float3 q=position.xyz;
 float4 encodedNormal=weatherNormal.SampleLevel(weatherSampler,uv,0);
 if(encodedNormal.a<=0)encodedNormal=weatherLowNormal.SampleLevel(weatherSampler,uv,0);
 float3 n=normalize(encodedNormal.xyz*2-1+1e-6);
 float3 down=normalize(weatherGravity.xyz),up=-down;
 float3 side=normalize(cross(up,abs(up.z)<.9?float3(0,0,1):float3(1,0,0))),depth=cross(up,side);
 float4 encodedAO=weatherGravity.w>.5?weatherAO.SampleLevel(weatherSampler,uv,0):1;
 float ao=encodedAO.a>0?encodedAO.r:1;
 float grain=weatherNoise(float2(dot(q,side),dot(q,depth))*36,weather2.y);
 float surface=lerp(1,.25+.75*saturate(dot(n,up)*.5+.5),weather1.w);
 float cavities=lerp(1,1+(1-ao)*2,weather1.z);
 if(weather0.x==1){
   float across=dot(q,side)*lerp(5,72,weather0.y)+weatherNoise(float2(dot(q,up),dot(q,depth))*8,weather2.y)*weather1.x;
   float stripe=1-smoothstep(max(.005,weather0.w*.1),max(.006,weather0.w*.5),abs(frac(across)-.5));
   float phase=frac(dot(q,down)/max(.015,weather0.z)+weatherHash(float2(floor(across),floor(dot(q,depth)*8)),weather2.y));
   float tail=1-smoothstep(max(.05,weather1.y*.7),min(.99,.2+weather1.y*.8),phase);
   return saturate(stripe*tail*lerp(1,grain,weather1.x)*surface*cavities);
 }
 float plane=weather2.z>.5?weather2.w+weather2.x*weatherOrigin.w:dot(weatherOrigin.xyz,up);
 float height=max(0,dot(q,up)-plane),reach=max(.005,weather0.z*(.15+weather1.y*.85));
 float growth=1-smoothstep(0,reach,height);
 float clumps=smoothstep(1-weather0.y-.15,1-weather0.y+.15,lerp(.5,grain,.2+weather1.x*.8)+weather1.y*.15);
 return saturate(growth*clumps*surface*cavities);
}
// Typed FP16 UAV stores truncate on some devices. Round the brush state explicitly
// so a long low-flow stroke does not accumulate a downward coverage bias.
float4 storeBrush(float4 value) {
    if(brushUnused[0].x<.5)return value;
    float4 magnitude=abs(value);uint4 lower=f32tof16(magnitude);
    float4 low=f16tof32(lower),high=f16tof32(min(lower+1,0x7bff));
    uint4 increment=uint4((magnitude.x-low.x>high.x-magnitude.x)?1:0,(magnitude.y-low.y>high.y-magnitude.y)?1:0,(magnitude.z-low.z>high.z-magnitude.z)?1:0,(magnitude.w-low.w>high.w-magnitude.w)?1:0);
    return sign(value)*f16tof32(min(lower+increment,0x7bff));
}
float4 over(float4 previous, float3 value, float weight) {
    float alpha = weight + previous.a * (1-weight);
    return float4((value*weight + previous.rgb*previous.a*(1-weight))/max(alpha,1e-8),alpha);
}
[numthreads(8,8,1)]
void brush(uint3 tid : SV_DispatchThreadID) {
    uint2 p=tid.xy+region.xy;
    if(any(p>=uint2(geometry.ww))) return;
    float2 delta=(float2(p)+.5-geometry.xy)/geometry.z;
    float2 ellipse=float2(delta.x*brushTip.z+delta.y*brushTip.w,-delta.x*brushTip.w+delta.y*brushTip.z);
    float distance=length(ellipse/float2(1,brushTip.y));
    if(surfaceBrush.w>0) {
       uint faceIndex=surfaceTriangle[p];float4 position=weatherPosition[p];
       if(faceIndex==0xffffffff||position.a<.5||surfaceAllowed[faceIndex]==0)return;
       distance=length(position.xyz*2-1-surfaceBrush.xyz)/surfaceBrush.w;
    }
    if(distance>=1) return;
    float weight=(1-smoothstep(min(color.a,.999),1,distance))*material.w;
    weight*=stencilWeight((float2(p)+.5)/geometry.w,weatherPosition[p]);
    if(weather0.x>0) weight*=weatherWeight(p);
    float oldStroke=brushStrokeCoverage[p],nextStroke=oldStroke+max(0,brushTip.x-oldStroke)*saturate(weight);
    weight=(nextStroke-oldStroke)/max(1-oldStroke,1e-8);brushStrokeCoverage[p]=nextStroke;
    if(region.w==2) {
        float4 coverage=brushCoverage[p],utility=brushUtility[p];
        if((region.z&8)!=0)coverage.r*=1-weight;
        if((region.z&16)!=0)utility.a*=1-weight;
        if((region.z&32)!=0)coverage.g*=1-weight;
        if((region.z&64)!=0)coverage.b*=1-weight;
        if((region.z&128)!=0)coverage.a*=1-weight;
        brushCoverage[p]=storeBrush(coverage);brushUtility[p]=storeBrush(utility);
float4 c=colorMap[p],m=materialMap[p];if((region.z&1)!=0)c.a*=1-weight;if((region.z&2)!=0)m.b*=1-weight;if((region.z&4)!=0)m.a*=1-weight;colorMap[p]=storeBrush(c);materialMap[p]=storeBrush(m);return;}
    if(region.w==1) { maskMap[p]=lerp(maskMap[p],material.z,weight); return; }
    if((region.z&1)!=0) colorMap[p]=storeBrush(over(colorMap[p],color.rgb,weight));
    // Each material channel carries its own coverage, preventing disabled-channel writes.
    float4 old=materialMap[p];
    if((region.z&2)!=0) { float2 pair=over(float4(old.r,0,0,old.b),float3(material.r,0,0),weight).ra; old.r=pair.x; old.b=pair.y; }
    if((region.z&4)!=0) { float2 pair=over(float4(old.g,0,0,old.a),float3(material.g,0,0),weight).ra; old.g=pair.x; old.a=pair.y; }
    materialMap[p]=storeBrush(old);
    float4 d=brushDetail[p],coverage=brushCoverage[p],utility=brushUtility[p];
    if((region.z&8)!=0){float4 pair=over(float4(d.xyz,coverage.r),brushDetailValue.xyz,weight);d.xyz=normalize(pair.xyz+float3(0,0,1e-8));coverage.r=pair.a;}
    if((region.z&16)!=0){float4 pair=over(float4(d.w,0,0,utility.a),brushDetailValue.www,weight);d.w=pair.r;utility.a=pair.a;}
    if((region.z&32)!=0){float4 pair=over(float4(utility.r,0,0,coverage.g),brushUtilityValue.xxx,weight);utility.r=pair.r;coverage.g=pair.a;}
    if((region.z&64)!=0){float4 pair=over(float4(brushEmission[p].rgb,coverage.b),brushEmissionValue.rgb,weight);brushEmission[p]=storeBrush(pair);coverage.b=pair.a;}
    if((region.z&128)!=0){float4 pair=over(float4(utility.g,0,0,coverage.a),brushUtilityValue.yyy,weight);utility.g=pair.r;coverage.a=pair.a;}
    brushDetail[p]=d;brushCoverage[p]=storeBrush(coverage);brushUtility[p]=storeBrush(utility);
}
#elif defined(NODE_PAINT)
Texture2D<float4> paintSource:register(t0);Texture2D<float4> paintBase:register(t1);
Texture2D<float4> paintPosition:register(t2);Texture2D<uint> paintTriangles:register(t3);StructuredBuffer<uint> paintAllowed:register(t4);
RWTexture2D<float4> paintTarget:register(u0);RWTexture2D<float> paintStrokeCoverage:register(u1);SamplerState paintSampler:register(s0);
cbuffer NodePaintData:register(b0){float4 paintCenter,paintValue,paintControls,paintClone,paintSurface;float4 paintTip,paintDispatch,paintUnused[9];};
[numthreads(8,8,1)]void nodePaint(uint3 id:SV_DispatchThreadID){
    id.xy+=uint2(paintDispatch.xy);uint width,height;paintTarget.GetDimensions(width,height);if(id.x>=width||id.y>=height||any(id.xy>=uint2(paintDispatch.zw)))return;
    float2 uv=(float2(id.xy)+.5)/float2(width,height), delta=uv-paintCenter.xy;
    if(paintControls.z>.5)delta-=round(delta);
    float2 ellipse=float2(delta.x*paintTip.z+delta.y*paintTip.w,-delta.x*paintTip.w+delta.y*paintTip.z);
    float distance=length(ellipse/float2(1,paintTip.y))/paintCenter.z;
    if(paintSurface.w>0){uint face=paintTriangles[id.xy];float4 pos=paintPosition[id.xy];
        if(face==0xffffffff||pos.a<.5||paintAllowed[face]==0)return;
        distance=length(pos.xyz*2-1-paintSurface.xyz)/paintSurface.w;}
    if(distance>=1)return;
    float weight=(1-smoothstep(min(paintControls.x,.999),1,distance))*paintCenter.w;
    weight*=stencilWeight(uv,paintPosition[id.xy]);
    float oldStroke=paintStrokeCoverage[id.xy],nextStroke=oldStroke+max(0,paintTip.x-oldStroke)*saturate(weight);
    weight=(nextStroke-oldStroke)/max(1-oldStroke,1e-8);paintStrokeCoverage[id.xy]=nextStroke;
    float4 value=paintValue;
    if(paintControls.y>.5)value=paintBase[id.xy];
    else if(paintClone.z>.5){float2 q=uv+paintClone.xy;value=paintSource.SampleLevel(paintSampler,paintControls.z>.5?frac(q):saturate(q),0);}
    float4 result=lerp(paintTarget[id.xy],value,weight);
    if(paintControls.w==5)result.xyz=normalize(result.xyz+float3(0,0,1e-8));
    paintTarget[id.xy]=result;
}
#elif defined(PROCEDURAL)
Texture2D<float4> geometryPosition:register(t0);
Texture2D<float4> inputColor:register(t1);Texture2D<float4> inputMaterial:register(t2);Texture2D<float> inputMask:register(t3);
Texture2D<float4> anchorColors[8]:register(t4);Texture2D<float4> anchorMaterials[8]:register(t12);Texture2D<float> anchorMasks[8]:register(t20);
Texture2D<float4> geometryNormal:register(t28);
Texture2D<float4> paintColor:register(t45);Texture2D<float4> paintMaterial:register(t46);
Texture2D<float4> paintDetail:register(t75),paintEmission:register(t76),paintUtility:register(t77),paintExtraCoverage:register(t78);
Texture2D<float4> fields[16]:register(t51);
Texture2D<float4> inputCoverage:register(t50);
Texture2D<float4> inputDetail:register(t47);Texture2D<float4> inputEmission:register(t48);Texture2D<float4> inputUtility:register(t49);
Texture2D<float4> images[16]:register(t29);SamplerState imageSampler:register(s0);
SamplerState nodeTextureSampler:register(s1);SamplerState fieldSampler:register(s2);
RWTexture2D<float4> nodeAtlas:register(u3);
RWTexture2D<float4> coverageMap:register(u7);
RWTexture2D<float4> detailMap:register(u4);RWTexture2D<float4> emissionMap:register(u5);RWTexture2D<float4> utilityMap:register(u6);
RWTexture2D<float4> colorMap : register(u0);
RWTexture2D<float4> materialMap : register(u1);
RWTexture2D<float> maskMap:register(u2);
struct NodeData {float4 meta;float4 parameters;float4 reserved;float4 convert0;float4 convert1;float4 extra0;float4 extra1;float4 links0;float4 links1;};
cbuffer ProceduralData : register(b0) { float4 primary; float4 secondary; float4 noiseSettings; float4 outputSettings; float4 reserved; float4 graphInfo;float4 effectInfo;float4 effectOutput;float4 uvTransform;float4 uvOptions;NodeData nodes[128]; };
float hash(float2 p) { return frac(sin(dot(p,float2(127.1,311.7))+noiseSettings.y*19.19)*43758.5453); }
float hashSeed(float2 p,float seed){return frac(sin(dot(p,float2(127.1,311.7))+seed*19.19)*43758.5453);}
// Periodic generator lattice; spatial feature positions remain unwrapped.
float2 tileCell2(float2 p,float period){return p-floor(p/period)*period;}
float3 tileCell3(float3 p,float period){return p-floor(p/period)*period;}
float tileScale(float scale){return max(1,round(scale));}
float tileHash(float2 p,float seed,float period){return hashSeed(tileCell2(p,period),seed);}
float tileNoise(float2 p,float seed,float2 period){float2 i=floor(p),f=frac(p);f=f*f*(3-2*f);float2 a=i-floor(i/period)*period,b=i+1-floor((i+1)/period)*period;return lerp(lerp(hashSeed(a,seed),hashSeed(float2(b.x,a.y),seed),f.x),lerp(hashSeed(float2(a.x,b.y),seed),hashSeed(b,seed),f.x),f.y);}
float graphNoise(float2 p,float seed){float2 i=floor(p),f=frac(p);f=f*f*(3-2*f);return lerp(lerp(hashSeed(i,seed),hashSeed(i+float2(1,0),seed),f.x),lerp(hashSeed(i+float2(0,1),seed),hashSeed(i+1,seed),f.x),f.y);}
float noise(float2 p) {float2 i=floor(p),f=frac(p);f=f*f*(3-2*f);return lerp(lerp(hash(i),hash(i+float2(1,0)),f.x),lerp(hash(i+float2(0,1)),hash(i+1),f.x),f.y);}
float4 anchorC(int slot,uint2 p) {
 if(slot==0) return anchorColors[0][p];
 if(slot==1) return anchorColors[1][p];
 if(slot==2) return anchorColors[2][p];
 if(slot==3) return anchorColors[3][p];
 if(slot==4) return anchorColors[4][p];
 if(slot==5) return anchorColors[5][p];
 if(slot==6) return anchorColors[6][p];
 if(slot==7) return anchorColors[7][p];
 return 0;
}
float4 anchorM(int slot,uint2 p) {
 if(slot==0) return anchorMaterials[0][p];
 if(slot==1) return anchorMaterials[1][p];
 if(slot==2) return anchorMaterials[2][p];
 if(slot==3) return anchorMaterials[3][p];
 if(slot==4) return anchorMaterials[4][p];
 if(slot==5) return anchorMaterials[5][p];
 if(slot==6) return anchorMaterials[6][p];
 if(slot==7) return anchorMaterials[7][p];
 return 0;
}
float anchorS(int slot,uint2 p) {
 if(slot==0) return anchorMasks[0][p];
 if(slot==1) return anchorMasks[1][p];
 if(slot==2) return anchorMasks[2][p];
 if(slot==3) return anchorMasks[3][p];
 if(slot==4) return anchorMasks[4][p];
 if(slot==5) return anchorMasks[5][p];
 if(slot==6) return anchorMasks[6][p];
 if(slot==7) return anchorMasks[7][p];
 return 0;
}
float4 imageAt(int slot,float2 uv) {
 if(slot==0) return images[0].SampleLevel(nodeTextureSampler,uv,0);
 if(slot==1) return images[1].SampleLevel(nodeTextureSampler,uv,0);
 if(slot==2) return images[2].SampleLevel(nodeTextureSampler,uv,0);
 if(slot==3) return images[3].SampleLevel(nodeTextureSampler,uv,0);
 if(slot==4) return images[4].SampleLevel(nodeTextureSampler,uv,0);
 if(slot==5) return images[5].SampleLevel(nodeTextureSampler,uv,0);
 if(slot==6) return images[6].SampleLevel(nodeTextureSampler,uv,0);
 if(slot==7) return images[7].SampleLevel(nodeTextureSampler,uv,0);
 if(slot==8) return images[8].SampleLevel(nodeTextureSampler,uv,0);
 if(slot==9) return images[9].SampleLevel(nodeTextureSampler,uv,0);
 if(slot==10) return images[10].SampleLevel(nodeTextureSampler,uv,0);
 if(slot==11) return images[11].SampleLevel(nodeTextureSampler,uv,0);
 if(slot==12) return images[12].SampleLevel(nodeTextureSampler,uv,0);
 if(slot==13) return images[13].SampleLevel(nodeTextureSampler,uv,0);
 if(slot==14) return images[14].SampleLevel(nodeTextureSampler,uv,0);
 if(slot==15) return images[15].SampleLevel(nodeTextureSampler,uv,0);
 return float4(.5,.5,.5,1);
}
float4 imageNodeAt(int slot,float2 uv,int wrap,int filter,float2 dimensions){
 if(slot<0)return .5;
 float2 size=max(dimensions,1),halfPixel=.5/size;
 if(wrap==2)uv=1-abs(frac(uv*.5)*2-1);
 if(wrap!=0)uv=clamp(uv,halfPixel,1-halfPixel);
 if(filter==1)uv=(floor(uv*size)+.5)/size;
 return imageAt(slot,uv);
}
float2 imageUV(float2 uv,float2 tiling,float angle,float2 offset){
 float2 q=(uv-.5)*max(tiling,.001);
 return float2(cos(angle)*q.x-sin(angle)*q.y,sin(angle)*q.x+cos(angle)*q.y)+.5+offset;
}
Texture2D<float4> simulationMasks[8]:register(t67);
float4 simulationAt(int i,float2 uv){
 if(i==0)return simulationMasks[0].SampleLevel(imageSampler,uv,0);if(i==1)return simulationMasks[1].SampleLevel(imageSampler,uv,0);if(i==2)return simulationMasks[2].SampleLevel(imageSampler,uv,0);if(i==3)return simulationMasks[3].SampleLevel(imageSampler,uv,0);if(i==4)return simulationMasks[4].SampleLevel(imageSampler,uv,0);if(i==5)return simulationMasks[5].SampleLevel(imageSampler,uv,0);if(i==6)return simulationMasks[6].SampleLevel(imageSampler,uv,0);if(i==7)return simulationMasks[7].SampleLevel(imageSampler,uv,0);return 0;
}
float4 fieldAt(int slot,float2 uv) {
 if(slot==0) return fields[0].SampleLevel(fieldSampler,uv,0);
 if(slot==1) return fields[1].SampleLevel(fieldSampler,uv,0);
 if(slot==2) return fields[2].SampleLevel(fieldSampler,uv,0);
 if(slot==3) return fields[3].SampleLevel(fieldSampler,uv,0);
 if(slot==4) return fields[4].SampleLevel(fieldSampler,uv,0);
 if(slot==5) return fields[5].SampleLevel(fieldSampler,uv,0);
 if(slot==6) return fields[6].SampleLevel(fieldSampler,uv,0);
 if(slot==7) return fields[7].SampleLevel(fieldSampler,uv,0);
 if(slot==8) return fields[8].SampleLevel(fieldSampler,uv,0);
 if(slot==9) return fields[9].SampleLevel(fieldSampler,uv,0);
 if(slot==10) return fields[10].SampleLevel(fieldSampler,uv,0);
 if(slot==11) return fields[11].SampleLevel(fieldSampler,uv,0);
 if(slot==12) return fields[12].SampleLevel(fieldSampler,uv,0);
 if(slot==13) return fields[13].SampleLevel(fieldSampler,uv,0);
 if(slot==14) return fields[14].SampleLevel(fieldSampler,uv,0);
 if(slot==15) return fields[15].SampleLevel(fieldSampler,uv,0);
 return 0;
}
float4 filterTap(int slot,float2 uv,int type){float4 v=fieldAt(slot,uv);if(type==1)v.rgb*=v.a;return v;}

int boundaryPixel(int v,int size,int wrap) {
    if(wrap==1)return clamp(v,0,size-1);
    int count=wrap==2?2*size:size;v=(v%count+count)%count;
    return wrap==2&&v>=size?2*size-1-v:v;
}
float3 safeNormalize(float3 n);
float4 sampleFieldTap(int slot,int2 p,int size,int wrap,int type) {
    int2 at=int2(boundaryPixel(p.x,size,wrap),boundaryPixel(p.y,size,wrap));
    return filterTap(slot,(float2(at)+.5)/size,type);
}
float4 sampleField(int slot,float2 q,int type,int wrap,int filtering) {
    int size=(int)outputSettings.y;
    float4 v;
    if(filtering==0)v=sampleFieldTap(slot,(int2)floor(q*size),size,wrap,type);
    else {
        float2 pixel=q*size-.5;int2 at=(int2)floor(pixel);float2 f=frac(pixel);
        v=lerp(lerp(sampleFieldTap(slot,at,size,wrap,type),sampleFieldTap(slot,at+int2(1,0),size,wrap,type),f.x),
               lerp(sampleFieldTap(slot,at+int2(0,1),size,wrap,type),sampleFieldTap(slot,at+int2(1,1),size,wrap,type),f.x),f.y);
    }
    if(type==1)v.rgb=v.a>1e-8?v.rgb/v.a:0;
    if(type==5)v=float4(safeNormalize(v.xyz),0);
    return v;
}
float4 seamBlend(int slot,float2 q,float2 blend,int type) {
    float2 w=(1-smoothstep(0,max(blend,1e-6),min(q,1-q)))*step(1e-6,blend);
    float4 v=lerp(lerp(filterTap(slot,q,type),filterTap(slot,frac(q+float2(.5,0)),type),w.x),
                  lerp(filterTap(slot,frac(q+float2(0,.5)),type),filterTap(slot,frac(q+.5),type),w.x),w.y);
    if(type==1)v.rgb=v.a>1e-8?v.rgb/v.a:0;
    if(type==5)v=float4(safeNormalize(v.xyz),0);
    return v;
}
float3 toLinear(float3 c){return lerp(c/12.92,pow((c+.055)/1.055,2.4),step(.04045,c));}
float3 toDisplay(float3 c){return lerp(12.92*c,1.055*pow(max(c,0),1.0/2.4)-.055,step(.0031308,c));}
float4 converted(float4 v,int code){if(code==1)return dot(v.rgb,float3(.2126,.7152,.0722)).xxxx;if(code==2)return v.xxxx;if(code==3)return (v.x>.5?1:0).xxxx;if(code==4)return round(v.x).xxxx;if(code==5){float3 n=v.rgb*2-1;return float4(length(n)>1e-6?n/length(n):float3(0,0,1),0);}if(code==6)return float4(length(v.xyz)>1e-6?v.xyz/length(v.xyz):float3(0,0,1),0);return v;}
float3 hash3(float3 p,float seed){return frac(sin(float3(dot(p,float3(127.1,311.7,74.7)),dot(p,float3(269.5,183.3,246.1)),dot(p,float3(113.5,271.9,124.6)))+seed*19.19)*43758.5453);}
float simplex3(float3 p,float seed){
 float3 cell=floor(p+dot(p,float3(1.0/3,1.0/3,1.0/3)));
 float3 v=p-cell+dot(cell,float3(1.0/6,1.0/6,1.0/6));
 float3 rank=float3(v.x>=v.y?1:0,v.y>=v.z?1:0,v.z>=v.x?1:0);
 float3 first=min(rank,1-rank.zxy),second=max(rank,1-rank.zxy);
 float sum=0;
 [unroll]for(int i=0;i<4;i++){
  float3 offset=i==0?0:i==1?first:i==2?second:1;
  float3 d=v-offset+i/6.0;float fall=max(0,.6-dot(d,d));
  float3 gradient=normalize(hash3(cell+offset,seed)*2-1+1e-5);
  sum+=fall*fall*fall*fall*dot(gradient,d);
 }
 return saturate(.5+sum*16);
}
float cellular3(float3 p,float seed,int mode){
 float3 cell=floor(p);float first=1e10,second=1e10,id=0;
 [loop]for(int z=-1;z<=1;z++)[loop]for(int y=-1;y<=1;y++)[loop]for(int x=-1;x<=1;x++){
  float3 cc=cell+float3(x,y,z);float distance=length(p-cc-hash3(cc,seed));
  if(distance<first){second=first;first=distance;id=hash3(cc+71,seed).r;}else second=min(second,distance);
 }
 return mode==1?saturate(second-first):mode==2?id:saturate(first);
}
float perlin3(float3 p,float seed){float3 i=floor(p),f=frac(p),u=f*f*f*(f*(f*6-15)+10);float sum=0;
[unroll]for(int z=0;z<2;z++)[unroll]for(int y=0;y<2;y++)[unroll]for(int x=0;x<2;x++){float3 off=float3(x,y,z),g=normalize(hash3(i+off,seed)*2-1+1e-5);float3 w=lerp(1-u,u,off);sum+=dot(g,f-off)*w.x*w.y*w.z;}return .5+sum*.75;}

float tilePerlin3(float3 p,float seed,float period){float3 i=floor(p),f=frac(p),u=f*f*f*(f*(f*6-15)+10);float sum=0;[loop]for(int z=0;z<2;z++)[loop]for(int y=0;y<2;y++)[loop]for(int x=0;x<2;x++){float3 off=float3(x,y,z),g=normalize(hash3(tileCell3(i+off,period),seed)*2-1+1e-5);float3 w=lerp(1-u,u,off);sum+=dot(g,f-off)*w.x*w.y*w.z;}return .5+sum*.75;}
float tileCellular3(float3 p,float seed,int mode,float period){float3 cell=floor(p);float first=1e10,second=1e10,id=0;[loop]for(int z=-1;z<=1;z++)[loop]for(int y=-1;y<=1;y++)[loop]for(int x=-1;x<=1;x++){float3 cc=cell+float3(x,y,z),wrapped=tileCell3(cc,period);float distance=length(p-cc-hash3(wrapped,seed));if(distance<first){second=first;first=distance;id=hash3(tileCell3(cc+71,period),seed).r;}else second=min(second,distance);}return mode==1?saturate(second-first):mode==2?id:saturate(first);}
// Wrap the unskewed integer lattice; Cartesian periods must be multiples of three.
float tileSimplex3(float3 p,float seed,float period){float3 cell=floor(p+dot(p,1.0/3.0));float3 v=p-cell+dot(cell,1.0/6.0);float3 rank=float3(v.x>=v.y?1:0,v.y>=v.z?1:0,v.z>=v.x?1:0),first=min(rank,1-rank.zxy),second=max(rank,1-rank.zxy);float sum=0;[loop]for(int i=0;i<4;i++){float3 off=i==0?0:i==1?first:i==2?second:1,cc=cell+off,d=v-off+i/6.0;float fall=max(0,.6-dot(d,d));float3 lattice=6*cc-dot(cc,1);float3 gradient=normalize(hash3(tileCell3(lattice,period*6),seed)*2-1+1e-5);sum+=fall*fall*fall*fall*dot(gradient,d);}return saturate(.5+sum*16);}
float3 rotateVector(float3 v,float3 r){float3 c=cos(r),s=sin(r);v=float3(v.x,c.x*v.y-s.x*v.z,s.x*v.y+c.x*v.z);v=float3(c.y*v.x+s.y*v.z,v.y,-s.y*v.x+c.y*v.z);return float3(c.z*v.x-s.z*v.y,s.z*v.x+c.z*v.y,v.z);}
float scalarMath(float x,float y,float z,int op){
 if(op==0)return x+y;if(op==1)return x-y;if(op==2)return x*y;if(op==3)return abs(y)>1e-6?x/y:0;
 if(op==4)return min(x,y);if(op==5)return max(x,y);if(op==6)return pow(max(x,1e-6),clamp(y,-8,8));if(op==7)return abs(x);if(op==8)return sin(x);if(op==9)return x<y;
 if(op==10)return cos(x);if(op==11)return tan(clamp(x,-1.55,1.55));if(op==12)return asin(clamp(x,-1,1));if(op==13)return acos(clamp(x,-1,1));if(op==14)return atan(x);if(op==15)return atan2(x,y+1e-8);
 if(op==16)return sqrt(max(x,0));if(op==17)return rsqrt(max(x,1e-6));if(op==18)return exp(clamp(x,-10,9));if(op==19)return log(max(x,1e-6));
 if(op==20)return floor(x);if(op==21)return ceil(x);if(op==22)return round(x);if(op==23)return trunc(x);if(op==24)return frac(x);if(op==25)return abs(y)>1e-6?fmod(x,y):0;
 if(op==26)return y>1e-6?frac(x/y)*y:0;if(op==27)return abs(y)>1e-6?round(x/y)*y:x;if(op==28)return sign(x);if(op==29)return x>y;if(op==30)return abs(x-y)<1e-5;
 if(op==31)return saturate(x);if(op==32){float h=max(.1-abs(x-y),0)/.1;return min(x,y)-h*h*.025;}if(op==33)return abs(x-y)<max(abs(z),1e-5);if(op==34)return x*y+z;if(op==35)return x>=y;if(op==36)return x*.01745329252;return x*57.2957795;
}
float3 rgbToHsv(float3 c){float4 K=float4(0,-1.0/3,2.0/3,-1);float4 p=lerp(float4(c.bg,K.wz),float4(c.gb,K.xy),step(c.b,c.g));float4 q=lerp(float4(p.xyw,c.r),float4(c.r,p.yzx),step(p.x,c.r));float d=q.x-min(q.w,q.y);return float3(abs(q.z+(q.w-q.y)/(6*d+1e-6)),d/(q.x+1e-6),q.x);}
float3 hsvToRgb(float3 c){float3 p=abs(frac(c.xxx+float3(0,2.0/3,1.0/3))*6-3);return c.z*lerp(1,saturate(p-1),saturate(c.y));}
float3 wavelengthRgb(float w){float3 c=0;
    if(w>=380&&w<440)c=float3((440-w)/60,0,1);else if(w<490&&w>=440)c=float3(0,(w-440)/50,1);else if(w<510&&w>=490)c=float3(0,1,(510-w)/20);else if(w<580&&w>=510)c=float3((w-510)/70,1,0);else if(w<645&&w>=580)c=float3(1,(645-w)/65,0);else if(w<=780&&w>=645)c=float3(1,0,0);
    float strength=w<420?lerp(.3,1,(w-380)/40):w>700?lerp(1,.3,(w-700)/80):1;return max(c,0)*saturate(strength);}
float3 approximateBlackbody(float temperature){float3 color=0;float t=clamp(temperature,1000,40000);[loop]for(int i=0;i<21;i++){float w=380+i*20,l=w*1e-9;float energy=1e-27/(pow(l,5)*max(exp(min(80,.01438776877/(l*t)))-1,1e-6));color+=wavelengthRgb(w)*energy;}return color/max(max(color.r,color.g),max(color.b,1e-6));}
#include "designer_nodes.hlsli"
float3 safeNormalize(float3 n){float lengthN=length(n);return lengthN>1e-6?n/lengthN:float3(0,0,1);}
float levels(float x){return lerp(effectOutput.x,effectOutput.y,pow(saturate((x-noiseSettings.x)/max(noiseSettings.y-noiseSettings.x,.0001)),1/max(noiseSettings.z,.05))*noiseSettings.w);}
// CUSTOM_NODE_FUNCTIONS
[numthreads(8,8,1)]
void procedural(uint3 tid:SV_DispatchThreadID) {
    bool preview=graphInfo.z>.5;
    uint2 p=preview?uint2((float2(tid.xy)+.5)*outputSettings.y/64):tid.xy; if(any(p>=uint2(outputSettings.yy))) return;
    float2 uv=(float2(p)+.5)/outputSettings.y;
    uv=(uv-.5)*uvTransform.xy;
    float ca=cos(uvOptions.x),sa=sin(uvOptions.x);
    uv=float2(ca*uv.x-sa*uv.y,sa*uv.x+ca*uv.y)+.5+uvTransform.zw;
    float4 oldC=inputColor[p],oldM=inputMaterial[p];float oldMask=inputMask[p];
    if(!preview && reserved.z==5){
        float4 c=paintColor[p],m=paintMaterial[p];uint ch=(uint)effectInfo.z;float opacity=effectInfo.x;int blend=(int)effectInfo.y;
        if(reserved.y==1)maskMap[p]=saturate(lerp(oldMask,blendValue(oldMask,c.r,blend),c.a*opacity));
        else{
            float ca=c.a*opacity,ra=m.b*opacity,ma=m.a*opacity;
            float alpha=ca+oldC.a*(1-ca);float3 value=(blendColor(oldC.rgb,c.rgb,blend)*ca+oldC.rgb*oldC.a*(1-ca))/max(alpha,1e-8);
            colorMap[p]=(ch&1)!=0?float4(saturate(value),alpha):oldC;
            float rc=ra+oldM.b*(1-ra),mc=ma+oldM.a*(1-ma);
            materialMap[p]=float4((ch&2)!=0?saturate((blendValue(oldM.r,m.r,blend)*ra+oldM.r*oldM.b*(1-ra))/max(rc,1e-8)):oldM.r,(ch&4)!=0?saturate((blendValue(oldM.g,m.g,blend)*ma+oldM.g*oldM.a*(1-ma))/max(mc,1e-8)):oldM.g,(ch&2)!=0?rc:oldM.b,(ch&4)!=0?mc:oldM.a);
            float4 priorD=channelRead(inputDetail,p),pd=paintDetail[p],pu=paintUtility[p],cov=paintExtraCoverage[p],pc=channelRead(inputCoverage,p),priorU=channelRead(inputUtility,p);
            if((ch&8)!=0){float weight=cov.r*opacity,alpha=weight+pc.r*(1-weight);float3 target=blendColor(priorD.xyz*.5+.5,pd.xyz*.5+.5,blend)*2-1;
                priorD.xyz=safeNormalize((target*weight+priorD.xyz*pc.r*(1-weight))/max(alpha,1e-8));pc.r=alpha;}
            if((ch&16)!=0){float weight=pu.a*opacity,alpha=weight+priorU.a*(1-weight);priorD.w=(blendValue(priorD.w,pd.w,blend)*weight+priorD.w*priorU.a*(1-weight))/max(alpha,1e-8);priorU.a=alpha;}
            if((ch&32)!=0){float weight=cov.g*opacity,alpha=weight+pc.g*(1-weight);priorU.r=(blendValue(priorU.r,pu.r,blend)*weight+priorU.r*pc.g*(1-weight))/max(alpha,1e-8);pc.g=alpha;}
            float4 pe=channelRead(inputEmission,p);
            if((ch&64)!=0){float weight=cov.b*opacity,alpha=weight+pc.b*(1-weight);pe.rgb=(blendColor(pe.rgb,paintEmission[p].rgb,blend)*weight+pe.rgb*pc.b*(1-weight))/max(alpha,1e-8);pc.b=alpha;}
            if((ch&128)!=0){float weight=cov.a*opacity,alpha=weight+pc.a*(1-weight);priorU.g=(blendValue(priorU.g,pu.g,blend)*weight+priorU.g*pc.a*(1-weight))/max(alpha,1e-8);pc.a=alpha;}
            detailMap[p]=priorD;utilityMap[p]=priorU;emissionMap[p]=pe;coverageMap[p]=pc;
        }return;
    }
    if(!preview && reserved.y>0 && reserved.z!=3 && reserved.z!=6) {
        float3 newC=oldC.rgb;float2 newM=oldM.rg;float newMask=oldMask;
        if(reserved.z==1){newC=float3(levels(oldC.r),levels(oldC.g),levels(oldC.b));newM=float2(levels(oldM.r),levels(oldM.g));newMask=levels(oldMask);}
        if(reserved.z==2){newC=1-oldC.rgb;newM=1-oldM.rg;newMask=1-oldMask;}
        if(reserved.z==4){int r=(int)noiseSettings.x;float3 sumC=0;float2 sumM=0;float sumS=0;float count=0;
            [loop]for(int y=-r;y<=r;y++)[loop]for(int x=-r;x<=r;x++){int2 q=clamp(int2(p)+int2(x,y),int2(0,0),int2(outputSettings.yy)-1);sumC+=inputColor[q].rgb;sumM+=inputMaterial[q].rg;sumS+=inputMask[q];count++;}
            newC=sumC/count;newM=sumM/count;newMask=sumS/count;}
        if(reserved.y==1)maskMap[p]=saturate(lerp(oldMask,blendValue(oldMask,newMask,(int)effectInfo.y),effectInfo.x));
        else {uint channels=(uint)effectInfo.z;colorMap[p]=float4((channels&1)!=0?lerp(oldC.rgb,saturate(newC),effectInfo.x):oldC.rgb,oldC.a);
            materialMap[p]=float4((channels&2)!=0?lerp(oldM.r,saturate(newM.x),effectInfo.x):oldM.r,(channels&4)!=0?lerp(oldM.g,saturate(newM.y),effectInfo.x):oldM.g,oldM.ba);
            float4 d=channelRead(inputDetail,p),e=channelRead(inputEmission,p),u=channelRead(inputUtility,p);
            float height=d.w,ao=u.r,surfaceOpacity=u.g;float3 emissive=e.rgb;
            if(reserved.z==1){height=levels(height*.5+.5)*2-1;ao=levels(ao);surfaceOpacity=levels(surfaceOpacity);emissive=float3(levels(e.r),levels(e.g),levels(e.b));}
            if(reserved.z==2){height=-height;ao=1-ao;surfaceOpacity=1-surfaceOpacity;emissive=1-emissive;}
            if(reserved.z==4){int radius=(int)noiseSettings.x;float hh=0,aa=0,oo=0;float3 ee=0;float count=0;
              [loop]for(int y=-radius;y<=radius;y++)[loop]for(int x=-radius;x<=radius;x++){int2 q=clamp(int2(p)+int2(x,y),int2(0,0),int2(outputSettings.yy)-1);hh+=channelRead(inputDetail,q).w;aa+=channelRead(inputUtility,q).r;oo+=channelRead(inputUtility,q).g;ee+=channelRead(inputEmission,q).rgb;count++;}height=hh/count;ao=aa/count;surfaceOpacity=oo/count;emissive=ee/count;}
            detailMap[p]=float4(d.xyz,(channels&16)!=0?lerp(d.w,height,effectInfo.x):d.w);
            utilityMap[p]=float4((channels&32)!=0?lerp(u.r,ao,effectInfo.x):u.r,(channels&128)!=0?lerp(u.g,surfaceOpacity,effectInfo.x):u.g,u.zw);
            emissionMap[p]=float4((channels&64)!=0?lerp(e.rgb,emissive,effectInfo.x):e.rgb,e.a);
        }
        return;
    }
    float n=noise(uv*noiseSettings.x)*.65+noise(uv*noiseSettings.x*3.7)*.35;
    if(reserved.x==1) n=geometryPosition[p].g;
    if(reserved.x==2) n=.5+.5*sin(uv.y*noiseSettings.x*6.283185+n*2);
    float width=max(noiseSettings.w,.001);float mask=smoothstep(noiseSettings.z-width,noiseSettings.z+width,n);
    float materialCoverage=1;
    float3 color=lerp(primary.rgb,secondary.rgb,mask*outputSettings.z);
    float rough=saturate(primary.a+(mask-.5)*outputSettings.x*2*outputSettings.w);
    float metallic=secondary.a,graphMask=oldMask;float4 detail=channelRead(inputDetail,p),emission=channelRead(inputEmission,p),utility=channelRead(inputUtility,p);float4 nodeResult=0;
    if(graphInfo.x>0) {
#ifndef GRAPH_VALUE_CAP
#define GRAPH_VALUE_CAP 128
#endif
        float4 values[GRAPH_VALUE_CAP];
        [loop]for(int i=0;i<(int)graphInfo.x;i++) {
            NodeData node=nodes[i];if(node.links1.z<.5){values[i]=0;continue;}int kind=(int)node.meta.x;
            float4 a=converted(node.meta.y>=0?values[(int)node.meta.y]:0,(int)node.convert0.x);
            float4 b=converted(node.meta.z>=0?values[(int)node.meta.z]:1,(int)node.convert0.y);
            float4 c=converted(node.meta.w>=0?values[(int)node.meta.w]:0,(int)node.convert0.z);
            float4 value=0;
            float2 nuv=node.meta.y>=0?a.xy:uv;float3 coord=node.meta.y>=0?a.xyz:float3(uv,0);int op=(int)node.reserved.y;
            if(kind>=143){switch(kind){
#include "designer_cases.hlsli"
                default: break;
            }}else switch(kind) {
#if !defined(SPECIALIZED_NODES) || defined(NODE_108)
            case 108: {value=simulationAt((int)node.reserved.x,(float2(p)+.5)/outputSettings.y).xxxx;break;}
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_91)
            case 91: { value=a; break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_93)
            case 93: { value=float4(uv,0,0); break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_94)
            case 94: { {
                int map=(int)node.reserved.y;float2 q=node.meta.y>=0?a.xy:(float2(p)+.5)/outputSettings.y;
                float4 tex=imageNodeAt((int)node.reserved.x,q,1,map==6?1:0,node.reserved.zw);
                if(node.reserved.x<0||tex.a<=0)tex=map==0?float4(.5,.5,1,1):(map==1||map==7)?geometryNormal[p]:map==4?geometryPosition[p]:map==2?1:(map==3||map==8)?float4(.5,.5,.5,1):0;
                if(map==0||map==1||map==7){float3 n=tex.xyz*2-1;if(map==0&&node.extra1.w>.5)n.y=-n.y;value=float4(safeNormalize(n),0);}
                else if(map==4||map==6)value=tex;else if(map==8)value=(tex.x*2-1).xxxx;else value=tex.xxxx;
            } break; }
#endif
#ifdef CUSTOM_NODES
#if !defined(SPECIALIZED_NODES) || defined(NODE_92)
            case 92: { {
                float4 d=node.links0.x>=0?converted(values[(int)node.links0.x],(int)node.convert0.w):0;
                float4 e=node.links0.y>=0?converted(values[(int)node.links0.y],(int)node.convert1.x):0;
                float4 f=node.links0.z>=0?converted(values[(int)node.links0.z],(int)node.convert1.y):0;
                float4 g=node.links0.w>=0?converted(values[(int)node.links0.w],(int)node.convert1.z):0;
                float4 h=node.links1.x>=0?converted(values[(int)node.links1.x],(int)node.convert1.w):0;
                value=surfaceCustomEval(i,node.meta.y>=0?a:0,node.meta.z>=0?b:0,node.meta.w>=0?c:0,d,e,f,g,h,uv,geometryPosition[p].xyz*2-1,geometryNormal[p].xyz*2-1);
                value=all(isfinite(value))?value:0;
            } break; }
#endif
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_95)
            case 95: { {float feather=max(.00001,(1-saturate(node.parameters.y))*.5);value=smoothstep(node.parameters.x-feather,node.parameters.x+feather,a.x).xxxx;} break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_96)
            case 96: { value=saturate((a.x-.5)*node.parameters.x+node.parameters.y).xxxx; break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_97)
            case 97: { {float halfRange=max(.00001,node.parameters.y*.5),feather=max(.00001,node.parameters.z);value=(1-smoothstep(halfRange,halfRange+feather,abs(a.x-node.parameters.x))).xxxx;} break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_98)
            case 98: { value=op==1?float4(pow(saturate((a.rgb-node.parameters.x)/max(.00001,node.parameters.y-node.parameters.x)),1/max(.05,node.parameters.z))*node.parameters.w,a.a):pow(saturate((a.x-node.parameters.x)/max(.00001,node.parameters.y-node.parameters.x)),1/max(.05,node.parameters.z))*node.parameters.w; break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_99)
            case 99: { float opacity=saturate(node.meta.w>=0?c.x:node.parameters.x);value=float4(lerp(a.rgb,blendColor(a.rgb,b.rgb,op),opacity),lerp(a.a,b.a,opacity));if(node.links1.y==5)value=float4(safeNormalize(value.xyz),0);break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_100) || defined(NODE_101) || defined(NODE_102)
            case 100:case 101:case 102: { {
                float2 q=(float2(p)+.5)/outputSettings.y;int slot=(int)node.reserved.x;float radius=clamp(node.parameters.x,0,64);
                if(kind==101 && node.meta.z>=0)radius*=saturate(fieldAt(slot+1,q).x);
                float4 sum=0;float total=0;
                if(kind==100){
                  int extent=(int)ceil(radius);
                  [loop]for(int j=-extent;j<=extent;j++){
                    float edge=saturate(radius+.5-abs(j));float w=node.extra0.x>.5?edge:exp(-2*j*j/max(radius*radius,.0001))*edge;
                    float angle=node.parameters.y*.0174532925;
                    sum+=filterTap(slot,q+float2(cos(angle),sin(angle))*j/outputSettings.y,(int)node.links1.y)*w;total+=w;
                  }
                }else{
                  // Deterministic disk sampling: more coverage, no random frame-to-frame grain.
                  [loop]for(int j=0;j<128;j++){
                    float angle=j*2.39996323,fraction=sqrt((j+.5)/128.0);
                    float w=exp(-2*fraction*fraction);
                    sum+=filterTap(slot,q+float2(cos(angle),sin(angle))*fraction*radius/outputSettings.y,(int)node.links1.y)*w;total+=w;
                  }
                }
                value=sum/max(total,.001);
                if(node.links1.y==1)value.rgb=value.a>1e-8?value.rgb/value.a:0;
                if(node.links1.y==5)value.xyz=safeNormalize(value.xyz);
                if(kind==102){float4 original=fieldAt(slot,q);value=float4(saturate(.5+(original.rgb-value.rgb)*node.parameters.z),original.a);}
            } break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_103)
            case 103: { {float2 q=(float2(p)+.5)/outputSettings.y;value=fieldAt((int)node.reserved.x,q+fieldAt((int)node.reserved.x+1,q).xy*node.parameters.x);} break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_104)
            case 104: { {float3 n=a.xyz;n.x=op==1||op==3?-n.x:n.x;n.y=op==0||op==3?-n.y:n.y;n.z=op==2||op==3?-n.z:n.z;value=float4(safeNormalize(n),0);} break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_105)
            case 105: { value=float4(safeNormalize(a.xyz),0); break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_106) || defined(NODE_107)
            case 106:case 107: { {float period=kind==106?max(3,round(node.parameters.x/3)*3):tileScale(node.parameters.x);float3 q=coord*period;float sum=0,total=0,amp=1;
                [loop]for(int octave=0;octave<clamp((int)node.parameters.z,1,8);octave++){
                  float v=kind==106?tileSimplex3(q,node.parameters.y+octave,period):tileCellular3(q,node.parameters.y+octave,op,period);
                  sum+=v*amp;total+=amp;amp*=clamp(node.parameters.w,.01,.99);q*=2;period*=2;
                }value=saturate(sum/max(.001,total)).xxxx;} break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_109)
            case 109: { {
                float3 position=(node.meta.y>=0?coord:geometryPosition[p].xyz)*2-1;
                float3 rotation=float3(node.extra0.w,node.extra1.x,node.extra1.y)*.01745329252;
                float3 right=rotateVector(float3(1,0,0),rotation),up=rotateVector(float3(0,1,0),rotation),forward=rotateVector(float3(0,0,1),rotation);
                float3 delta=position-node.extra0.xyz;
                float3 local=float3(dot(delta,right),dot(delta,up),dot(delta,forward))/max(node.parameters.xyz,.001);
                float2 q=float2(local.x,-local.y)+.5;
                bool inside=all(abs(local)<=.5)&&geometryPosition[p].a>0;
                float facing=dot(safeNormalize(geometryNormal[p].xyz*2-1),forward);
                float fade=node.extra1.z;
                float edge=fade>0?smoothstep(0,fade,min(.5-abs(local.x),.5-abs(local.y))):1;
                float4 tex=node.reserved.x>=0?imageNodeAt((int)node.reserved.x,q,1,0,node.reserved.zw):float4(1,1,1,1);
                float alpha=inside&&facing>=node.extra1.w?saturate(tex.a*edge*node.parameters.w):0;
                value=op==1?alpha.xxxx:float4(imageWorking(tex.rgb,(int)node.links1.w),alpha);
            } break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_0)
            case 0: { value=node.parameters.xxxx; break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_1)
            case 1: { value=float4(node.parameters.rgb,1); break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_2)
            case 2: { {float scale=tileScale(node.parameters.x),fine=tileScale(scale*3.7);float n=tileNoise(nuv*scale,node.parameters.y,scale.xx)*.65+tileNoise(nuv*fine,node.parameters.y,fine.xx)*.35;if(node.parameters.z>.5)n=.5+.5*sin(nuv.y*scale*6.283185+n*2);value=n.xxxx;} break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_3)
            case 3: { value=geometryPosition[p].gggg; break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_4)
            case 4: { {float lo=node.parameters.x,hi=node.parameters.y;float t=saturate((a.x-lo)/(abs(hi-lo)<.0001?.0001:hi-lo));value=(t*t*(3-2*t)).xxxx;} break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_5) || defined(NODE_6)
            case 5:case 6: { value=lerp(a,b,saturate(c.x)); break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_8)
            case 8: { value=oldC; break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_9)
            case 9: { value=oldM.rrrr; break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_10)
            case 10: { value=oldM.gggg; break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_11)
            case 11: { value=oldMask.xxxx; break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_12)
            case 12: { value=geometryNormal[p].gggg; break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_13)
            case 13: { value=anchorC((int)node.reserved.x,p); break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_14)
            case 14: { {int slot=(int)node.reserved.x,channel=(int)node.reserved.y;float4 ac=anchorC(slot,p),am=anchorM(slot,p);float av=dot(ac.rgb,float3(.2126,.7152,.0722));if(channel==1)av=am.r;if(channel==2)av=am.g;if(channel==3){av=node.reserved.z>.5?anchorS(slot,p):1;if(node.reserved.z>.5&&node.reserved.w>.5)av=1-av;}if(channel==4)av=ac.a;value=av.xxxx;} break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_16) || defined(NODE_17)
            case 16:case 17: { {
                float angle=node.parameters.w*.0174532925;
                float2 q=imageUV(nuv,node.parameters.xy,angle,node.extra0.xy);
                int filter=node.extra0.w<.5?(int)uvOptions.z:(int)node.extra0.w-1;
                float4 tex=imageNodeAt((int)node.reserved.x,q,node.extra0.z<.5?(int)uvOptions.y:(int)node.extra0.z-1,filter,node.reserved.zw);
                bool linearized=false;
                if(node.meta.y>=0 && a.w<=-8){
                  float sharp=clamp((-a.w-8)*100,1,16);
                  float3 projectionNormal=geometryNormal[p].xyz*2-1;
                  NodeData coordinateSource=nodes[(int)node.meta.y];
                  if(coordinateSource.meta.x==38){
                    float3 projectionScale=coordinateSource.parameters.xyz;
                    projectionNormal/=max(abs(projectionScale),.0001);
                    projectionNormal=rotateVector(projectionNormal,float3(coordinateSource.extra0.w,coordinateSource.extra1.x,coordinateSource.extra1.y)*.0174532925);
                  }
                  float3 w=pow(abs(safeNormalize(projectionNormal)),sharp);w/=max(dot(w,1),1e-6);
                  int wr=node.extra0.z<.5?(int)uvOptions.y:(int)node.extra0.z-1;
                  float4 tx=imageNodeAt((int)node.reserved.x,imageUV(a.zy,node.parameters.xy,angle,node.extra0.xy),wr,filter,node.reserved.zw);
                  float4 ty=imageNodeAt((int)node.reserved.x,imageUV(a.xz,node.parameters.xy,angle,node.extra0.xy),wr,filter,node.reserved.zw);
                  float4 tz=imageNodeAt((int)node.reserved.x,imageUV(a.xy,node.parameters.xy,angle,node.extra0.xy),wr,filter,node.reserved.zw);
                  if(kind==16){tx.rgb=imageWorking(tx.rgb,(int)node.parameters.z);ty.rgb=imageWorking(ty.rgb,(int)node.parameters.z);tz.rgb=imageWorking(tz.rgb,(int)node.parameters.z);linearized=true;}
                  tex=tx*w.x+ty*w.y+tz*w.z;
                }
                if(kind==16){value=float4(!linearized?imageWorking(tex.rgb,(int)node.parameters.z):tex.rgb,tex.a);}
                else{int ch=(int)node.reserved.y;float v=ch==1?tex.r:ch==2?tex.g:ch==3?tex.b:ch==4?tex.a:dot(tex.rgb,float3(.2126,.7152,.0722));value=v.xxxx;}} break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_18)
            case 18: { {float scale=max(2,round(node.parameters.x*.5)*2);float2 q=floor(nuv*scale);value=(abs(fmod(q.x+q.y,2))).xxxx;} break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_19)
            case 19: { {float t=node.reserved.y==1?nuv.y:node.reserved.y==2?length(nuv-.5)*1.4142:nuv.x;value=saturate(t).xxxx;} break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_20)
            case 20: { float scale=tileScale(node.parameters.x);value=tileHash(floor(nuv*scale),node.parameters.y,scale).xxxx; break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_21)
            case 21: { {float scale=tileScale(node.parameters.x);float2 q=nuv*scale,cell=floor(q);float dist=10;
                [loop]for(int y=-1;y<=1;y++)[loop]for(int x=-1;x<=1;x++){float2 c=cell+float2(x,y);float2 feature=c+float2(tileHash(c,node.parameters.y,scale),tileHash(c,node.parameters.y+31,scale));dist=min(dist,length(q-feature));}value=saturate(dist).xxxx;} break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_22)
            case 22: { {float sum=0,amp=1,weight=0;float period=tileScale(node.parameters.x);float2 q=nuv*period;
                [loop]for(int o=0;o<min(8,(int)max(1,node.parameters.z));o++){sum+=tileNoise(q,node.parameters.y+o,period.xx)*amp;period*=2;weight+=amp;amp*=clamp(node.parameters.w,.05,.95);q*=2;}value=(sum/max(weight,.001)).xxxx;} break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_23)
            case 23: { value=op==1?float4(1-a.rgb,a.a):(1-a.x).xxxx; break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_24)
            case 24: { value=op==1?float4(clamp(a.rgb,min(node.parameters.x,node.parameters.y),max(node.parameters.x,node.parameters.y)),a.a):clamp(a.x,min(node.parameters.x,node.parameters.y),max(node.parameters.x,node.parameters.y)).xxxx; break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_25)
            case 25: { {float x=node.meta.y>=0?a.x:node.parameters.x,y=node.meta.z>=0?b.x:node.parameters.y,z=node.meta.w>=0?c.x:node.parameters.z;value=clamp(scalarMath(x,y,z,op),-10000,10000).xxxx;} break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_26)
            case 26: { value=dot(a.rgb,float3(.2126,.7152,.0722)).xxxx; break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_27)
            case 27: { value=float4(lerp(node.extra0.rgb,node.parameters.rgb,saturate(a.x)),1); break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_28)
            case 28: { value=op==1?float4(pow(max(a.rgb,0),1/max(.05,node.parameters.x)),a.a):pow(max(a.x,0),1/max(.05,node.parameters.x)).xxxx; break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_29)
            case 29: { value=op==1?float4(saturate((a.rgb-.5)*node.parameters.y+.5+node.parameters.x),a.a):saturate((a.x-.5)*node.parameters.y+.5+node.parameters.x).xxxx; break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_30)
            case 30: { value=uv.xxxx; break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_31)
            case 31: { value=uv.yyyy; break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_32)
            case 32: { value=geometryPosition[p].rrrr; break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_33)
            case 33: { value=geometryPosition[p].bbbb; break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_34)
            case 34: { value=geometryNormal[p].rrrr; break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_35)
            case 35: { value=geometryNormal[p].bbbb; break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_36)
            case 36: { {float t=node.reserved.y==1?nuv.y:node.reserved.y==2?length(nuv-.5):nuv.x;value=(.5+.5*sin(t*tileScale(node.parameters.x)*6.283185+node.parameters.y)).xxxx;} break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_37)
            case 37: { value=float4(node.parameters.xyz,0); break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_38)
            case 38: {
 float3 position=geometryPosition[p].xyz,normal=geometryNormal[p].xyz*2-1;
 float3 q=op==1?position:op==2?normal:float3(op==3?(float2(p)+.5)/outputSettings.y:uv,0);
 int axis=(int)node.extra1.w;float3 local=axis==0?position.yzx:axis==2?position.xzy:position;
 float2 radial=local.xz-.5;float angle=atan2(radial.y,radial.x)/6.2831853+.5;
 if(op==4){float2 r=uv-.5;q=float3(atan2(r.y,r.x)/6.2831853+.5,length(r)*2,0);}
 if(op==5)q=float3(angle,local.y,0);
 if(op==6){float3 d=local-.5;q=float3(angle,acos(clamp(d.y/max(length(d),1e-6),-1,1))/3.14159265,0);}
 if(op==7){float3 n=abs(normal);q=n.x>=n.y&&n.x>=n.z?float3(position.zy,0):n.y>=n.z?float3(position.xz,0):float3(position.xy,0);}
 if(op==8)q=position;
 float3 scale=all(node.parameters.xyz==0)?1:node.parameters.xyz;
 q=rotateVector((q-.5)*scale,float3(node.extra0.w,node.extra1.x,node.extra1.y)*.0174532925)+.5+node.extra0.xyz;
 value=float4(q,op==8?-8-clamp(node.extra1.z,1,16)*.01:0);break;
 }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_39)
            case 39: { value=a[clamp(op,0,3)].xxxx; break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_40)
            case 40: { value=float4(a.x,b.x,c.x,0); break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_41)
            case 41: { value=float4(rotateVector(coord*node.parameters.xyz+node.extra0.xyz,float3(node.extra0.w,node.extra1.x,node.parameters.w)*.0174532925),0); break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_42)
            case 42: { {float3 x=a.xyz,y=b.xyz,r=0;float scale=node.meta.w>=0?c.x:node.parameters.x;
                if(op==0)r=x+y;if(op==1)r=x-y;if(op==2)r=x*y;if(op==3)r=float3(abs(y.x)>1e-6?x.x/y.x:0,abs(y.y)>1e-6?x.y/y.y:0,abs(y.z)>1e-6?x.z/y.z:0);
                if(op==4)r=cross(x,y);if(op==5)r=length(x)>1e-6?normalize(x):0;if(op==6)r=dot(x,y).xxx;if(op==7)r=length(x).xxx;if(op==8)r=length(x-y).xxx;if(op==9)r=x*scale;
                if(op==10)r=y*dot(x,y)/max(dot(y,y),1e-6);if(op==11)r=reflect(x,safeNormalize(y));if(op==12)r=refract(safeNormalize(x),safeNormalize(y),scale);if(op==13)r=min(x,y);if(op==14)r=max(x,y);if(op==15)r=floor(x);if(op==16)r=frac(x);if(op==17)r=abs(x);if(op==18)r=sin(x);value=float4(r,0);} break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_43)
            case 43: { value=float4(rotateVector(coord,node.parameters.xyz*.0174532925),0); break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_44)
            case 44: { {float period=tileScale(node.parameters.x);float3 q=coord*period;float sum=0,total=0,amp=1;[loop]for(int octave=0;octave<clamp((int)node.parameters.z,1,8);octave++){float v=tilePerlin3(q,node.parameters.y+octave,period);if(op==1)v=1-abs(v*2-1);if(op==2)v=abs(v*2-1);sum+=v*amp;total+=amp;amp*=clamp(node.parameters.w,.01,.99);q*=2;period*=2;}value=saturate(sum/max(total,.001)).xxxx;} break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_45)
            case 45: {float period=tileScale(node.parameters.x);value=tileCellular3(coord*period,node.parameters.y,op,period).xxxx;break;}
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_46)
            case 46: { {float scale=max(2,round(node.parameters.x*.5)*2);float2 q=nuv*scale;q.x+=abs(fmod(floor(q.y),2))*node.parameters.z;float2 f=frac(q);float gap=clamp(node.parameters.y,.001,.4);value=(f.x>gap&&f.x<1-gap&&f.y>gap&&f.y<1-gap?1:0).xxxx;} break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_47)
            case 47: { {float3 q=coord*tileScale(node.parameters.x)*6.283185;float m=sin(q.x+sin(q.y)*node.parameters.y*10)*cos(q.y+sin(q.z+q.x)*node.parameters.y*10);value=(m*.5+.5).xxxx;} break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_48)
            case 48: { {float3 hsv=rgbToHsv(max(a.rgb,0));hsv.x=frac(hsv.x+node.parameters.x);hsv.y*=node.parameters.y;hsv.z*=node.parameters.z;value=float4(hsvToRgb(hsv),a.a);} break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_49)
            case 49: { value=a[clamp(op,0,3)].xxxx; break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_50)
            case 50: { value=float4(a.x,b.x,c.x,1); break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_51)
            case 51: { value=float4(approximateBlackbody(node.parameters.x),1); break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_52)
            case 52: { value=float4(wavelengthRgb(node.parameters.x),1); break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_53)
            case 53: { value=float4(blendColor(a.rgb,b.rgb,op),a.a); break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_54)
            case 54: { {float delta=node.parameters.y-node.parameters.x;float t=abs(delta)>1e-6?(a.x-node.parameters.x)/delta:0;if(op==1)t=saturate(t);value=lerp(node.parameters.z,node.parameters.w,t).xxxx;} break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_55)
            case 55: { {float t=saturate(a.x),u=1-t;value=(u*u*u*node.parameters.x+3*u*u*t*node.parameters.y+3*u*t*t*node.parameters.z+t*t*t*node.parameters.w).xxxx;} break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_56)
            case 56: { value=(node.parameters.x>.5?1:0).xxxx; break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_57)
            case 57: { value=round(node.parameters.x).xxxx; break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_58)
            case 58: { {float tolerance=max(abs(node.parameters.x),1e-6);bool result=op==0?a.x<b.x:op==1?a.x>b.x:op==2?abs(a.x-b.x)<tolerance:op==3?a.x<=b.x:op==4?a.x>=b.x:abs(a.x-b.x)>=tolerance;value=(result?1:0).xxxx;} break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_59)
            case 59: { value=c.x>.5?b:a; break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_60)
            case 60: { {float3 n=(node.meta.y>=0?a.rgb:float3(.5,.5,1))*2-1;n.xy*=node.parameters.x;if(op==1)n.y=-n.y;value=float4(safeNormalize(n),0);} break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_61)
            case 61: { {float3 n1=node.meta.y>=0?a.xyz:float3(0,0,1),n2=node.meta.z>=0?b.xyz:float3(0,0,1);float3 n=op==2?combineNormalHeight(n1,safeNormalize(lerp(float3(0,0,1),n2,saturate(node.parameters.x)))):op==1?lerp(n1,float3(n1.xy+n2.xy,n1.z*n2.z),saturate(node.parameters.x)):lerp(n1,n2,saturate(node.parameters.x));value=float4(safeNormalize(n),0);} break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_62)
            case 62: { {float weight=saturate(c.x+(b.x-a.x)*node.parameters.x);value=lerp(a.x,b.x,weight).xxxx;} break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_63)
            case 63: { value=length(a.xyz-b.xyz).xxxx; break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_64)
            case 64: { {float3 n=node.meta.y>=0?safeNormalize(coord):geometryNormal[p].xyz*2-1;value=pow(saturate(1-abs(n.z)),max(.01,node.parameters.x)).xxxx;} break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_65)
            case 65: { {float2 q=coord.xy-.5;value=float4((atan2(q.y,q.x)/6.283185+.5)*node.parameters.x,length(q)*node.parameters.y,0,0);} break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_66)
            case 66: { {float steps=max(2,round(node.parameters.x))-1;value=op==1?float4(round(saturate(a.rgb)*steps)/steps,a.a):(round(saturate(a.x)*steps)/steps).xxxx;} break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_67)
            case 67: { {float d=node.parameters.y-node.parameters.x,t=abs(d)>1e-6?saturate((a.x-node.parameters.x)/d):0;value=(t*t*(3-2*t)).xxxx;} break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_68)
            case 68: { float scale=tileScale(node.parameters.y);value=hash3(tileCell3(floor(coord*scale),scale),node.parameters.x).rrrr; break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_69)
            case 69: { {float2 q=frac(nuv*tileScale(node.parameters.x))-.5;float r=.5-clamp(node.parameters.y,0,.49);bool inside=op==1?length(q)<r:op==2?abs(q.x)+abs(q.y)<r:op==3?max(.8660254*abs(q.x)+.5*abs(q.y),abs(q.y))<r:all(abs(q)<r);value=(inside?1:0).xxxx;} break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_70)
            case 70: { {float2 q=coord.xy-.5;float r=node.parameters.x,h=node.parameters.y;float distance=op==1?max(abs(q.x)-r,abs(q.y)-h):op==2?abs(length(q)-r)-h:op==3?(abs(q.x)+abs(q.y)-r)*.7071068:op==4?max(.8660254*abs(q.x)+.5*abs(q.y),abs(q.y))-r:length(q)-r;value=(node.parameters.z>.5?distance:1-smoothstep(-.002,.002,distance)).xxxx;} break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_71)
            case 71: { value=(op==3?saturate(length(coord-.5)*1.1547):coord[clamp(op,0,2)]).xxxx; break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_72)
            case 72: { {float3 q=coord,v=0;if(op==0)v=float3(length(q.xy),atan2(q.y,q.x)/6.283185+.5,q.z);if(op==1)v=float3(q.x*cos((q.y-.5)*6.283185),q.x*sin((q.y-.5)*6.283185),q.z);if(op==2){float len=length(q);v=float3(len,atan2(q.z,q.x)/6.283185+.5,len>1e-6?acos(clamp(q.y/len,-1,1))/3.141593:0);}if(op==3){float angle=(q.y-.5)*6.283185,elev=q.z*3.141593;v=float3(q.x*sin(elev)*cos(angle),q.x*cos(elev),q.x*sin(elev)*sin(angle));}value=float4(v,0);} break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_73)
            case 73: { value=float4(op==0?toLinear(a.rgb):op==1?toDisplay(a.rgb):op==2?rgbToHsv(a.rgb):hsvToRgb(a.rgb),a.a); break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_74)
            case 74: { {float scale=tileScale(node.parameters.x);float2 q=nuv*scale;float n=tileNoise(q,node.parameters.y,scale.xx);if(op==1)n=1-abs(n*2-1);if(op==2)n=smoothstep(.3,.7,n);if(op==3)n=tileHash(floor(q),node.parameters.y,scale);if(op==4)n=.5+.5*sin(q.y*6.283185+tileNoise(nuv*max(1,round(scale*.2)),node.parameters.y,max(1,round(scale*.2)).xx)*4);if(op==5){float2 cell=floor(q);float d=10;[loop]for(int y=-1;y<=1;y++)[loop]for(int x=-1;x<=1;x++){float2 c=cell+float2(x,y);d=min(d,length(q-c-float2(tileHash(c,node.parameters.y,scale),tileHash(c+13,node.parameters.y,scale))));}n=1-smoothstep(.1,.3,d);}if(op==6){float2 period=max(1,round(scale*float2(8,.25)));n=tileNoise(nuv*period,node.parameters.y,period);}if(op==7)n=n*n*n;if(op==8)n=1-pow(1-n,3);value=n.xxxx;} break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_15)
            case 15: { {graphMask=node.meta.y>=0?saturate(a.x):oldMask;value=graphMask.xxxx;} break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_75)
            case 75: { value=float4(channelRead(inputDetail,p).xyz,0); break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_76)
            case 76: { value=channelRead(inputDetail,p).wwww; break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_77)
            case 77: { value=channelRead(inputUtility,p).rrrr; break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_78)
            case 78: { value=channelRead(inputEmission,p); break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_79)
            case 79: { value=channelRead(inputUtility,p).gggg; break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_80)
            case 80: {value=fieldAt((int)node.reserved.x,(float2(p)+.5)/outputSettings.y);break;}
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_110)
            case 110: {float2 uv=(float2(p)+.5)/outputSettings.y,q=frac(uv-node.parameters.xy);
                value=seamBlend((int)node.reserved.x,q,node.parameters.zw,(int)node.links1.y);break;}
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_112)
            case 112: {value=lerp(a,fieldAt((int)node.reserved.x,(float2(p)+.5)/outputSettings.y),node.parameters.x);if(node.links1.y==5)value.xyz=safeNormalize(value.xyz);break;}
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_142)
            case 142: {
                float2 uv=node.meta.z>=0?b.xy:(float2(p)+.5)/outputSettings.y;
                float2 q=uv*node.parameters.xy-.5;
                float angle=node.parameters.z*.01745329252,co=cos(angle),si=sin(angle);
                q=float2(co*q.x+si*q.y,-si*q.x+co*q.y)+.5+node.extra0.xy;
                value=sampleField((int)node.reserved.x,q,(int)node.links1.y,op,(int)node.extra0.z);break;
            }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_139)
            case 139: {
                int type=(int)node.links1.y;
                value=node.meta.y>=0?a:node.parameters;
                if(type==0)value=value.xxxx;
                else if(type==2)value=float4(value.xyz,0);
                else if(type==3)value=(value.x>.5?1:0).xxxx;
                else if(type==4)value=round(value.x).xxxx;
                else if(type==5)value=float4(safeNormalize(value.xyz),0);
                break;
            }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_113)
            case 113: {value=a;break;}
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_111)
            case 111: {float2 q=(float2(p)+.5)/outputSettings.y;
                value=seamBlend((int)node.reserved.x,q,node.parameters.xy,(int)node.links1.y);break;}
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_81)
            case 81: { {float2 q=(float2(p)+.5)/outputSettings.y-.5;float angle=node.parameters.z*.0174532925;float co=cos(angle),si=sin(angle);q=float2(co*q.x+si*q.y,-si*q.x+co*q.y)/max(abs(node.parameters.xy),.001);value=fieldAt((int)node.reserved.x,q+.5+node.extra0.xy);} break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_82) || defined(NODE_83)
            case 82:case 83: { {float2 direction=kind==82?b.xy:float2(cos(node.parameters.y*.0174532925),sin(node.parameters.y*.0174532925))*b.x;value=fieldAt((int)node.reserved.x,(float2(p)+.5)/outputSettings.y+direction*node.parameters.x);} break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_84) || defined(NODE_85) || defined(NODE_88)
            case 84:case 85:case 88: { {int slot=(int)node.reserved.x;float2 q=(float2(p)+.5)/outputSettings.y,stepUV=1.0/outputSettings.yy;
                float4 l=converted(fieldAt(slot,q-float2(stepUV.x,0)),(int)node.convert0.x),r=converted(fieldAt(slot,q+float2(stepUV.x,0)),(int)node.convert0.x),up=converted(fieldAt(slot,q-float2(0,stepUV.y)),(int)node.convert0.x),down=converted(fieldAt(slot,q+float2(0,stepUV.y)),(int)node.convert0.x);
                float2 gradient=float2(r.x-l.x,down.x-up.x)*.5*outputSettings.y;
                if(kind==84){float3 nn=normalize(float3(-gradient.x*node.parameters.x,(op==1?1:-1)*gradient.y*node.parameters.x,1));value=float4(combineNormalHeight(node.meta.z>=0?b.xyz:float3(0,0,1),nn),0);}
                if(kind==85)value=saturate(length(gradient)*node.parameters.x).xxxx;
                if(kind==88)value=saturate(.5+(r.x-l.x+down.y-up.y)*outputSettings.y*node.parameters.x*.25).xxxx;
            } break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_86)
            case 86: { {int radius=clamp((int)node.parameters.x,1,8);float result=op==1?1e10:-1e10;[loop]for(int y=-radius;y<=radius;y++)[loop]for(int x=-radius;x<=radius;x++){float v=converted(fieldAt((int)node.reserved.x,(float2(p)+.5+float2(x,y))/outputSettings.y),(int)node.convert0.x).x;result=op==1?min(result,v):max(result,v);}value=result.xxxx;} break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_87)
            case 87: { {float2 q=(float2(p)+.5)/outputSettings.y;int count=clamp((int)node.parameters.y,1,8),slot=(int)node.reserved.x;float4 sum=0,result=fieldAt(slot,q);float2 stepUV=1.0/outputSettings.yy;
                [loop]for(int j=0;j<count;j++){float l=converted(fieldAt(slot+1,q-float2(stepUV.x,0)),(int)node.convert0.y).x,r=converted(fieldAt(slot+1,q+float2(stepUV.x,0)),(int)node.convert0.y).x,up=converted(fieldAt(slot+1,q-float2(0,stepUV.y)),(int)node.convert0.y).x,dn=converted(fieldAt(slot+1,q+float2(0,stepUV.y)),(int)node.convert0.y).x;
                    q+=float2(r-l,dn-up)*node.parameters.x*stepUV;float4 sample=fieldAt(slot,q);sum+=sample;result=op==1?min(result,sample):max(result,sample);}
                value=op==0?sum/count:result;
            } break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_89)
            case 89: { {float3 q=node.meta.y>=0?coord:geometryPosition[p].xyz;float3 n=abs(geometryNormal[p].xyz*2-1);n=pow(n,max(node.parameters.w,.01));n/=max(n.x+n.y+n.z,1e-6);int wrap=node.extra0.z<.5?(int)uvOptions.y:(int)node.extra0.z-1,filter=node.extra0.w<.5?(int)uvOptions.z:(int)node.extra0.w-1;float4 tex=imageNodeAt((int)node.reserved.x,q.yz*node.parameters.xy,wrap,filter,node.reserved.zw)*n.x+imageNodeAt((int)node.reserved.x,q.xz*node.parameters.xy,wrap,filter,node.reserved.zw)*n.y+imageNodeAt((int)node.reserved.x,q.xy*node.parameters.xy,wrap,filter,node.reserved.zw)*n.z;value=float4(imageWorking(tex.rgb,(int)node.parameters.z),tex.a);} break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_90)
            case 90: { {float scale=tileScale(node.parameters.x);float2 q=nuv*scale,cell=floor(q);float sum=0;float angle=node.parameters.w*.0174532925;float2 dir=float2(cos(angle),sin(angle));
                [loop]for(int y=-1;y<=1;y++)[loop]for(int x=-1;x<=1;x++){float2 c=cell+float2(x,y),v=q-c-float2(tileHash(c,node.parameters.y,scale),tileHash(c,node.parameters.y+21.3,scale));sum+=exp(-dot(v,v)*3.14159265)*cos(6.283185*node.parameters.z*dot(v,dir)+tileHash(c+17,node.parameters.y,scale)*6.283185);}value=saturate(.5+sum*.35).xxxx;} break; }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_7)
            case 7: { {color=node.meta.y>=0?a.rgb:primary.rgb;rough=node.meta.z>=0?saturate(b.x):primary.a;metallic=node.meta.w>=0?saturate(c.x):secondary.a;materialCoverage=uvOptions.w>.5?saturate(a.a):1;value=float4(color,materialCoverage);
                float4 d=node.links0.x>=0?converted(values[(int)node.links0.x],(int)node.convert0.w):float4(0,0,1,0);
                float4 h=node.links0.y>=0?converted(values[(int)node.links0.y],(int)node.convert1.x):0;
                float4 ao=node.links0.z>=0?converted(values[(int)node.links0.z],(int)node.convert1.y):1;
                float4 e=node.links0.w>=0?converted(values[(int)node.links0.w],(int)node.convert1.z):0;
                float4 opacity=node.links1.x>=0?converted(values[(int)node.links1.x],(int)node.convert1.w):1;
                detail=float4(d.xyz/max(length(d.xyz),1e-6),clamp(h.x,-1,1));emission=float4(max(e.rgb,0),1);utility=float4(saturate(ao.x),saturate(opacity.x),1,1);
            } break; }
#endif

#if !defined(SPECIALIZED_NODES) || defined(NODE_119) || defined(NODE_120) || defined(NODE_129) || defined(NODE_131) || defined(NODE_132) || defined(NODE_138)
            case 119:case 120:case 129:case 131:case 132:case 138: {value=fieldAt((int)node.reserved.x,(float2(p)+.5)/outputSettings.y);break;}
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_118)
            case 118: {
                float2 q=(float2(p)+.5)/outputSettings.y,lo=node.parameters.xy,size=max(node.parameters.zw,1e-6);
                bool inside=all(q>=lo)&&all(q<lo+size);
                value=op==1?fieldAt((int)node.reserved.x,lo+q*size):inside?fieldAt((int)node.reserved.x,q):0;
                break;
            }
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_121)
            case 121:{value=float4(dot(a.rgb,node.parameters.xyz)+node.parameters.w,dot(a.rgb,node.extra0.xyz)+node.extra0.w,dot(a.rgb,node.extra1.xyz)+node.extra1.w,a.a);break;}
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_122) || defined(NODE_123)
            case 122:case 123:{float softness=kind==122?node.extra0.x:node.extra0.w;
                float m=1-smoothstep(max(0,node.parameters.w),max(0,node.parameters.w)+max(softness,1e-6),length(a.rgb-node.parameters.xyz)/sqrt(3.0));
                value=kind==122?m.xxxx:float4(lerp(a.rgb,node.extra0.xyz,m),a.a);break;}
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_124)
            case 124:{value=float4(op==1?frac(a.rgb+node.parameters.x):saturate(a.rgb+node.parameters.x),a.a);break;}
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_125)
            case 125:{value=a;if(op==0)value.a=saturate(node.meta.z>=0?b.x:node.parameters.x);else if(op==1)value.rgb*=value.a;else value.rgb=value.a>1e-8?value.rgb/value.a:0;break;}
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_126)
            case 126:{float2 q=(float2(p)+.5)/outputSettings.y,center=node.parameters.xy,d=q-center;int count=clamp((int)node.parameters.w,1,128),slot=(int)node.reserved.x,type=(int)node.links1.y;
                float4 sum=0;[loop]for(int j=0;j<count;j++){float t=count==1?0:(float(j)/(count-1)-.5),angle=t*node.parameters.z*.01745329252;
                    float2 tap=op==0?center+float2(cos(angle)*d.x-sin(angle)*d.y,sin(angle)*d.x+cos(angle)*d.y):center+d*(1+t*node.parameters.z/100);
                    float4 v=fieldAt(slot,tap);if(type==1)v.rgb*=v.a;sum+=v;}
                value=sum/count;if(type==1)value.rgb=value.a>1e-8?value.rgb/value.a:0;if(type==5)value.xyz=safeNormalize(value.xyz);break;}
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_127)
            case 127:{float2 q=(float2(p)+.5)/outputSettings.y,d=q-node.parameters.zw;int slot=(int)node.reserved.x;
                float amount=node.parameters.x,angle=node.parameters.y*.01745329252;
                float intensity=node.meta.z>=0?converted(fieldAt(slot+1,q),(int)node.convert0.y).x:1;
                if(op==0){float4 sum=0;[unroll]for(int j=0;j<4;j++){float aa=angle+j*1.57079632679;sum+=fieldAt(slot,q+float2(cos(aa),sin(aa))*amount*intensity);}value=sum*.25;break;}
                if(op==1)q+=float2(cos(angle),sin(angle))*amount*intensity;
                if(op==2){float a0=amount*(1-saturate(length(d)*2));q=node.parameters.zw+float2(cos(a0)*d.x-sin(a0)*d.y,sin(a0)*d.x+cos(a0)*d.y);}
                if(op==3)q.x+=d.y*amount;
                if(op==4)q.x=node.parameters.z+(q.x-node.parameters.z)/max(.01,1+amount*d.y);
                if(op==5)q.x=1-abs(2*q.x-1);if(op==6)q.y=1-abs(2*q.y-1);
                if(op==7){float slices=clamp(abs(node.parameters.y),1,64),sector=6.283185307/slices,aa=abs(frac(atan2(d.y,d.x)/sector+.5)*sector-sector*.5);q=node.parameters.zw+length(d)*float2(cos(aa),sin(aa));}
                value=fieldAt(slot,q);break;}
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_128)
            case 128:{float2 q=(float2(p)+.5)/outputSettings.y;int slot=(int)node.reserved.x;float index=round(fieldAt(slot,q).x);
                float2 center=node.meta.w>=0?fieldAt(slot+2,q).xy:.5;
                float2 size=node.links0.x>=0?max(fieldAt(slot+3,q).xy,1e-6):1;
                float2 delta=q-center;delta-=round(delta);float2 local=delta/size/max(node.parameters.x,.001);
                float angle=(node.parameters.y+(hash3(float3(index,0,0),node.parameters.z).x-.5)*node.parameters.w)*.01745329252;local=float2(cos(angle)*local.x+sin(angle)*local.y,-sin(angle)*local.x+cos(angle)*local.y)+.5;
                value=index>0&&all(local>=0)&&all(local<=1)?fieldAt(slot+1,clamp(local,.5/outputSettings.y,1-.5/outputSettings.y)):0;break;}
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_130)
            case 130:{int directions=clamp((int)node.parameters.w,1,16),slot=(int)node.reserved.x;float2 q=(float2(p)+.5)/outputSettings.y;float height=converted(fieldAt(slot,q),(int)node.convert0.x).x,occlusion=0;
                [loop]for(int j=0;j<directions;j++){float angle=(j+.5)*6.283185307/directions;float2 dir=float2(cos(angle),sin(angle));float horizon=0;
                    [loop]for(int step=1;step<=16;step++){float distance=max(1,node.parameters.x)*step/16;float h=converted(fieldAt(slot,q+dir*distance/outputSettings.y),(int)node.convert0.x).x;
                        horizon=max(horizon,(h-height-node.parameters.z)*outputSettings.y/distance*node.parameters.y);}
                    occlusion+=horizon/sqrt(1+horizon*horizon);}
                value=saturate(1-occlusion/directions).xxxx;break;}
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_133)
            case 133:{int slot=(int)node.reserved.x;float2 q=(float2(p)+.5)/outputSettings.y,dx=float2(1,0)/outputSettings.y,dy=dx.yx;
                float gx=converted(fieldAt(slot,q+dx),(int)node.convert0.x).x-converted(fieldAt(slot,q-dx),(int)node.convert0.x).x;
                float gy=converted(fieldAt(slot,q+dy),(int)node.convert0.x).x-converted(fieldAt(slot,q-dy),(int)node.convert0.x).x;
                float az=node.parameters.x*.01745329252,el=node.parameters.y*.01745329252;
                float3 n=safeNormalize(float3(-gx*node.parameters.z*outputSettings.y,-gy*node.parameters.z*outputSettings.y,1));
                float3 l=float3(cos(az)*cos(el),sin(az)*cos(el),sin(el));float diffuse=saturate(dot(n,l));
                value=saturate(diffuse+pow(saturate(dot(n,safeNormalize(l+float3(0,0,1)))),max(1,node.parameters.w))*.25).xxxx;break;}
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_134)
            case 134:{float scale=(op==2||op==4)?max(2,round(node.parameters.x*.5)*2):tileScale(node.parameters.x);float2 q=nuv*scale+hash3(float3(0,0,0),node.parameters.y).xy,f=frac(q)-.5;float width=clamp(node.parameters.z,.001,1),v=0;
                if(op==0){float angle=atan2(f.y,f.x),points=clamp(round(node.parameters.w),3,16);float radius=width*(.65+.35*cos(angle*points));v=1-smoothstep(radius,radius+.01,length(f));}
                if(op==1){float rows=max(2,round(scale*.8660254*.5)*2);float2 t=nuv*float2(scale,rows)+hash3(float3(0,0,0),node.parameters.y).xy;t.x+=t.y*.5;float3 edges=abs(float3(frac(t.x),frac(t.y),frac(t.x-t.y))-.5);v=1-smoothstep(width*.1,width*.1+.01,min(edges.x,min(edges.y,edges.z)));}
                if(op==2){bool horizontal=abs(fmod(floor(q.x)+floor(q.y),2))<1;v=1-smoothstep(width,width+.02,abs(horizontal?f.y:f.x)*2);v*=.65+.35*cos((horizontal?f.x:f.y)*3.14159265);}
                if(op==3){float2 c=f+float2(.5,.5);v=1-smoothstep(width*.1,width*.1+.015,abs(frac(length(c)*4)-.5));}
                if(op==4){float2 row=q;row.x+=abs(fmod(floor(row.y),2))*.5;float2 d=frac(row)-.5;float edge=max(abs(d.x)*.8660254+abs(d.y)*.5,abs(d.y));v=1-smoothstep(width*.5,width*.5+.02,edge);}
                if(op==5)v=pow(saturate(.5+.5*sin(q.x*6.283185307+sin(q.y*6.283185307+node.parameters.y)*width)),4);
                if(op==6)v=exp(-dot(f,f)/max(width*width*.1,1e-5));if(op==7)v=1-smoothstep(width,width+.02,frac(q.x));
                value=v.xxxx;break;}
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_135)
            case 135:{float period=tileScale(node.parameters.x);float3 q=coord*period;float seed=node.parameters.y,v=0,weight=.5,total=0;int octaves=clamp((int)node.parameters.z,1,8);
                [loop]for(int j=0;j<octaves;j++){v+=tilePerlin3(q*exp2(j),seed+j,period*exp2(j))*weight;total+=weight;weight*=clamp(node.parameters.w,.05,.95);}v/=max(total,1e-6);
                if(op==0){float3 r=hash3(tileCell3(floor(q),period),seed);v=saturate(.5+sqrt(-2*log(max(r.x,1e-6)))*cos(r.y*6.283185307)*.166666667);}
                if(op==1)v=.5+.5*sin(v*12+(q.x+q.y)*6.283185307);
                if(op==2)v=pow(saturate(1-abs(v*2-1)),8);
                if(op==3)v=.5+.5*sin(q.x*6.283185307+v*8);
                if(op==4)v=tileCellular3(q,seed,1,period);
                if(op==5)v=pow(saturate(.5+.5*sin(q.x*6.283185307*4+v*4)),4);
                if(op==6)v=smoothstep(.4,.7,v)*tileCellular3(q*3,seed,0,period*3);
                if(op==7)v=smoothstep(.25,.8,v);value=v.xxxx;break;}
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_136)
            case 136:{float d=node.links0.x>=0?converted(values[(int)node.links0.x],(int)node.convert0.w).x:node.parameters.w;
                value=float4(node.meta.y>=0?a.x:node.parameters.x,node.meta.z>=0?b.x:node.parameters.y,node.meta.w>=0?c.x:node.parameters.z,d);break;}
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_137)
            case 137:{int selector=clamp((int)round(node.links1.x>=0?converted(values[(int)node.links1.x],(int)node.convert1.w).x:node.parameters.x),0,6);
                int source=selector==0?(int)node.meta.y:selector==1?(int)node.meta.z:selector==2?(int)node.meta.w:selector==3?(int)node.links0.x:selector==4?(int)node.links0.y:selector==5?(int)node.links0.z:(int)node.links0.w;
                int code=selector==0?(int)node.convert0.x:selector==1?(int)node.convert0.y:selector==2?(int)node.convert0.z:selector==3?(int)node.convert0.w:selector==4?(int)node.convert1.x:selector==5?(int)node.convert1.y:(int)node.convert1.z;
                value=source>=0?converted(values[source],code):node.parameters.y.xxxx;break;}
#endif

#if !defined(SPECIALIZED_NODES) || defined(NODE_114) || defined(NODE_115) || defined(NODE_117)
            case 114:case 115:case 117: {value=fieldAt((int)node.reserved.x,(float2(p)+.5)/outputSettings.y);break;}
#endif
#if !defined(SPECIALIZED_NODES) || defined(NODE_116)
            case 116: {
                float2 grid=max(round(node.parameters.xy),1),uv=(float2(p)+.5)/outputSettings.y;
                float2 cell=floor(uv*grid);float4 result=0;
                [loop]for(int y=-1;y<=1;y++)[loop]for(int x=-1;x<=1;x++){
                    float2 c=cell+float2(x,y),periodic=fmod(fmod(c,grid)+grid,grid);
                    float seed=node.parameters.z;
                    float2 jitter=(float2(hashSeed(periodic,seed),hashSeed(periodic+17,seed))-.5)*node.extra0.y;
                    float scale=clamp(node.parameters.w*(1+(hashSeed(periodic+31,seed)*2-1)*node.extra0.z),.01,1.25);
                    float angle=(node.extra0.x+(hashSeed(periodic+57,seed)*2-1)*node.extra0.w)*.01745329252;
                    float2 local=(uv*grid-c-.5-jitter)/scale;
                    local=float2(cos(angle)*local.x+sin(angle)*local.y,-sin(angle)*local.x+cos(angle)*local.y)+.5;
                    if(all(local>=0)&&all(local<=1)){
                        float4 v=node.meta.y>=0?fieldAt((int)node.reserved.x,clamp(local,.5/outputSettings.y,1-.5/outputSettings.y)):float4(1,1,1,1);
                        if(node.links1.y==1){float alpha=saturate(v.a);result.rgb=v.rgb*alpha+result.rgb*(1-alpha);result.a=alpha+result.a*(1-alpha);}
                        else result=max(result,v.xxxx);
                    }
                }
                if(node.links1.y==1 && result.a>1e-8)result.rgb/=result.a;
                value=result;break;
            }
#endif
            default: break;
            }
            values[i]=value;
            if(graphInfo.w==i+1)nodeResult=value;
            if(preview){bool colorType=node.links1.y==1; bool vectorType=node.links1.y==2||node.links1.y==5;
                nodeAtlas[tid.xy+uint2(i%8*64,i/8*64)]=float4(colorType?saturate(toDisplay(value.rgb)):vectorType?saturate(value.rgb*.5+.5):saturate(value.xxx),1);}
        }
    }
    if(preview) return;
    if(graphInfo.w>0){colorMap[p]=nodeResult;materialMap[p]=float4(.5,0,1,1);maskMap[p]=nodeResult.x;return;}
    rough=saturate(rough);metallic=saturate(metallic);
    if(reserved.y==1){maskMap[p]=saturate(lerp(oldMask,blendValue(oldMask,graphMask,(int)effectInfo.y),effectInfo.x));}
    else if(reserved.y==2){uint ch=(uint)effectInfo.z;float opacity=effectInfo.x*materialCoverage;int blend=(int)effectInfo.y;bool fill=reserved.z==6;
        float alpha=fill?opacity+oldC.a*(1-opacity):oldC.a;
        float3 blended=blendColor(oldC.rgb,color,blend);float3 c=fill?(blended*opacity+oldC.rgb*oldC.a*(1-opacity))/max(alpha,1e-8):lerp(oldC.rgb,blended,opacity);
        float rc=fill?opacity+oldM.b*(1-opacity):oldM.b,mc=fill?opacity+oldM.a*(1-opacity):oldM.a;
        float r=fill?(blendValue(oldM.r,rough,blend)*opacity+oldM.r*oldM.b*(1-opacity))/max(rc,1e-8):lerp(oldM.r,blendValue(oldM.r,rough,blend),opacity);
        float m=fill?(blendValue(oldM.g,metallic,blend)*opacity+oldM.g*oldM.a*(1-opacity))/max(mc,1e-8):lerp(oldM.g,blendValue(oldM.g,metallic,blend),opacity);
        colorMap[p]=float4((ch&1)!=0?saturate(c):oldC.rgb,(ch&1)!=0?alpha:oldC.a);materialMap[p]=float4((ch&2)!=0?saturate(r):oldM.r,(ch&4)!=0?saturate(m):oldM.g,(ch&2)!=0?rc:oldM.b,(ch&4)!=0?mc:oldM.a);}
    else {colorMap[p]=float4(color,materialCoverage);materialMap[p]=float4(rough,metallic,materialCoverage,materialCoverage);}
    if(reserved.y!=1){
        uint channels=reserved.y==2?(uint)effectInfo.z:255;float weight=(reserved.y==2?effectInfo.x:1)*materialCoverage;
        float4 priorD=channelRead(inputDetail,p),priorE=channelRead(inputEmission,p),priorU=channelRead(inputUtility,p),priorCoverage=channelRead(inputCoverage,p);
        float3 n=(channels&8)!=0?lerp(priorD.xyz,detail.xyz,weight):priorD.xyz;
        detailMap[p]=float4(n/max(length(n),1e-6),(channels&16)!=0?lerp(priorD.w,detail.w,weight):priorD.w);
        emissionMap[p]=float4((channels&64)!=0?lerp(priorE.rgb,emission.rgb,weight):priorE.rgb,1);
        float4 authored=float4((channels&8)!=0?1:0,(channels&32)!=0?1:0,(channels&64)!=0?1:0,(channels&128)!=0?1:0);
        coverageMap[p]=priorCoverage+(1-priorCoverage)*authored*weight;
        utilityMap[p]=float4((channels&32)!=0?lerp(priorU.r,utility.r,weight):priorU.r,(channels&128)!=0?lerp(priorU.g,utility.g,weight):priorU.g,0,(channels&16)!=0?priorU.a+(1-priorU.a)*weight:priorU.a);
    }

}
#elif defined(MESH)
Texture2D<float4> albedo:register(t0);Texture2D<float4> properties:register(t1);SamplerState textureSampler:register(s0);
Texture2D<float> selectedMask:register(t2);
Texture2D<float4> surfaceDetail:register(t3);Texture2D<float4> surfaceEmission:register(t4);Texture2D<float4> surfaceUtility:register(t5);
float3 finalSurfaceNormal(float2 uv,float3 base){
 uint w,h;surfaceDetail.GetDimensions(w,h);float2 stepUV=1.0/float2(w,h),lo=stepUV*.5,hi=1-lo;
 float hx=surfaceDetail.SampleLevel(textureSampler,clamp(uv+float2(stepUV.x,0),lo,hi),0).w-surfaceDetail.SampleLevel(textureSampler,clamp(uv-float2(stepUV.x,0),lo,hi),0).w;
 float hy=surfaceDetail.SampleLevel(textureSampler,clamp(uv+float2(0,stepUV.y),lo,hi),0).w-surfaceDetail.SampleLevel(textureSampler,clamp(uv-float2(0,stepUV.y),lo,hi),0).w;
 return combineNormalHeight(base,float3(-hx*w*.025,-hy*h*.025,1));
}

cbuffer CameraData:register(b1) {float4 camera;float4 cameraExtra;float4 cameraScreen;float4 lighting;float4 environmentSettings;float4 projectionSettings;};
Texture2D<float4> environmentImage:register(t6);
float3 environmentRadiance(float3 n,float mip){float c=cos(lighting.w),s=sin(lighting.w);n=float3(c*n.x-s*n.z,n.y,s*n.x+c*n.z);float2 uv=float2(atan2(n.z,n.x)/6.283185+.5,acos(clamp(n.y,-1,1))/3.141593);return environmentImage.SampleLevel(textureSampler,uv,mip).rgb*environmentSettings.y;}
float3 keyDirection(){float3 v=normalize(float3(-.55,.65,.7));float c=cos(lighting.x),s=sin(lighting.x);v=float3(c*v.x-s*v.z,v.y,s*v.x+c*v.z);float cp=cos(lighting.y),sp=sin(lighting.y);return float3(v.x,cp*v.y-sp*v.z,sp*v.y+cp*v.z);}
struct MeshInput {float3 position:POSITION;float3 normal:NORMAL;float2 uv:TEXCOORD;float3 tangent:TANGENT;float3 bitangent:BINORMAL;};
struct MeshOutput {float4 position:SV_POSITION;float3 normal:NORMAL;float2 uv:TEXCOORD;float3 worldPosition:TEXCOORD1;float3 tangent:TEXCOORD2;float3 bitangent:TEXCOORD3;};
float3 rotate(float3 p) {float c=cos(camera.x),s=sin(camera.x),cp=cos(camera.y),sp=sin(camera.y);float3 q=float3(c*p.x-s*p.z,p.y,s*p.x+c*p.z);return float3(q.x,cp*q.y-sp*q.z,sp*q.y+cp*q.z);}
MeshOutput meshVertex(MeshInput i) {MeshOutput o;float3 p=rotate(objectRotate(i.position*objectScale.xyz)+objectTranslation.xyz);if(projectionSettings.x>.5){float w=3-p.z;o.position=float4((p.xy*camera.z*3*projectionSettings.y+cameraExtra.xy*w)*cameraScreen.xy+cameraScreen.zw*w,(w-.05)/10*w,w);}else o.position=float4((p.xy*camera.z+cameraExtra.xy)*cameraScreen.xy+cameraScreen.zw,.5-p.z*.4,1);o.normal=rotate(normalize(objectRotate(i.normal/max(objectScale.xyz,.001))));o.tangent=rotate(objectRotate(i.tangent));o.bitangent=rotate(objectRotate(i.bitangent));o.uv=i.uv;o.worldPosition=p;return o;}
float4 meshShadowVertex(MeshInput i):SV_POSITION {float3 p=rotate(objectRotate(i.position*objectScale.xyz)+objectTranslation.xyz);float3 c=shadowCoordinates(p,(int)renderReserved.x);return float4(c.xy,c.z*.5+.5,1);}
float3 display(float3 c){return managedDisplay(c);}
StructuredBuffer<uint> regionMembership:register(t12);
float4 meshPixelBase(MeshOutput i) {
    float3 color=albedo.Sample(textureSampler,i.uv).rgb;float2 p=properties.Sample(textureSampler,i.uv).rg;
    if(camera.w==4) {float m=cameraExtra.z>.5?saturate(selectedMask.Sample(textureSampler,i.uv)):1;
        if(cameraExtra.z>.5 && cameraExtra.w>.5)m=1-m;return float4(m,m,m,1);}
    if(camera.w==8)return float4(color,1);if(camera.w==9)return float4(color*.5+.5,1);
    float4 detail=surfaceDetail.Sample(textureSampler,i.uv),emission=surfaceEmission.Sample(textureSampler,i.uv),utility=surfaceUtility.Sample(textureSampler,i.uv);
    if(camera.w==5)return float4(finalSurfaceNormal(i.uv,detail.xyz)*.5+.5,1);if(camera.w==6)return float4((.5+detail.w*.5).xxx,1);if(camera.w==7)return float4(utility.rrr,1);
    if(camera.w==10)return float4(display(emission.rgb),1);
    if(camera.w==11)return float4(utility.ggg,1);
    clip(utility.g-.5);
    if(camera.w==1) return float4(p.rrr,1);if(camera.w==2) return float4(p.ggg,1);if(camera.w==3) return float4(display(color),1);
    float3 tangentNormal=finalSurfaceNormal(i.uv,detail.xyz);
    float3 n=normalize(i.tangent*tangentNormal.x+i.bitangent*tangentNormal.y+i.normal*tangentNormal.z);
    float3 v=normalize(float3(0,0,3)-i.worldPosition);float rough=clamp(p.x,.02,1),metal=saturate(p.y);float3 f0=lerp(.04.xxx,color,metal);
    float3 shaded=directPBR(color,rough,metal,n,v,i.worldPosition);
    shaded+=environmentPBR(color,rough,metal,n,v,lighting.w,environmentSettings.y,environmentSettings.x>.5)*utility.r;
    shaded=(shaded+emission.rgb)*exp2(lighting.z);
    if(renderView.z>.5)shaded=lerp(shaded,float3(.08,.8,.64),.25);
    return float4(display(shaded),1);
}
float4 meshPixel(MeshOutput i,uint faceID:SV_PrimitiveID):SV_TARGET {
    float4 result=meshPixelBase(i);
    uint authored=faceID+(uint)interactionSettings.y;
    if(interactionSettings.x>.5 && authored<(uint)interactionSettings.z && regionMembership[authored]!=0)
        result.rgb=lerp(result.rgb,float3(.14,.88,.72),.38);
    return result;
}
#elif defined(COMPOSE)
Texture2D<float> folderMask:register(t12);
Texture2D<float4> authoredColor:register(t13);Texture2D<float4> authoredMaterial:register(t14);
Texture2D<float4> authoredDetail:register(t15);Texture2D<float4> authoredEmission:register(t16);
Texture2D<float4> authoredUtility:register(t17);Texture2D<float4> authoredCoverage:register(t18);
Texture2D<float4> lowerCoverage:register(t19);
RWTexture2D<float4> resultCoverage:register(u5);
Texture2D<float4> lowerColor : register(t0);
Texture2D<float4> lowerMaterial : register(t1);
Texture2D<float4> upperColor : register(t2);
Texture2D<float4> upperMaterial : register(t3);
Texture2D<float> upperMask : register(t4);
RWTexture2D<float4> resultColor : register(u0);
RWTexture2D<float4> resultMaterial : register(u1);
Texture2D<float4> lowerDetail:register(t5);Texture2D<float4> lowerEmission:register(t6);Texture2D<float4> lowerUtility:register(t7);
Texture2D<float4> upperCoverage:register(t11);
Texture2D<float4> upperDetail:register(t8);Texture2D<float4> upperEmission:register(t9);Texture2D<float4> upperUtility:register(t10);
RWTexture2D<float4> resultDetail:register(u2);RWTexture2D<float4> resultEmission:register(u3);RWTexture2D<float4> resultUtility:register(u4);
SamplerState bakeSampler:register(s0);
cbuffer ComposeData : register(b0) { float4 settings; float4 maskSettings;float4 materialBlend;float4 channelOpacity;float4 extraOpacity;float4 opacityTail;float4 dispatchRegion;float4 extraBlend;float4 blendTail; };
[numthreads(8,8,1)]
void compose(uint3 tid : SV_DispatchThreadID) {
    uint2 p=tid.xy+uint2(dispatchRegion.xy); if(any(tid.xy>=uint2(dispatchRegion.zw))||any(p>=uint2(settings.yy))) return;
    if(settings.z==-2){
      float4 a=lowerColor[p],m=lowerMaterial[p],d=lowerDetail[p],e=lowerEmission[p],u=lowerUtility[p],c=lowerCoverage[p];
      resultColor[p]=channelOpacity.x==10?a:0;
      resultMaterial[p]=float4(materialBlend.x==10?m.r:.5,materialBlend.y==10?m.g:0,materialBlend.x==10?m.b:0,materialBlend.y==10?m.a:0);
      resultDetail[p]=float4(extraBlend.x==10?d.xyz:float3(0,0,1),extraBlend.y==10?d.w:0);
      resultEmission[p]=extraBlend.w==10?e:0;
      resultUtility[p]=float4(extraBlend.z==10?u.r:1,blendTail.x==10?u.g:1,0,extraBlend.y==10?u.a:0);
      resultCoverage[p]=float4(extraBlend.x==10?c.r:0,extraBlend.z==10?c.g:0,extraBlend.w==10?c.b:0,blendTail.x==10?c.a:0);return;
    }
    if(settings.z<0){
      float2 uv=(float2(p)+.5)/settings.y;float3 n=float3(0,0,1);
      if(maskSettings.x>.5){float4 encoded=upperDetail.SampleLevel(bakeSampler,uv,0);if(encoded.a>0){n=encoded.xyz*2-1;if(maskSettings.z>.5)n.y=-n.y;n=normalize(n+1e-8);}}
      float4 encodedAO=maskSettings.y>.5?upperUtility.SampleLevel(bakeSampler,uv,0):1;
      float ao=encodedAO.a>0?encodedAO.r:1;
      resultColor[p]=float4(.035,.044,.055,1);resultMaterial[p]=float4(.6,0,1,1);resultDetail[p]=float4(n,0);resultEmission[p]=0;resultUtility[p]=float4(ao,1,0,1);resultCoverage[p]=1;return;
    }
    float4 a=lowerColor[p], b=upperColor[p]; float4 m=lowerMaterial[p], n=upperMaterial[p];
    bool adjustment=blendTail.w<.5 && (settings.z==10||materialBlend.x==10||materialBlend.y==10||any(extraBlend==10)||blendTail.x==10);
    float4 sourceD=0,sourceE=0,sourceU=0,sourceCoverage=0;
    if(adjustment){
      float4 sourceC=authoredColor[p],sourceM=authoredMaterial[p];
      sourceD=channelRead(authoredDetail,p);sourceE=channelRead(authoredEmission,p);sourceU=channelRead(authoredUtility,p);sourceCoverage=channelRead(authoredCoverage,p);
      if(settings.z!=10)b=sourceC;else b.a=a.a;
      if(materialBlend.x!=10){n.r=sourceM.r;n.b=sourceM.b;}else n.b=m.b;
      if(materialBlend.y!=10){n.g=sourceM.g;n.a=sourceM.a;}else n.a=m.a;
    }
    float mask=maskSettings.x>.5?saturate(upperMask[p]):1;if(maskSettings.x>.5 && maskSettings.y>.5)mask=1-mask;mask=lerp(1,mask,blendTail.y);if(maskSettings.z>.5){float folder=saturate(folderMask[p]);mask*=lerp(1,maskSettings.w>.5?1-folder:folder,blendTail.z);}mask*=settings.x;
    uint channels=(uint)settings.w;
    float4 ld=lowerDetail[p],ud=channelRead(upperDetail,p),le=lowerEmission[p],ue=channelRead(upperEmission,p),lu=lowerUtility[p],uu=channelRead(upperUtility,p);
    float4 coverage=channelRead(upperCoverage,p),lc=lowerCoverage[p];
    if(adjustment){
      if(extraBlend.x!=10){ud.xyz=sourceD.xyz;coverage.r=sourceCoverage.r;}
      if(extraBlend.y!=10){ud.w=sourceD.w;uu.a=sourceU.a;}else uu.a=lu.a;
      if(extraBlend.z!=10){uu.r=sourceU.r;coverage.g=sourceCoverage.g;}
      if(extraBlend.w!=10){ue=sourceE;coverage.b=sourceCoverage.b;}
      if(blendTail.x!=10){uu.g=sourceU.g;coverage.a=sourceCoverage.a;}
    }
    bool group=blendTail.w>.5;
    float cw=(channels&1)!=0 && settings.z!=19?mask*channelOpacity.x*(group&&settings.z==10?1:b.a):0;
    float ca=cw+a.a*(1-cw);
    float3 cv=(blendColor(a.rgb,b.rgb,(int)settings.z)*cw+a.rgb*a.a*(1-cw))/max(ca,1e-8);
    resultColor[p]=float4(cw>0?cv:a.rgb,ca);
    float rw=(channels&2)!=0 && materialBlend.x!=19?mask*channelOpacity.y*(group&&materialBlend.x==10?1:n.b):0;
    float mw=(channels&4)!=0 && materialBlend.y!=19?mask*channelOpacity.z*(group&&materialBlend.y==10?1:n.a):0;
    float rc=rw+m.b*(1-rw),mc=mw+m.a*(1-mw);
    resultMaterial[p]=float4(rw>0?saturate((blendValue(m.r,n.r,(int)materialBlend.x)*rw+m.r*m.b*(1-rw))/max(rc,1e-8)):m.r,mw>0?saturate((blendValue(m.g,n.g,(int)materialBlend.y)*mw+m.g*m.a*(1-mw))/max(mc,1e-8)):m.g,rc,mc);
    float3 targetNormal=ud.xyz;int normalMode=(int)extraBlend.x;
    if(normalMode==0){float3 t=ld.xyz+float3(0,0,1),u=ud.xyz*float3(-1,-1,1);targetNormal=normalize(t*dot(t,u)/max(t.z,1e-6)-u);}
    else if(normalMode==12)targetNormal=normalize(float3(ld.xy+ud.xy,ld.z*ud.z)+1e-8);
    else if(normalMode==13)targetNormal=normalize(float3(ld.xy+ud.xy,ld.z)+1e-8);
    else if(normalMode==19)targetNormal=ld.xyz;
    else if(normalMode!=10 && normalMode!=11)targetNormal=blendColor(ld.xyz*.5+.5,ud.xyz*.5+.5,normalMode)*2-1;
    float nw=(channels&8)!=0 && normalMode!=19?mask*extraOpacity.x*(group&&normalMode==10?1:coverage.r):0;
    float nc=nw+lc.r*(1-nw);float3 normal=nw>0?(targetNormal*nw+ld.xyz*lc.r*(1-nw))/max(nc,1e-8):ld.xyz;
    float hw=(channels&16)!=0 && extraBlend.y!=19?mask*extraOpacity.y*(group&&extraBlend.y==10?1:uu.a):0;
    float hc=hw+lu.a*(1-hw);
    float height=hw>0?(clamp(blendValue(ld.w,ud.w,(int)extraBlend.y),-1,1)*hw+ld.w*lu.a*(1-hw))/max(hc,1e-8):ld.w;
    resultDetail[p]=float4(length(normal)>1e-6?normalize(normal):float3(0,0,1),height);
    float ew=(channels&64)!=0 && extraBlend.w!=19?mask*extraOpacity.w*(group&&extraBlend.w==10?1:coverage.b):0;
    float ec=ew+lc.b*(1-ew);
    resultEmission[p]=float4(ew>0?(blendColor(le.rgb,ue.rgb,(int)extraBlend.w)*ew+le.rgb*lc.b*(1-ew))/max(ec,1e-8):le.rgb,ec);
    float aw=(channels&32)!=0 && extraBlend.z!=19?mask*extraOpacity.z*(group&&extraBlend.z==10?1:coverage.g):0;
    float ac=aw+lc.g*(1-aw);
    float ow=(channels&128)!=0 && blendTail.x!=19?mask*opacityTail.x*(group&&blendTail.x==10?1:coverage.a):0;
    float oc=ow+lc.a*(1-ow);
    float ao=aw>0?(blendValue(lu.r,materialBlend.w>.5 && extraBlend.z==0?lu.r*uu.r:uu.r,(int)extraBlend.z)*aw+lu.r*lc.g*(1-aw))/max(ac,1e-8):lu.r;
    float surfaceOpacity=ow>0?(blendValue(lu.g,uu.g,(int)blendTail.x)*ow+lu.g*lc.a*(1-ow))/max(oc,1e-8):lu.g;
    resultUtility[p]=float4(ao,surfaceOpacity,0,hc);resultCoverage[p]=float4(nc,ac,ec,oc);


}
#else
Texture2D<float4> albedo : register(t0);
Texture2D<float4> properties : register(t1);
SamplerState textureSampler : register(s0);
Texture2D<float> selectedMask:register(t2);
Texture2D<float4> surfaceDetail:register(t3);Texture2D<float4> surfaceEmission:register(t4);Texture2D<float4> surfaceUtility:register(t5);
float3 finalSurfaceNormal(float2 uv,float3 base){
 uint w,h;surfaceDetail.GetDimensions(w,h);float2 stepUV=1.0/float2(w,h),lo=stepUV*.5,hi=1-lo;
 float hx=surfaceDetail.SampleLevel(textureSampler,clamp(uv+float2(stepUV.x,0),lo,hi),0).w-surfaceDetail.SampleLevel(textureSampler,clamp(uv-float2(stepUV.x,0),lo,hi),0).w;
 float hy=surfaceDetail.SampleLevel(textureSampler,clamp(uv+float2(0,stepUV.y),lo,hi),0).w-surfaceDetail.SampleLevel(textureSampler,clamp(uv-float2(0,stepUV.y),lo,hi),0).w;
 return combineNormalHeight(base,float3(-hx*w*.025,-hy*h*.025,1));
}

cbuffer ViewData : register(b0) { float4 view; float4 cursor; float4 mode; float4 navigation; float4 cameraNavigation;float4 lighting;float4 environmentSettings;float4 projectionSettings; }; // width, height, yaw, channel
Texture2D<float4> environmentImage:register(t6);
float3 environmentRadiance(float3 n,float mip){float c=cos(lighting.w),s=sin(lighting.w);n=float3(c*n.x-s*n.z,n.y,s*n.x+c*n.z);float2 uv=float2(atan2(n.z,n.x)/6.283185+.5,acos(clamp(n.y,-1,1))/3.141593);return environmentImage.SampleLevel(textureSampler,uv,mip).rgb*environmentSettings.y;}
float3 keyDirection(){float3 v=normalize(float3(-.55,.65,.7));float c=cos(lighting.x),s=sin(lighting.x);v=float3(c*v.x-s*v.z,v.y,s*v.x+c*v.z);float cp=cos(lighting.y),sp=sin(lighting.y);return float3(v.x,cp*v.y-sp*v.z,sp*v.y+cp*v.z);}
struct VertexOutput { float4 position : SV_POSITION; float2 uv : TEXCOORD0; };
VertexOutput vertex(uint id : SV_VertexID) {
    VertexOutput o; o.uv=float2((id<<1)&2,id&2); o.position=float4(o.uv*float2(2,-2)+float2(-1,1),0,1); return o;
}
float3 displayColor(float3 c) { return managedDisplay(c); }
float3 channelColor(float2 uv) {
    float3 c=albedo.SampleLevel(textureSampler,uv,0).rgb; float2 p=properties.SampleLevel(textureSampler,uv,0).rg;
    if(view.w==4) {float m=mode.z>.5?saturate(selectedMask.SampleLevel(textureSampler,uv,0)):1;
        if(mode.z>.5 && mode.w>.5)m=1-m;return m.xxx;}
    if(view.w==8)return c;if(view.w==9)return c*.5+.5;
    float4 detail=surfaceDetail.SampleLevel(textureSampler,uv,0);if(view.w==5)return finalSurfaceNormal(uv,detail.xyz)*.5+.5;if(view.w==6)return (.5+detail.w*.5).xxx;if(view.w==7)return surfaceUtility.SampleLevel(textureSampler,uv,0).rrr;
    if(view.w==10)return displayColor(surfaceEmission.SampleLevel(textureSampler,uv,0).rgb);
    if(view.w==11)return surfaceUtility.SampleLevel(textureSampler,uv,0).ggg;
    if(view.w==1) return p.rrr; if(view.w==2) return p.ggg; return displayColor(c);
}
Texture2D<float> regionUV:register(t13);
float4 pixelColor(VertexOutput input,out float sceneDepth) {
    sceneDepth=.999999;
    float2 pos=input.position.xy;
    float split=mode.x==1?view.x:mode.x==2?0:view.x*.62;
    float3 bg=renderFlags.y>.5?managedDisplay(workingFrom709(renderBackground.rgb)):lerp(float3(.055,.063,.078),float3(.095,.108,.135),1-pos.y/view.y);

    if(renderFlags.y>.5 && pos.x<split && view.w==0){
        float sc=min(split*.40,view.y*.38);float2 ndc=float2(pos.x/split*2-1,1-pos.y/view.y*2)-float2(0,.02);
        float2 q=ndc/float2(2*sc/split,2*sc/view.y)-cameraNavigation.xy;
        float3 eye=float3(0,0,3),ray=normalize(float3(q/(navigation.w*3*projectionSettings.y),-1));
        if(projectionSettings.x<.5){eye=float3(q/navigation.w,3);ray=float3(0,0,-1);}
        float3 origin=inverseView(eye),direction=inverseView(ray);
        if(renderView.w>.5 && environmentSettings.x>.5)bg=managedDisplay(workingFrom709(environmentRadiance(renderFlags.y>.5?direction:ray,0))*exp2(lighting.z));
        if(renderFlags.w>.5 && abs(direction.y)>.0001){float distance=(groundSettings.x-origin.y)/direction.y;float3 world=origin+distance*direction;
            if(distance>0 && all(abs(world.xz)<groundSettings.zz)){float3 groundHit=forwardView(world),n=forwardView(float3(0,1,0)),v=normalize(eye-groundHit);float rough=clamp(groundSettings.y,.02,1),col=0;
                float3 color=workingFrom709(groundColor.rgb);float3 shaded=directPBR(color,rough,0,n,v,groundHit)+environmentPBR(color,rough,0,n,v,lighting.w,environmentSettings.y,environmentSettings.x>.5);
                sceneDepth=projectionSettings.x>.5?(3-groundHit.z-.05)/10:.5-groundHit.z*.4;
                if(sceneDepth>=0 && sceneDepth<=1)return float4(managedDisplay(shaded*exp2(lighting.z)),1);
                sceneDepth=.999999;
            }
        }
    }
    if(pos.x<split) {
        float scale=min(split*.40,view.y*.38);
        float2 q=(pos-float2(split*.5,view.y*.49))/scale; q.y=-q.y; q=(q-cameraNavigation.xy)/navigation.w;
        float rad=dot(q,q);
        if(rad<=1 && mode.y==0) {
            float3 normal=float3(q,sqrt(1-rad));
            float c=cos(view.z),s=sin(view.z);
            float cp=cos(cameraNavigation.z),sp=sin(cameraNavigation.z);
            float3 unpitch=float3(normal.x,cp*normal.y+sp*normal.z,-sp*normal.y+cp*normal.z);
            float3 surface=float3(c*unpitch.x+s*unpitch.z,unpitch.y,-s*unpitch.x+c*unpitch.z);
            float2 uv=float2(frac(atan2(surface.x,surface.z)/6.283185+.5),acos(clamp(surface.y,-1,1))/3.141593);
            float3 base=albedo.SampleLevel(textureSampler,uv,0).rgb;
            float2 props=properties.SampleLevel(textureSampler,uv,0).rg;
            if(view.w!=0) return float4(channelColor(uv),1);
            float3 shaded=directPBR(base,clamp(props.r,.02,1),saturate(props.g),normal,float3(0,0,1),normal);
            shaded+=environmentPBR(base,clamp(props.r,.02,1),saturate(props.g),normal,float3(0,0,1),lighting.w,environmentSettings.y,environmentSettings.x>.5);
            shaded=(shaded+surfaceEmission.SampleLevel(textureSampler,uv,0).rgb)*exp2(lighting.z);
            return float4(displayColor(shaded),1);
        }
    } else {
        float size=min(view.x-split-48,view.y-100);
        float2 start=float2(split+(view.x-split-size)*.5,(view.y-size)*.5);
        float2 uv=.5+((pos-float2(split+(view.x-split)*.5,view.y*.5))/size-navigation.xy)/navigation.z;
        bool repeated=cameraNavigation.w>.5;
        if(all(uv>=(repeated?-1:0))&&all(uv<=(repeated?2:1))) {
            float2 tileUV=frac(uv);float3 color=channelColor(repeated?tileUV:uv);
            if(repeated && (any(uv<0)||any(uv>1)))color*=.88;
            float2 grid=abs(frac(uv*8)-.5); if(grid.x>.491||grid.y>.491) color=lerp(color,float3(.3,.38,.43),.12);
            if(cursor.z>0 && cursor.w>0) {
                float2 delta=uv-cursor.xy;if(repeated)delta=frac(delta+.5)-.5;
                float d=length(delta*size*navigation.z); float r=cursor.z*size*navigation.z;
                if(abs(d-r)<1.2) color=float3(.7,.96,.87);
            }
            if(interactionSettings.x>.5 && regionUV.SampleLevel(textureSampler,uv,0)>.5)
                color=lerp(color,float3(.14,.88,.72),.38);
            return float4(color,1);
        }
    }
    if(abs(pos.x-split)<1) bg=float3(.15,.18,.22);
    return float4(bg,renderFlags.y>.5 && renderFlags.z>.5?0:1);
}
struct PresentationPixel {float4 color:SV_TARGET;float depth:SV_DEPTH;};
PresentationPixel pixel(VertexOutput input){PresentationPixel result;result.color=pixelColor(input,result.depth);return result;}

#endif

